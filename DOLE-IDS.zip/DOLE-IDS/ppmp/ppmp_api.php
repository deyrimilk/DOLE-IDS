<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
require_once __DIR__ . '/../Login/db_connect.php';
require_once __DIR__ . '/../Login/activity_log.php';

header('Content-Type: application/json; charset=utf-8');

function json_out(int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

function normalizePpmpHeader(string $value): string
{
    return strtolower(preg_replace('/[^a-z0-9]+/i', '', trim($value)) ?? '');
}

function xlsxColumnIndex(string $reference): int
{
    preg_match('/^([A-Z]+)/i', $reference, $matches);
    $letters = strtoupper($matches[1] ?? 'A');
    $index = 0;
    for ($i = 0; $i < strlen($letters); $i++) {
        $index = ($index * 26) + (ord($letters[$i]) - 64);
    }
    return max(0, $index - 1);
}

function parsePpmpRows(string $path, string $ext): array
{
    if ($ext !== 'xlsx' || !class_exists('ZipArchive')) {
        throw new InvalidArgumentException('The PPMP must be an .xlsx file and the server must have ZIP support enabled.');
    }

    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        throw new InvalidArgumentException('The uploaded PPMP file could not be opened.');
    }

    $sharedStrings = [];
    $sharedXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($sharedXml !== false && ($shared = simplexml_load_string($sharedXml)) !== false) {
        $sharedNamespaces = $shared->getDocNamespaces(true);
        $sharedRoot = $shared->children($sharedNamespaces[''] ?? '');
        foreach ($sharedRoot->si as $entry) {
            $sharedStrings[] = implode('', array_map('strval', iterator_to_array($entry->t)));
        }
    }

    $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($sheetXml === false) {
        for ($index = 0; $index < $zip->numFiles; $index++) {
            $name = $zip->getNameIndex($index);
            if (str_starts_with($name, 'xl/worksheets/') && str_ends_with($name, '.xml')) {
                $sheetXml = $zip->getFromIndex($index);
                break;
            }
        }
    }
    $zip->close();
    if ($sheetXml === false || ($sheet = simplexml_load_string($sheetXml)) === false) {
        throw new InvalidArgumentException('The PPMP workbook has no readable first worksheet.');
    }

    $sheetNamespaces = $sheet->getDocNamespaces(true);
    $sheetRoot = $sheet->children($sheetNamespaces[''] ?? '');
    $rows = [];
    foreach ($sheetRoot->sheetData->row as $row) {
        $cells = [];
        $fallbackIndex = 0;
        foreach ($row->c as $cell) {
            $domCell = function_exists('dom_import_simplexml') ? dom_import_simplexml($cell) : null;
            $reference = $domCell ? $domCell->getAttribute('r') : '';
            $cellType = $domCell ? $domCell->getAttribute('t') : '';
            $index = $reference !== '' ? xlsxColumnIndex($reference) : $fallbackIndex;
            $fallbackIndex = $index + 1;
            $value = (string)$cell->v;
            if ($cellType === 's' && isset($sharedStrings[(int)$value])) {
                $value = $sharedStrings[(int)$value];
            } elseif ($cellType === 'inlineStr') {
                $inline = $cell->children($sheetNamespaces[''] ?? '');
                $value = (string)$inline->is->t;
            }
            $cells[$index] = trim($value);
        }
        $rows[] = $cells;
    }

    $header = null;
    $itemColumn = $unitColumn = $quantityColumn = null;
    foreach (array_slice($rows, 0, 30) as $candidate) {
        foreach ($candidate as $index => $value) {
            $normalized = normalizePpmpHeader((string)$value);
            if (str_contains($normalized, 'itemdescription') || str_contains($normalized, 'itemsdescription')) $itemColumn = $index;
            if (str_contains($normalized, 'unitcategory')) $unitColumn = $index;
            if ($normalized === 'qty' || str_contains($normalized, 'qtyestimatedcost') || str_contains($normalized, 'quantityestimatedcost')) $quantityColumn = $index;
        }
        if ($itemColumn !== null && $unitColumn !== null && $quantityColumn !== null) {
            $header = $candidate;
            break;
        }
        $itemColumn = $unitColumn = $quantityColumn = null;
    }

    if ($header === null) {
        throw new InvalidArgumentException("The PPMP must contain Item's Description, Unit Category, and Qty columns.");
    }

    $parsed = [];
    foreach ($rows as $candidate) {
        $name = trim((string)($candidate[$itemColumn] ?? ''));
        $unit = trim((string)($candidate[$unitColumn] ?? ''));
        $quantity = (int)($candidate[$quantityColumn] ?? 0);
        if ($name === '' && $unit === '' && $quantity === 0) continue;
        if ($name === '' || $unit === '' || $quantity < 0) {
            throw new InvalidArgumentException('Every PPMP item row must include an item description, unit category, and non-negative quantity.');
        }
        if ($quantity > 0) $parsed[] = ['name' => $name, 'unit' => $unit, 'qty' => $quantity];
    }

    if (!$parsed) throw new InvalidArgumentException('The PPMP contains no items with a quantity greater than zero.');
    return $parsed;
}

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    json_out(401, ['success' => false, 'message' => 'Unauthorized']);
}

$role = (string)($_SESSION['role'] ?? '');
$allowedRoles = ['Requester', 'Admin', 'Approver'];
if (!in_array($role, $allowedRoles, true)) {
    json_out(403, ['success' => false, 'message' => 'Forbidden']);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($method !== 'GET') {
    $sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
    $cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));
    $headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));

    $valid = $headerToken !== '' && $sessionToken !== '' && hash_equals($sessionToken, $headerToken);
    if ($sessionToken === '' || !$valid) {
        json_out(403, ['success' => false, 'message' => 'Invalid CSRF token']);
    }
}

try {
    if ($method === 'POST' && $action === 'upload') {
        $headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
        $sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
        $cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

        $valid = $headerToken !== ''
            && $sessionToken !== ''
            && hash_equals($sessionToken, $headerToken);
        if (!$valid) {
            json_out(403, ['success' => false, 'message' => 'Invalid CSRF token']);
        }

        if (empty($_FILES['ppmp_file']) || $_FILES['ppmp_file']['error'] !== UPLOAD_ERR_OK) {
            json_out(422, ['success' => false, 'message' => 'No file uploaded']);
        }

        if ((int)$_FILES['ppmp_file']['size'] > 10 * 1024 * 1024) {
            json_out(413, ['success' => false, 'message' => 'PPMP file must be 10MB or smaller']);
        }

        $fiscalYear = trim((string)($_POST['fiscal_year'] ?? ''));
        if ($fiscalYear === '') {
            $fiscalYear = date('Y');
        }

        $uploadDir = __DIR__ . '/../Images/ppmp';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $ext = strtolower(pathinfo($_FILES['ppmp_file']['name'], PATHINFO_EXTENSION));
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['ppmp_file']['tmp_name']);
        $allowedMimes = ['application/zip', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
        if ($ext !== 'xlsx' || !in_array($mime, $allowedMimes, true)) {
            json_out(422, ['success' => false, 'message' => 'Only .xlsx files using the PPMP template are supported']);
        }

        $safeName = 'ppmp_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest = $uploadDir . '/' . $safeName;
        if (!move_uploaded_file($_FILES['ppmp_file']['tmp_name'], $dest)) {
            json_out(500, ['success' => false, 'message' => 'Could not save uploaded file']);
        }

        try {
            $items = parsePpmpRows($dest, $ext);
        } catch (InvalidArgumentException $e) {
            @unlink($dest);
            json_out(422, ['success' => false, 'message' => $e->getMessage()]);
        }

        $requestorName = (string)($_SESSION['username'] ?? '');
        $province = strtoupper(trim((string)($_SESSION['province'] ?? '')));
        if ($province === '') {
            @unlink($dest);
            json_out(422, ['success' => false, 'message' => 'Your account must have a province before uploading a PPMP.']);
        }
        $userId = (int)($_SESSION['user_id'] ?? 0);
        $stmt = $pdo->prepare(
            'INSERT INTO ppmp_records (requestor_id, requestor_name, file_name, stored_file, province, fiscal_year, status, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, "Pending", NOW())'
        );
        $stmt->execute([$userId, $requestorName, $_FILES['ppmp_file']['name'], $safeName, $province, $fiscalYear]);
        $ppmpId = (int)$pdo->lastInsertId();

        $insertItem = $pdo->prepare('INSERT INTO ppmp_items (ppmp_id, item_name, unit, quantity) VALUES (?, ?, ?, ?)');
        foreach ($items as $item) {
            $insertItem->execute([$ppmpId, $item['name'], $item['unit'], (int)$item['qty']]);
        }

        recordSystemActivity(
            $pdo,
            'ppmp_submitted',
            'ppmp',
            $ppmpId,
            $province,
            'PPMP submitted for review',
            ['file_name' => $_FILES['ppmp_file']['name'], 'fiscal_year' => $fiscalYear, 'items' => $items]
        );

        json_out(200, ['success' => true, 'message' => 'PPMP uploaded successfully']);
    }

    if ($method === 'GET' && $action === 'list') {
        $sql = 'SELECT pr.id, pr.requestor_name, pr.file_name, pr.province, pr.fiscal_year, pr.status, pr.reason, pr.uploaded_at, pr.reviewed_at, pr.reviewed_by, COUNT(pi.id) AS item_count
                FROM ppmp_records pr
                LEFT JOIN ppmp_items pi ON pi.ppmp_id = pr.id';
        $params = [];
        if ($role === 'Requester') {
            $sql .= ' WHERE pr.requestor_id = ?';
            $params[] = (int)($_SESSION['user_id'] ?? 0);
        }
        $sql .= ' GROUP BY pr.id ORDER BY pr.uploaded_at DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        json_out(200, ['success' => true, 'data' => $rows]);
    }

    if ($method === 'GET' && $action === 'download') {
        if ($role !== 'Approver' && $role !== 'Admin') {
            json_out(403, ['success' => false, 'message' => 'Only Supply staff can download PPMP files']);
        }

        $id = (int)($_GET['id'] ?? 0);
        $stmt = $pdo->prepare('SELECT file_name, stored_file, UNIX_TIMESTAMP(uploaded_at) AS uploaded_epoch FROM ppmp_records WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$record) {
            json_out(404, ['success' => false, 'message' => 'The original PPMP file is not available.']);
        }

        $uploadDir = realpath(__DIR__ . '/../Images/ppmp');
        $storedFile = basename((string)$record['stored_file']);
        if ($storedFile === '' && $uploadDir) {
            // Backfill records created before stored_file was added by matching upload time.
            $targetTime = (int)$record['uploaded_epoch'];
            $closest = null;
            $closestDelta = PHP_INT_MAX;
            foreach (glob($uploadDir . DIRECTORY_SEPARATOR . 'ppmp_*.xlsx') ?: [] as $candidate) {
                $delta = abs(filemtime($candidate) - $targetTime);
                if ($delta <= 10 && $delta < $closestDelta) {
                    $closest = $candidate;
                    $closestDelta = $delta;
                }
            }
            if ($closest !== null) {
                $storedFile = basename($closest);
                $backfill = $pdo->prepare('UPDATE ppmp_records SET stored_file = ? WHERE id = ?');
                $backfill->execute([$storedFile, $id]);
            }
        }
        if ($storedFile === '') {
            json_out(404, ['success' => false, 'message' => 'The original PPMP file is not available.']);
        }
        $filePath = $uploadDir ? realpath($uploadDir . DIRECTORY_SEPARATOR . $storedFile) : false;
        if (!$uploadDir || !$filePath || strpos($filePath, $uploadDir . DIRECTORY_SEPARATOR) !== 0 || !is_file($filePath)) {
            json_out(404, ['success' => false, 'message' => 'The original PPMP file is not available.']);
        }

        $downloadName = preg_replace('/[^A-Za-z0-9._-]+/', '_', (string)($record['file_name'] ?: 'PPMP.xlsx'));
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $downloadName . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }

    if ($method === 'POST' && $action === 'review') {
        if ($role !== 'Approver' && $role !== 'Admin') {
            json_out(403, ['success' => false, 'message' => 'Only approvers can review PPMPs']);
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: [];
        $id = (int)($input['id'] ?? 0);
        $status = (string)($input['status'] ?? '');
        $reason = trim((string)($input['reason'] ?? ''));
        $isEdit = !empty($input['edit']);

        if ($id <= 0 || !in_array($status, ['Approved', 'Rejected'], true)) {
            json_out(422, ['success' => false, 'message' => 'Invalid review payload']);
        }

        if ($status === 'Rejected' && $reason === '') {
            json_out(422, ['success' => false, 'message' => 'A rejection reason is required']);
        }

        $stmt = $pdo->prepare('SELECT * FROM ppmp_records WHERE id = ? LIMIT 1 FOR UPDATE');
        $pdo->beginTransaction();
        $stmt->execute([$id]);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$record) {
            $pdo->rollBack();
            json_out(404, ['success' => false, 'message' => 'PPMP not found']);
        }
        if (!$isEdit && $record['status'] !== 'Pending') {
            $pdo->rollBack();
            json_out(409, ['success' => false, 'message' => 'This PPMP has already been reviewed.']);
        }

        $update = $pdo->prepare(
            'UPDATE ppmp_records SET status = ?, reason = ?, reviewed_at = NOW(), reviewed_by = ? WHERE id = ?'
        );
        $update->execute([$status, $reason !== '' ? $reason : null, $_SESSION['username'], $id]);

        $wasApproved = $record['status'] === 'Approved';
        $isApproved = $status === 'Approved';
        if ($wasApproved !== $isApproved) {
            $itemsStmt = $pdo->prepare('SELECT id, item_name, unit, quantity FROM ppmp_items WHERE ppmp_id = ?');
            $itemsStmt->execute([$id]);
            $upsert = $pdo->prepare(
                'INSERT INTO requestor_inventory_items (province, item_name, unit, quantity_left) VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE quantity_left = quantity_left + VALUES(quantity_left), updated_at = CURRENT_TIMESTAMP'
            );
            $findInventory = $pdo->prepare('SELECT id, quantity_left FROM requestor_inventory_items WHERE province = ? AND item_name = ? AND unit = ? FOR UPDATE');
            $subtractInventory = $pdo->prepare('UPDATE requestor_inventory_items SET quantity_left = GREATEST(0, quantity_left - ?), updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $audit = $pdo->prepare(
                'INSERT INTO requestor_inventory_audit (province, inventory_item_id, ppmp_id, ppmp_file_name, requestor_name, item_name, unit, quantity_added, quantity_change, resulting_quantity, accepted_at, accepted_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)'
            );
            while ($item = $itemsStmt->fetch(PDO::FETCH_ASSOC)) {
                $quantity = (int)$item['quantity'];
                if ($quantity <= 0) continue;
                if ($isApproved) {
                    $upsert->execute([$record['province'], $item['item_name'], $item['unit'], $quantity]);
                }
                $findInventory->execute([$record['province'], $item['item_name'], $item['unit']]);
                $inventory = $findInventory->fetch(PDO::FETCH_ASSOC);
                if (!$inventory) {
                    throw new RuntimeException('Provincial inventory item not found while correcting this PPMP.');
                }
                if (!$isApproved) {
                    $subtractInventory->execute([$quantity, $inventory['id']]);
                    $findInventory->execute([$record['province'], $item['item_name'], $item['unit']]);
                    $inventory = $findInventory->fetch(PDO::FETCH_ASSOC);
                }
                $change = $isApproved ? $quantity : -$quantity;
                $added = $isApproved ? $quantity : 0;
                $audit->execute([
                    $record['province'], $inventory['id'], $id, $record['file_name'], $record['requestor_name'],
                    $item['item_name'], $item['unit'], $added, $change, $inventory['quantity_left'], $_SESSION['username']
                ]);
            }
        }

        if (strcasecmp((string)$record['status'], $status) !== 0) {
            $itemsStmt = $pdo->prepare('SELECT item_name, unit, quantity FROM ppmp_items WHERE ppmp_id = ?');
            $itemsStmt->execute([$id]);
            recordSystemActivity(
                $pdo,
                'ppmp_status_changed',
                'ppmp',
                $id,
                (string)$record['province'],
                'PPMP status changed to ' . $status,
                [
                    'from_status' => $record['status'],
                    'to_status' => $status,
                    'requestor_name' => $record['requestor_name'],
                    'reason' => $reason,
                    'items' => $itemsStmt->fetchAll(PDO::FETCH_ASSOC),
                ]
            );
        }

        $pdo->commit();

        json_out(200, ['success' => true, 'message' => 'PPMP reviewed successfully']);
    }

    if ($method === 'GET' && $action === 'inventory') {
        if ($role !== 'Requester' && $role !== 'Admin' && $role !== 'Approver') {
            json_out(403, ['success' => false, 'message' => 'Forbidden']);
        }
        $province = strtoupper(trim((string)($_SESSION['province'] ?? '')));
        if ($role === 'Requester' && $province === '') {
            json_out(422, ['success' => false, 'message' => 'Your account has no province assigned.']);
        }
        $stmt = $role === 'Requester'
            ? $pdo->prepare('SELECT id, item_name, unit, quantity_left, updated_at FROM requestor_inventory_items WHERE province = ? ORDER BY item_name, unit')
            : $pdo->query('SELECT id, province, item_name, unit, quantity_left, updated_at FROM requestor_inventory_items ORDER BY province, item_name, unit');
        if ($role === 'Requester') $stmt->execute([$province]);
        json_out(200, ['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC), 'province' => $province]);
    }

    if ($method === 'GET' && $action === 'audit') {
        $province = strtoupper(trim((string)($_SESSION['province'] ?? '')));
        if ($role === 'Requester' && $province === '') json_out(422, ['success' => false, 'message' => 'Your account has no province assigned.']);
        $requestedProvince = strtoupper(trim((string)($_GET['province'] ?? '')));
        if ($role === 'Approver' || $role === 'Admin') $province = $requestedProvince !== '' ? $requestedProvince : $province;
        $stmt = $province !== ''
            ? $pdo->prepare('SELECT * FROM requestor_inventory_audit WHERE province = ? ORDER BY accepted_at DESC, id DESC')
            : $pdo->query('SELECT * FROM requestor_inventory_audit ORDER BY accepted_at DESC, id DESC');
        if ($province !== '') $stmt->execute([$province]);
        json_out(200, ['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC), 'province' => $province]);
    }

    json_out(400, ['success' => false, 'message' => 'Invalid action']);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('PPMP API error: ' . $e->getMessage());
    json_out(500, ['success' => false, 'message' => 'The PPMP request could not be completed.']);
}
