<?php
// db_connect.php
// Use this file to connect to the login database from your PHP login scripts.

$projectRoot = dirname(__DIR__);
$envFile = $projectRoot . DIRECTORY_SEPARATOR . '.env';

if (is_file($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines !== false) {
        foreach ($lines as $line) {
            $trimmed = trim($line);
            if ($trimmed === '' || str_starts_with($trimmed, '#')) {
                continue;
            }

            $equalsPos = strpos($trimmed, '=');
            if ($equalsPos === false) {
                continue;
            }

            $key = trim(substr($trimmed, 0, $equalsPos));
            $value = trim(substr($trimmed, $equalsPos + 1));

            if ($key === '') {
                continue;
            }

            putenv($key . '=' . $value);
            $_ENV[$key] = $value;
            $_SERVER[$key] = $value;
        }
    }
}

$host = getenv('DOLE_DB_HOST') ?: '127.0.0.1';
$db   = getenv('DOLE_DB_NAME') ?: 'dole_ids_db';
$user = getenv('DOLE_DB_USER') ?: 'root';
$pass = getenv('DOLE_DB_PASSWORD') ?: '';
$charset = 'utf8mb4';
$seedDefaultAdmin = getenv('DOLE_SEED_DEFAULT_ADMIN') === '1';

if ($host === false || $db === false || $user === false || $pass === false) {
    jsonErrorExit('Missing required database environment variables. Set DOLE_DB_HOST, DOLE_DB_NAME, DOLE_DB_USER, and DOLE_DB_PASSWORD before starting the application.', 500);
}

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

function jsonErrorExit(string $message, int $statusCode = 500): void {
    error_log($message);
    $publicMessage = getenv('DOLE_DEBUG') === '1' ? $message : 'A server error occurred.';
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    http_response_code($statusCode);
    echo json_encode(['success' => false, 'message' => $publicMessage]);
    exit;
}

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    if ((string)$e->getCode() === '1049') {
        // Database does not exist yet. Create it, then create the users table.
        try {
            $pdo = new PDO("mysql:host=$host;charset=$charset", $user, $pass, $options);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db`");
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS `users` ("
                . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
                . "`username` VARCHAR(50) NOT NULL UNIQUE,"
                . "`password_hash` VARCHAR(255) NOT NULL,"
                . "`full_name` VARCHAR(100) NOT NULL,"
                . "`email` VARCHAR(100) DEFAULT NULL,"
                . "`role` ENUM('Admin','Approver','Requester','Delivery') NOT NULL DEFAULT 'Requester',"
                . "`province` VARCHAR(100) DEFAULT NULL,"
                . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                . "`last_login` DATETIME DEFAULT NULL,"
                . "PRIMARY KEY (`id`)"
                . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );

            if ($seedDefaultAdmin) {
                $defaultAdminUsername = getenv('DOLE_DEFAULT_ADMIN_USERNAME') ?: 'AdminFMD03';
                $defaultAdminPassword = getenv('DOLE_DEFAULT_ADMIN_PASSWORD') ?: 'Admin12345';
                $adminHash = password_hash($defaultAdminPassword, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare(
                    'INSERT INTO users (username, password_hash, full_name, email, role, province) VALUES (?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), full_name = VALUES(full_name), email = VALUES(email), role = VALUES(role), province = VALUES(province)'
                );
                $stmt->execute([$defaultAdminUsername, $adminHash, 'Admin FMD', 'admin@example.com', 'Admin', 'MANILA']);
            }
        } catch (PDOException $inner) {
            jsonErrorExit('Database initialization failed: ' . $inner->getMessage(), 500);
        }
    } else {
        jsonErrorExit('Database connection failed: ' . $e->getMessage(), 500);
    }
}

try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `system_activity_log` ("
        . "`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`event_type` VARCHAR(64) NOT NULL,"
        . "`entity_type` VARCHAR(64) NOT NULL,"
        . "`entity_id` VARCHAR(64) DEFAULT NULL,"
        . "`province` VARCHAR(100) DEFAULT NULL,"
        . "`actor_username` VARCHAR(100) DEFAULT NULL,"
        . "`actor_role` VARCHAR(32) DEFAULT NULL,"
        . "`summary` VARCHAR(500) NOT NULL,"
        . "`details_json` LONGTEXT DEFAULT NULL,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`), INDEX (`created_at`), INDEX (`province`, `created_at`),"
        . "INDEX (`entity_type`, `entity_id`), INDEX (`event_type`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (PDOException $e) {
    jsonErrorExit('Activity log initialization failed: ' . $e->getMessage(), 500);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (empty($_COOKIE['csrf_token']) || !hash_equals((string)$_SESSION['csrf_token'], (string)$_COOKIE['csrf_token'])) {
    $_COOKIE['csrf_token'] = (string)$_SESSION['csrf_token'];
    setcookie('csrf_token', $_SESSION['csrf_token'], [
        'expires' => time() + 3600,
        'path' => '/',
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => false,
    ]);
}

// Ensure the users table exists (DB may exist without the table).
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `users` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`username` VARCHAR(50) NOT NULL UNIQUE,"
        . "`password_hash` VARCHAR(255) NOT NULL,"
        . "`full_name` VARCHAR(100) NOT NULL,"
        . "`email` VARCHAR(100) DEFAULT NULL,"
        . "`role` ENUM('Admin','Approver','Requester','Delivery') NOT NULL DEFAULT 'Requester',"
        . "`province` VARCHAR(100) DEFAULT NULL,"
        . "`status` ENUM('Operational','Not Operational') NOT NULL DEFAULT 'Operational',"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`last_login` DATETIME DEFAULT NULL,"
        . "PRIMARY KEY (`id`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    if ($seedDefaultAdmin) {
        $defaultAdminUsername = getenv('DOLE_DEFAULT_ADMIN_USERNAME') ?: 'AdminFMD03';
        $defaultAdminPassword = getenv('DOLE_DEFAULT_ADMIN_PASSWORD') ?: 'Admin12345';
        $adminHash = password_hash($defaultAdminPassword, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            'INSERT INTO users (username, password_hash, full_name, email, role, province) VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), full_name = VALUES(full_name), email = VALUES(email), role = VALUES(role), province = VALUES(province)'
        );
        $stmt->execute([$defaultAdminUsername, $adminHash, 'Admin FMD', 'admin@example.com', 'Admin', 'MANILA']);
    }
} catch (PDOException $e) {
    jsonErrorExit('Database initialization failed: ' . $e->getMessage(), 500);
}

// Normalize users table schema only when needed.
// Avoid running expensive ALTER statements on every request.
try {
    $columnStmt = $pdo->query("SHOW COLUMNS FROM `users`");
    $columns = [];
    while ($row = $columnStmt->fetch()) {
        $columns[$row['Field']] = $row;
    }

    if (!isset($columns['full_name'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `full_name` VARCHAR(100) NOT NULL DEFAULT '' AFTER `password_hash`");
    }
    if (!isset($columns['province'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `province` VARCHAR(100) DEFAULT NULL AFTER `role`");
    }
    if (!isset($columns['status'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `status` ENUM('Operational','Not Operational') NOT NULL DEFAULT 'Operational' AFTER `province`");
    }
    if (!isset($columns['created_at'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `status`");
    }
    if (!isset($columns['last_login'])) {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `last_login` DATETIME DEFAULT NULL AFTER `created_at`");
    }

    // Only change enum if table still uses the legacy role set.
    if (isset($columns['role']) && strpos(strtolower((string)$columns['role']['Type']), 'user') !== false) {
        $pdo->exec("ALTER TABLE `users` CHANGE COLUMN `role` `role` ENUM('Admin','Approver','Requester','Delivery') NOT NULL DEFAULT 'Requester'");
        $pdo->exec("UPDATE `users` SET `role` = 'Requester' WHERE `role` = 'user'");
    }

    if (isset($columns['role']) && strpos((string)$columns['role']['Type'], 'Delivery') === false) {
        $pdo->exec("ALTER TABLE `users` CHANGE COLUMN `role` `role` ENUM('Admin','Approver','Requester','Delivery') NOT NULL DEFAULT 'Requester'");
    }

    if ($seedDefaultAdmin) {
        $defaultAdminUsername = getenv('DOLE_DEFAULT_ADMIN_USERNAME') ?: 'AdminFMD03';
        $defaultAdminPassword = getenv('DOLE_DEFAULT_ADMIN_PASSWORD') ?: 'Admin12345';
        $adminHash = password_hash($defaultAdminPassword, PASSWORD_DEFAULT);
        $defaultStmt = $pdo->prepare('UPDATE `users` SET `password_hash` = ?, `full_name` = ?, `email` = ?, `role` = ?, `province` = ? WHERE `username` = ?');
        $defaultStmt->execute([$adminHash, 'Admin FMD', 'admin@example.com', 'Admin', 'MANILA', $defaultAdminUsername]);

        $insertStmt = $pdo->prepare('INSERT IGNORE INTO `users` (`username`, `password_hash`, `full_name`, `email`, `role`, `province`) VALUES (?, ?, ?, ?, ?, ?)');
        $insertStmt->execute([$defaultAdminUsername, $adminHash, 'Admin FMD', 'admin@example.com', 'Admin', 'MANILA']);
    }

    $pdo->exec("UPDATE `users` SET `full_name` = 'Admin FMD' WHERE `username` = 'AdminFMD03' AND (`full_name` IS NULL OR `full_name` = '')");

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `login_attempts` ("
        . "`ip_address` VARCHAR(45) NOT NULL,"
        . "`attempts` INT UNSIGNED NOT NULL DEFAULT 0,"
        . "`window_started` DATETIME NOT NULL,"
        . "`locked_until` DATETIME DEFAULT NULL,"
        . "PRIMARY KEY (`ip_address`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (PDOException $e) {
    jsonErrorExit('Database schema repair failed: ' . $e->getMessage(), 500);
}

// --- INVENTORY TABLE (shared across portals) ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `inventory_items` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`category` VARCHAR(120) NOT NULL,"
        . "`stock` INT NOT NULL DEFAULT 0,"
        . "`unit` VARCHAR(50) NOT NULL DEFAULT 'pcs',"
        . "`min_stock` INT NOT NULL DEFAULT 0,"
        . "`last_modified` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`category`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $countStmt = $pdo->query("SELECT COUNT(*) AS c FROM `inventory_items`");
    $row = $countStmt->fetch();
    $count = (int)($row['c'] ?? 0);

    if ($count === 0) {
        $seed = [
            ['Black Ink Cartridges', 'Printer Supplies', 3, 'box', 10],
            ['Laser Toner', 'Printer Supplies', 5, 'cartridge', 8],
            ['Photo Paper', 'Printer Supplies', 12, 'pack', 20],
            ['Ballpoint Pens', 'Writing Supplies', 10, 'dozen', 40],
            ['Whiteboard Markers', 'Writing Supplies', 4, 'box', 30],
            ['Blue Ink Pens', 'Writing Supplies', 0, 'pack', 20],
            ['Gel Pens', 'Writing Supplies', 25, 'dozen', 30],
            ['Correction Fluid', 'Writing Supplies', 8, 'bottle', 15],
            ['Highlighters', 'Writing Supplies', 0, 'pack', 10],
            ['A4 Notebooks', 'Office Supplies', 5, 'dozen', 25],
            ['Paper Clips', 'Office Supplies', 50, 'box', 150],
            ['Staplers', 'Office Supplies', 0, 'pcs', 5],
            ['Binder Clips', 'Office Supplies', 18, 'box', 40],
            ['Desk Organizer', 'Office Supplies', 7, 'pcs', 10],
            ['Printer Paper', 'Paper Products', 0, 'ream', 20],
            ['Sticky Notes', 'Paper Products', 0, 'pack', 10],
            ['Manila Folders', 'Paper Products', 30, 'pack', 60],
            ['Notepads', 'Paper Products', 20, 'pad', 35],
        ];

        $ins = $pdo->prepare("INSERT INTO `inventory_items` (item_name, category, stock, unit, min_stock) VALUES (?, ?, ?, ?, ?)");
        foreach ($seed as $s) {
            $ins->execute($s);
        }
    }
} catch (PDOException $e) {
    jsonErrorExit('Inventory initialization failed: ' . $e->getMessage(), 500);
}

// Normalize inventory_items table schema to add unit column if missing.
try {
    $columnStmt = $pdo->query("SHOW COLUMNS FROM `inventory_items`");
    $columns = [];
    while ($row = $columnStmt->fetch()) {
        $columns[$row['Field']] = $row;
    }

    if (!isset($columns['unit'])) {
        $pdo->exec("ALTER TABLE `inventory_items` ADD COLUMN `unit` VARCHAR(50) NOT NULL DEFAULT 'pcs' AFTER `stock`");
        // Set appropriate units based on existing item names
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'box' WHERE `item_name` LIKE '%Cartridge%' OR `item_name` LIKE '%Ink%'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'cartridge' WHERE `item_name` = 'Laser Toner'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'pack' WHERE `item_name` IN ('Photo Paper', 'Blue Ink Pens', 'Gel Pens', 'Highlighters', 'Sticky Notes', 'Manila Folders')");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'dozen' WHERE `item_name` IN ('Ballpoint Pens', 'A4 Notebooks', 'Gel Pens')");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'box' WHERE `item_name` IN ('Whiteboard Markers', 'Paper Clips', 'Binder Clips')");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'bottle' WHERE `item_name` = 'Correction Fluid'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'ream' WHERE `item_name` = 'Printer Paper'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'pad' WHERE `item_name` = 'Notepads'");
        $pdo->exec("UPDATE `inventory_items` SET `unit` = 'pcs' WHERE `unit` = 'pcs' OR `unit` IS NULL");
    }
} catch (PDOException $e) {
    jsonErrorExit('Inventory schema repair failed: ' . $e->getMessage(), 500);
}

// --- REQUESTS TABLE ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `requests` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`quantity` INT NOT NULL,"
        . "`requestor` VARCHAR(100) NOT NULL,"
        . "`approver` VARCHAR(100) DEFAULT NULL,"
        . "`stock_status` ENUM('In Stock','Low Stock','Out of Stock') NOT NULL DEFAULT 'In Stock',"
        . "`status` ENUM('Pending','Approved','Declined') NOT NULL DEFAULT 'Pending',"
        . "`request_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`approved_date` DATETIME DEFAULT NULL,"
        . "`remarks` VARCHAR(255) DEFAULT NULL,"
        . "`note` TEXT DEFAULT NULL,"
        . "`item_details` TEXT DEFAULT NULL,"
        . "`ris_number` VARCHAR(32) DEFAULT NULL,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`status`),"
        . "INDEX (`request_date`),"
        . "INDEX (`requestor`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    // Seed sample requests if table is empty
    $countStmt = $pdo->query("SELECT COUNT(*) AS c FROM `requests`");
    $row = $countStmt->fetch();
    $count = (int)($row['c'] ?? 0);

    if ($count === 0) {
        $sampleRequests = [
            ['Sticky Notes', 12, 'Cavite', 'ApproverDonna', 'In Stock', 'Approved', '2026-02-10', '2026-02-10', 'In Stock', 'Ubos na lh.'],
            ['Ballpoint Pen (Black)', 8, 'Batangas', 'ApproverKurt', 'Low Stock', 'Pending', '2026-02-15', NULL, 'Low Stock', 'Need restock'],
            ['A4 Notebook', 45, 'Batangas', 'ApproverGab', 'In Stock', 'Approved', '2026-01-28', '2026-01-28', 'In Stock', 'Ubos na lh.'],
            ['Calculator', 5, 'Cavite', 'ApproverDonna', 'Low Stock', 'Pending', '2026-02-18', NULL, 'Low Stock', ''],
            ['Binder Clips', 5, 'Rizal', 'ApproverKurt', 'In Stock', 'Approved', '2026-01-20', '2026-01-20', 'In Stock', ''],
            ['Highlighter', 0, 'Rizal', 'ApproverGab', 'Out of Stock', 'Declined', '2026-01-30', '2026-01-30', 'Out of Stock', 'Declined by Kurt'],
            ['Ballpoint Pen (Black)', 30, 'Quezon', 'ApproverDonna', 'In Stock', 'Approved', '2026-02-05', '2026-02-05', 'In Stock', ''],
            ['Stapler', 0, 'Quezon', 'ApproverKurt', 'Out of Stock', 'Declined', '2026-01-25', '2026-01-25', 'Out of Stock', 'Declined by Kurt'],
            ['Folder (Expandable)', 6, 'Batangas', 'ApproverGab', 'Low Stock', 'Pending', '2026-02-12', NULL, 'Low Stock', ''],
            ['Bond Paper (Short)', 5, 'Cavite', 'ApproverDonna', 'Low Stock', 'Pending', '2026-02-10', NULL, 'Low Stock', 'Ubos na lh.'],
            ['Envelope (Long)', 30, 'Laguna', 'ApproverKurt', 'In Stock', 'Approved', '2026-02-08', '2026-02-08', 'In Stock', ''],
            ['Correction Tape', 4, 'Batangas', 'ApproverGab', 'Low Stock', 'Pending', '2026-02-11', NULL, 'Low Stock', ''],
            ['Printer Paper', 20, 'Cavite', 'ApproverDonna', 'Out of Stock', 'Approved', '2026-02-20', '2026-02-20', 'Out of Stock', '']
        ];

        $insReq = $pdo->prepare("INSERT INTO `requests` (item_name, quantity, requestor, approver, stock_status, status, request_date, approved_date, remarks, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($sampleRequests as $req) {
            $insReq->execute($req);
        }
    }
} catch (PDOException $e) {
    jsonErrorExit('Requests table initialization failed: ' . $e->getMessage(), 500);
}

try {
    $columnStmt = $pdo->query("SHOW COLUMNS FROM `requests`");
    $columns = [];
    while ($row = $columnStmt->fetch()) {
        $columns[$row['Field']] = $row;
    }

    if (!isset($columns['item_details'])) {
        $pdo->exec("ALTER TABLE `requests` ADD COLUMN `item_details` TEXT DEFAULT NULL AFTER `note`");
    }
    if (!isset($columns['ris_number'])) {
        $pdo->exec("ALTER TABLE `requests` ADD COLUMN `ris_number` VARCHAR(32) DEFAULT NULL AFTER `item_details`");
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `request_ris_sequences` ("
        . "`request_day` DATE NOT NULL,"
        . "`last_sequence` INT UNSIGNED NOT NULL DEFAULT 0,"
        . "PRIMARY KEY (`request_day`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pendingRis = $pdo->query(
        "SELECT id, DATE(request_date) AS request_day FROM requests WHERE ris_number IS NULL OR ris_number = '' ORDER BY request_date ASC, id ASC"
    );
    $dailySequence = [];
    $updateRis = $pdo->prepare('UPDATE requests SET ris_number = ? WHERE id = ? AND (ris_number IS NULL OR ris_number = \'\')');
    while ($request = $pendingRis->fetch(PDO::FETCH_ASSOC)) {
        $day = (string)$request['request_day'];
        $dailySequence[$day] = ($dailySequence[$day] ?? 0) + 1;
        $risNumber = 'RIS-' . str_replace('-', '', $day) . '-' . str_pad((string)$dailySequence[$day], 4, '0', STR_PAD_LEFT);
        $updateRis->execute([$risNumber, (int)$request['id']]);
    }

    $seedSequences = $pdo->query(
        "SELECT STR_TO_DATE(SUBSTRING(ris_number, 5, 8), '%Y%m%d') AS request_day,
                MAX(CAST(SUBSTRING_INDEX(ris_number, '-', -1) AS UNSIGNED)) AS last_sequence
         FROM requests
         WHERE ris_number REGEXP '^RIS-[0-9]{8}-[0-9]{4,}$'
         GROUP BY SUBSTRING(ris_number, 5, 8)"
    );
    $saveSequence = $pdo->prepare(
        'INSERT INTO request_ris_sequences (request_day, last_sequence) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE last_sequence = GREATEST(last_sequence, VALUES(last_sequence))'
    );
    foreach ($seedSequences as $sequence) {
        if (!empty($sequence['request_day'])) {
            $saveSequence->execute([$sequence['request_day'], (int)$sequence['last_sequence']]);
        }
    }

    $hasRisUniqueIndex = false;
    foreach ($pdo->query("SHOW INDEX FROM `requests`") as $index) {
        if ($index['Key_name'] === 'uq_requests_ris_number') {
            $hasRisUniqueIndex = true;
            break;
        }
    }
    if (!$hasRisUniqueIndex) {
        $pdo->exec("ALTER TABLE `requests` ADD UNIQUE KEY `uq_requests_ris_number` (`ris_number`)");
    }
} catch (PDOException $e) {
    jsonErrorExit('Requests schema repair failed: ' . $e->getMessage(), 500);
}

// --- PPMP TABLE ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `ppmp_records` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`requestor_id` INT UNSIGNED NOT NULL,"
        . "`requestor_name` VARCHAR(150) NOT NULL,"
        . "`province` VARCHAR(100) DEFAULT NULL,"
        . "`fiscal_year` VARCHAR(10) NOT NULL,"
        . "`status` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',"
        . "`reason` TEXT DEFAULT NULL,"
        . "`uploaded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`reviewed_at` DATETIME DEFAULT NULL,"
        . "`reviewed_by` VARCHAR(100) DEFAULT NULL,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`requestor_id`),"
        . "INDEX (`status`),"
        . "INDEX (`fiscal_year`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (PDOException $e) {
    jsonErrorExit('PPMP records table initialization failed: ' . $e->getMessage(), 500);
}

try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `ppmp_items` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`ppmp_id` INT UNSIGNED NOT NULL,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`unit` VARCHAR(100) NOT NULL DEFAULT 'pcs',"
        . "`quantity` INT NOT NULL DEFAULT 0,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`ppmp_id`),"
        . "INDEX (`item_name`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (PDOException $e) {
    jsonErrorExit('PPMP items table initialization failed: ' . $e->getMessage(), 500);
}

// PPMP metadata and the Requestor-only, province-scoped inventory.
try {
    $recordColumns = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `ppmp_records`") as $row) {
        $recordColumns[$row['Field']] = true;
    }
    if (!isset($recordColumns['file_name'])) {
        $pdo->exec("ALTER TABLE `ppmp_records` ADD COLUMN `file_name` VARCHAR(255) DEFAULT NULL AFTER `requestor_name`");
    }
    if (!isset($recordColumns['stored_file'])) {
        $pdo->exec("ALTER TABLE `ppmp_records` ADD COLUMN `stored_file` VARCHAR(255) DEFAULT NULL AFTER `file_name`");
    }

    $itemColumns = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `ppmp_items`") as $row) {
        $itemColumns[$row['Field']] = true;
    }
    if (!isset($itemColumns['unit'])) {
        $pdo->exec("ALTER TABLE `ppmp_items` ADD COLUMN `unit` VARCHAR(100) NOT NULL DEFAULT 'pcs' AFTER `item_name`");
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `requestor_inventory_items` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`province` VARCHAR(100) NOT NULL,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`unit` VARCHAR(100) NOT NULL,"
        . "`quantity_left` INT UNSIGNED NOT NULL DEFAULT 0,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "UNIQUE KEY `uq_requestor_inventory_province_item_unit` (`province`, `item_name`, `unit`),"
        . "INDEX (`province`), INDEX (`item_name`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `requestor_inventory_audit` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`province` VARCHAR(100) NOT NULL,"
        . "`inventory_item_id` INT UNSIGNED DEFAULT NULL,"
        . "`ppmp_id` INT UNSIGNED NOT NULL,"
        . "`ppmp_file_name` VARCHAR(255) DEFAULT NULL,"
        . "`requestor_name` VARCHAR(150) NOT NULL,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`unit` VARCHAR(100) NOT NULL,"
        . "`quantity_added` INT UNSIGNED NOT NULL,"
        . "`quantity_change` INT NOT NULL DEFAULT 0,"
        . "`resulting_quantity` INT UNSIGNED NOT NULL,"
        . "`accepted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`accepted_by` VARCHAR(100) NOT NULL,"
        . "PRIMARY KEY (`id`), INDEX (`province`), INDEX (`inventory_item_id`), INDEX (`ppmp_id`), INDEX (`item_name`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $auditColumns = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `requestor_inventory_audit`") as $row) {
        $auditColumns[$row['Field']] = true;
    }
    if (!isset($auditColumns['quantity_change'])) {
        $pdo->exec("ALTER TABLE `requestor_inventory_audit` ADD COLUMN `quantity_change` INT NOT NULL DEFAULT 0 AFTER `quantity_added`");
        $pdo->exec("UPDATE `requestor_inventory_audit` SET `quantity_change` = `quantity_added` WHERE `quantity_change` = 0 AND `quantity_added` > 0");
    }
} catch (PDOException $e) {
    jsonErrorExit('Requestor inventory initialization failed: ' . $e->getMessage(), 500);
}

// --- DELIVERY PACKAGES TABLE ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `delivery_packages` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`package_id` VARCHAR(50) NOT NULL UNIQUE,"
        . "`request_id` INT UNSIGNED DEFAULT NULL,"
        . "`office` VARCHAR(120) NOT NULL,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`status` ENUM('ready','picked','delivering','shipped','completed','cancelled','returned') NOT NULL DEFAULT 'ready',"
        . "`eta` VARCHAR(30) DEFAULT NULL,"
        . "`courier_name` VARCHAR(100) DEFAULT NULL,"
        . "`scanned_at` DATETIME DEFAULT NULL,"
        . "`delivered_at` DATETIME DEFAULT NULL,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "INDEX (`request_id`),"
        . "INDEX (`status`),"
        . "INDEX (`package_id`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `delivery_logs` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`package_id` VARCHAR(50) NOT NULL,"
        . "`request_id` INT UNSIGNED DEFAULT NULL,"
        . "`office` VARCHAR(120) NOT NULL,"
        . "`item_name` VARCHAR(150) NOT NULL,"
        . "`status` ENUM('ready','picked','delivering','shipped','completed','cancelled','returned') NOT NULL DEFAULT 'completed',"
        . "`eta` VARCHAR(30) DEFAULT NULL,"
        . "`courier_name` VARCHAR(100) DEFAULT NULL,"
        . "`scanned_at` DATETIME DEFAULT NULL,"
        . "`delivered_at` DATETIME DEFAULT NULL,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "`completed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "UNIQUE KEY `package_id` (`package_id`),"
        . "INDEX (`status`),"
        . "INDEX (`request_id`)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "ALTER TABLE `delivery_packages` MODIFY COLUMN `status` ENUM('ready','picked','delivering','shipped','completed','cancelled','returned') NOT NULL DEFAULT 'ready'"
    );
    $pdo->exec(
        "ALTER TABLE `delivery_logs` MODIFY COLUMN `status` ENUM('ready','picked','delivering','shipped','completed','cancelled','returned') NOT NULL DEFAULT 'completed'"
    );

    $packageColumns = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `delivery_packages`") as $column) {
        $packageColumns[$column['Field']] = true;
    }
    if (!isset($packageColumns['scan_code'])) {
        $pdo->exec("ALTER TABLE `delivery_packages` ADD COLUMN `scan_code` VARCHAR(40) DEFAULT NULL AFTER `package_id`");
    }

    $logColumns = [];
    foreach ($pdo->query("SHOW COLUMNS FROM `delivery_logs`") as $column) {
        $logColumns[$column['Field']] = true;
    }
    if (!isset($logColumns['scan_code'])) {
        $pdo->exec("ALTER TABLE `delivery_logs` ADD COLUMN `scan_code` VARCHAR(40) DEFAULT NULL AFTER `package_id`");
    }

    $missingCodes = $pdo->query("SELECT id FROM `delivery_packages` WHERE scan_code IS NULL OR scan_code = ''")->fetchAll(PDO::FETCH_COLUMN);
    $codeUpdate = $pdo->prepare("UPDATE `delivery_packages` SET scan_code = ? WHERE id = ?");
    foreach ($missingCodes as $packageId) {
        $codeUpdate->execute(['DLV-' . strtoupper(bin2hex(random_bytes(10))), $packageId]);
    }

    $countStmt = $pdo->query("SELECT COUNT(*) AS c FROM `delivery_packages`");
    $row = $countStmt->fetch();
    $count = (int)($row['c'] ?? 0);

    if ($count === 0) {
        $seedPackages = [
            ['PKG-1001', 1, 'Requestor Office', 'Bond Paper', 'ready', '09:15 AM', null, null, null],
            ['PKG-1002', 2, 'Supply Unit', 'Ballpen Set', 'ready', '09:45 AM', null, null, null],
            ['PKG-1003', 3, 'Admin Office', 'Folders', 'ready', '10:20 AM', null, null, null]
        ];

        $ins = $pdo->prepare(
            "INSERT INTO `delivery_packages` (package_id, scan_code, request_id, office, item_name, status, eta, courier_name, scanned_at, delivered_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        foreach ($seedPackages as $pkg) {
            array_splice($pkg, 1, 0, ['DLV-' . strtoupper(bin2hex(random_bytes(10)))]);
            $ins->execute($pkg);
        }
    }
} catch (PDOException $e) {
    jsonErrorExit('Delivery packages table initialization failed: ' . $e->getMessage(), 500);
}

// --- PASSWORD RESETS TABLE ---
try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `password_resets` ("
        . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
        . "`user_id` INT UNSIGNED NOT NULL,"
        . "`token_hash` CHAR(64) NOT NULL,"
        . "`expires_at` DATETIME NOT NULL,"
        . "`used_at` DATETIME DEFAULT NULL,"
        . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
        . "PRIMARY KEY (`id`),"
        . "UNIQUE KEY `token_hash` (`token_hash`),"
        . "INDEX (`user_id`),"
        . "INDEX (`expires_at`),"
        . "CONSTRAINT `fk_password_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
} catch (PDOException $e) {
    // Fallback without FK if users engine/charset mismatch blocks constraint creation.
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `password_resets` ("
            . "`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,"
            . "`user_id` INT UNSIGNED NOT NULL,"
            . "`token_hash` CHAR(64) NOT NULL,"
            . "`expires_at` DATETIME NOT NULL,"
            . "`used_at` DATETIME DEFAULT NULL,"
            . "`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
            . "PRIMARY KEY (`id`),"
            . "UNIQUE KEY `token_hash` (`token_hash`),"
            . "INDEX (`user_id`),"
            . "INDEX (`expires_at`)"
            . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (PDOException $inner) {
        jsonErrorExit('Password resets table initialization failed: ' . $inner->getMessage(), 500);
    }
}
