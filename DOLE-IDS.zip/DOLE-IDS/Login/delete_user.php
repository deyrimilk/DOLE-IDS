<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username']) || empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
$sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
$cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

if ($sessionToken === '' && $cookieToken !== '') {
    $_SESSION['csrf_token'] = $cookieToken;
    $sessionToken = $cookieToken;
}

if ($sessionToken === '' || $headerToken === '' || !hash_equals($sessionToken, $headerToken)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');

if (!$username) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username is required']);
    exit;
}

if ($username === $_SESSION['username']) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'You cannot delete the currently logged-in account']);
    exit;
}

require_once 'db_connect.php';
require_once __DIR__ . '/activity_log.php';

try {
    $beforeStmt = $pdo->prepare('SELECT id, username, full_name, email, role, province, status FROM users WHERE username = ? LIMIT 1');
    $beforeStmt->execute([$username]);
    $before = $beforeStmt->fetch(PDO::FETCH_ASSOC);
    if (!$before) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    $stmt = $pdo->prepare('DELETE FROM users WHERE username = ?');
    $stmt->execute([$username]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    recordSystemActivity($pdo, 'user_deleted', 'user', $before['id'], $before['province'], 'User account deleted', $before);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not delete user']);
}
