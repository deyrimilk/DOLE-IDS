<?php
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
require_once 'db_connect.php';

$error = '';
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$resetRow = null;

function findValidReset(PDO $pdo, string $token): ?array
{
    if ($token === '' || !preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }

    $tokenHash = hash('sha256', $token);
    $stmt = $pdo->prepare(
        'SELECT pr.id, pr.user_id, pr.expires_at, pr.used_at, u.username
         FROM password_resets pr
         INNER JOIN users u ON u.id = pr.user_id
         WHERE pr.token_hash = ?
         LIMIT 1'
    );
    $stmt->execute([$tokenHash]);
    $row = $stmt->fetch();

    if (!$row || $row['used_at'] !== null) {
        return null;
    }

    if (strtotime($row['expires_at']) < time()) {
        return null;
    }

    return $row;
}

$resetRow = findValidReset($pdo, $token);

if (!$resetRow) {
    $error = 'This reset link is invalid or has expired. Please request a new one.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $resetRow) {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($password === '' || $confirm === '') {
        $error = 'Please enter and confirm your new password.';
    } elseif (strlen($password) < 8) {
        $error = 'New password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $pdo->beginTransaction();
        try {
            $updateUser = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
            $updateUser->execute([$passwordHash, $resetRow['user_id']]);

            $markUsed = $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = ?');
            $markUsed->execute([$resetRow['id']]);

            $pdo->prepare(
                'UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL'
            )->execute([$resetRow['user_id']]);

            $pdo->commit();

            $_SESSION['flash_message'] = 'Password updated successfully. You can now log in.';
            header('Location: login.php');
            exit;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $error = 'Could not update password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset Password</title>
<link rel="stylesheet" href="Login.css?v=logo-fill-20260929">
</head>
<body>

<div class="background"></div>
<div class="bg-logo">
    <img src="../Images/LOGO%20BG.png" alt="Background Logo">
</div>

<div class="login-shell">
    <div class="login-card">
        <div class="brand-panel">
            <img class="brand-logo" src="../Images/LOGO.png" alt="DOLE Logo">
        </div>

        <div class="form-panel">
            <h2>Reset password</h2>
            <?php if ($resetRow): ?>
                <p class="form-subtitle">Choose a new password for <strong><?php echo htmlspecialchars($resetRow['username']); ?></strong>.</p>
            <?php else: ?>
                <p class="form-subtitle">Your reset link could not be verified.</p>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($resetRow): ?>
            <form method="post" action="reset_password.php">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">

                <label class="field-label" for="password">New password</label>
                <div class="input-group">
                    <input id="password" type="password" name="password" placeholder="New password" minlength="8" required autofocus>
                    <span class="show-pass" title="Show/Hide password">👁</span>
                </div>

                <label class="field-label" for="confirm_password">Confirm password</label>
                <div class="input-group">
                    <input id="confirm_password" type="password" name="confirm_password" placeholder="Confirm password" minlength="8" required>
                    <span class="show-pass" title="Show/Hide password">👁</span>
                </div>

                <button type="submit" class="login-btn">UPDATE PASSWORD</button>
            </form>
            <?php else: ?>
                <a class="login-btn auth-btn-link" href="forgot_password.php">REQUEST NEW LINK</a>
            <?php endif; ?>

            <p class="auth-link"><a href="login.php">Back to login</a></p>
            <p class="panel-footer">© 2026 DOLE.</p>
        </div>
    </div>
</div>

<script src="Login.js"></script>

</body>
</html>
