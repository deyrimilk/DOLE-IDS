<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
require_once __DIR__ . '/db_connect.php';

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
$sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
$cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

if ($sessionToken === '' && $cookieToken !== '') {
    $_SESSION['csrf_token'] = $cookieToken;
    $sessionToken = $cookieToken;
}

if ($sessionToken === '' || $headerToken === '' || !hash_equals($sessionToken, $headerToken)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

$username = $_SESSION['username'];
if (!preg_match('/^[A-Za-z0-9_-]{3,50}$/', $username)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Account username is not valid for file storage']);
    exit;
}
if (empty($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'No avatar uploaded']);
    exit;
}

if ((int)$_FILES['avatar']['size'] > 5 * 1024 * 1024) {
    http_response_code(413);
    echo json_encode(['success' => false, 'message' => 'Avatar must be 5MB or smaller']);
    exit;
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['avatar']['tmp_name']);
$mimeToExtension = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/gif' => 'gif', 'image/webp' => 'webp'];
if (!isset($mimeToExtension[$mime])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Unsupported image type']);
    exit;
}
$ext = $mimeToExtension[$mime];

$uploadDir = dirname(__DIR__) . '/Images/avatars';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$dest = $uploadDir . "/avatar_{$username}.{$ext}";
if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $dest)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to save file']);
    exit;
}

$baseWeb = dirname(dirname($_SERVER['SCRIPT_NAME'])); // /SYSTEM
$url = "{$baseWeb}/Images/avatars/avatar_{$username}.{$ext}";
// persist avatar path in DB (add column if missing)
try {
    $colCheck = $pdo->query("SHOW COLUMNS FROM users LIKE 'avatar'");
    $exists = $colCheck->fetch();
    if (!$exists) {
        $pdo->exec("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL AFTER email");
    }
    $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE username = ?");
    $dbPath = "Images/avatars/avatar_{$username}.{$ext}";
    $stmt->execute([$dbPath, $username]);
} catch (PDOException $e) {
    // non-fatal; continue returning url
}

echo json_encode(['success' => true, 'url' => $url]);

?>
