<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username']) || strcasecmp((string)($_SESSION['role'] ?? ''), 'Admin') !== 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once 'db_connect.php';

try {
    // include avatar column if exists
    $cols = 'id, username, full_name, email, role, province, last_login, created_at';
    $colCheck = $pdo->query("SHOW COLUMNS FROM users LIKE 'avatar'");
    if ($colCheck && $colCheck->fetch()) {
        $cols .= ', avatar';
    }
    $colCheckStatus = $pdo->query("SHOW COLUMNS FROM users LIKE 'status'");
    if ($colCheckStatus && $colCheckStatus->fetch()) {
        $cols .= ', status';
    }
    $stmt = $pdo->query("SELECT {$cols} FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll();
    // attach avatar url: prefer DB avatar, fallback to file detection
    $baseWeb = dirname(dirname($_SERVER['SCRIPT_NAME']));
    foreach ($users as &$u) {
        $uname = $u['username'] ?? '';
        $found = null;
        if (!empty($u['avatar'])) {
            $found = rtrim($baseWeb, '/') . '/' . ltrim($u['avatar'], '/');
        } else {
            $possible = ['png','jpg','jpeg','gif','webp'];
            foreach ($possible as $ext) {
                $rel = __DIR__ . "/../Images/avatars/avatar_{$uname}.{$ext}";
                if (file_exists($rel)) {
                    $found = "{$baseWeb}/Images/avatars/avatar_{$uname}.{$ext}";
                    break;
                }
            }
        }
        $u['avatar'] = $found;
    }

    echo json_encode(['success' => true, 'data' => $users]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to fetch users: ' . $e->getMessage()]);
}
