<?php
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
require_once 'db_connect.php';

$error = '';
$message = '';
$username = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($username === '' || $email === '') {
        $error = 'Please enter both username and email.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = $pdo->prepare(
            'SELECT id FROM users WHERE username = ? AND LOWER(email) = LOWER(?) LIMIT 1'
        );
        $stmt->execute([$username, $email]);
        $user = $stmt->fetch();

        if (!$user) {
            $message = 'If the details match an account, reset instructions will be provided.';
        } else {
            // Invalidate any unused tokens for this user.
            $pdo->prepare(
                'UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL'
            )->execute([$user['id']]);

            $token = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $token);
            $expiresAt = (new DateTimeImmutable('+1 hour'))->format('Y-m-d H:i:s');

            $insert = $pdo->prepare(
                'INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)'
            );
            $insert->execute([$user['id'], $tokenHash, $expiresAt]);

            header('Location: reset_password.php?token=' . urlencode($token));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password</title>
<link rel="stylesheet" href="Login.css?v=logo-fill-20260929">
</head>
<body>

<div class="background"></div>
<div class="bg-logo">
    <img src="../Images/LOGO%20BG.png" alt="Background Logo">
</div>

<div class="login-shell">
    <div class="login-card">
        <div class="brand-panel">
            <img class="brand-logo" src="../Images/LOGO.png" alt="DOLE Logo">
        </div>

        <div class="form-panel">
            <h2>Forgot password</h2>
            <p class="form-subtitle">Enter your username and registered email to reset your password.</p>

            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($message): ?>
                <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <form method="post" action="forgot_password.php">
                <label class="field-label" for="username">Username</label>
                <div class="input-group">
                    <input id="username" type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($username); ?>" required autofocus>
                </div>

                <label class="field-label" for="email">Email</label>
                <div class="input-group">
                    <input id="email" type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>

                <button type="submit" class="login-btn">CONTINUE</button>
            </form>

            <p class="auth-link"><a href="login.php">Back to login</a></p>
            <p class="panel-footer">© 2026 DOLE.</p>
        </div>
    </div>
</div>

</body>
</html>
