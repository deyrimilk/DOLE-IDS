<?php

function recordSystemActivity(
    PDO $pdo,
    string $eventType,
    string $entityType,
    string|int|null $entityId,
    ?string $province,
    string $summary,
    array $details = []
): void {
    $actorUsername = trim((string)($_SESSION['username'] ?? ''));
    $actorRole = trim((string)($_SESSION['role'] ?? ''));
    $encodedDetails = $details
        ? json_encode($details, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE)
        : null;

    if ($details && $encodedDetails === false) {
        throw new RuntimeException('Could not encode activity details.');
    }

    $stmt = $pdo->prepare(
        'INSERT INTO system_activity_log
            (event_type, entity_type, entity_id, province, actor_username, actor_role, summary, details_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $eventType,
        $entityType,
        $entityId !== null ? (string)$entityId : null,
        $province !== null && trim($province) !== '' ? strtoupper(trim($province)) : null,
        $actorUsername !== '' ? $actorUsername : null,
        $actorRole !== '' ? $actorRole : null,
        $summary,
        $encodedDetails,
    ]);
}