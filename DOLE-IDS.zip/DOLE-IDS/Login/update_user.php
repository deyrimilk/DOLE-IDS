<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username']) || empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
$sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
$cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

if ($sessionToken === '' && $cookieToken !== '') {
    $_SESSION['csrf_token'] = $cookieToken;
    $sessionToken = $cookieToken;
}

if ($sessionToken === '' || $headerToken === '' || !hash_equals($sessionToken, $headerToken)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid payload']);
    exit;
}

$username = trim((string)($input['username'] ?? ''));
$email = trim((string)($input['email'] ?? ''));
$fullname = trim((string)($input['fullname'] ?? ''));
$role = trim((string)($input['role'] ?? ''));
$province = trim((string)($input['province'] ?? ''));
$password = isset($input['password']) ? (string)$input['password'] : '';

if ($username === '' || $email === '' || $fullname === '' || $role === '' || $province === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All editable fields are required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || stripos($email, '@gmail.com') === false) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid Gmail address']);
    exit;
}

$validRoles = ['Admin', 'Approver', 'Requester', 'Delivery'];
if (!in_array($role, $validRoles, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid role']);
    exit;
}

require_once 'db_connect.php';
require_once __DIR__ . '/activity_log.php';

try {
    $beforeStmt = $pdo->prepare('SELECT id, full_name, email, role, province, status FROM users WHERE username = ? LIMIT 1');
    $beforeStmt->execute([$username]);
    $before = $beforeStmt->fetch(PDO::FETCH_ASSOC);
    if (!$before) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    $sql = 'UPDATE users SET full_name = ?, email = ?, role = ?, province = ?';
    $params = [$fullname, $email, $role, $province];

    if (isset($input['status']) && $input['status'] !== '') {
        $status = trim((string)$input['status']);
        $validStatuses = ['Operational', 'Not Operational'];
        if (!in_array($status, $validStatuses, true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid status value']);
            exit;
        }
        $sql .= ', status = ?';
        $params[] = $status;
    }

    if ($password !== '') {
        if (strlen($password) < 8) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters']);
            exit;
        }
        $sql .= ', password_hash = ?';
        $params[] = password_hash($password, PASSWORD_DEFAULT);
    }

    $sql .= ' WHERE username = ?';
    $params[] = $username;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }

    recordSystemActivity($pdo, 'user_updated', 'user', $before['id'], $province, 'User account updated', [
        'username' => $username,
        'before' => $before,
        'after' => [
            'full_name' => $fullname,
            'email' => $email,
            'role' => $role,
            'province' => $province,
            'status' => $status ?? $before['status'],
            'password_changed' => $password !== '',
        ],
    ]);

    echo json_encode(['success' => true, 'message' => 'User updated successfully']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not update user']);
}
