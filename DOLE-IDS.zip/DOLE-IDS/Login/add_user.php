<?php
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username']) || empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
$sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
$cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

if ($sessionToken === '' && $cookieToken !== '') {
    $_SESSION['csrf_token'] = $cookieToken;
    $sessionToken = $cookieToken;
}

if ($sessionToken === '' || $headerToken === '' || !hash_equals($sessionToken, $headerToken)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');
$password = $input['password'] ?? '';
$email = trim($input['email'] ?? '');
$fullname = trim($input['fullname'] ?? '');
$role = trim($input['role'] ?? '');
$province = trim($input['province'] ?? '');

if (!$username || !$password || !$email || !$fullname || !$role || !$province) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

if (!preg_match('/^[A-Za-z0-9_-]{3,50}$/', $username)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username must contain only letters, numbers, underscores, or hyphens']);
    exit;
}

if (strlen($password) < 8) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || stripos($email, '@gmail.com', -10) === false) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid Gmail address']);
    exit;
}

$validRoles = ['Admin', 'Approver', 'Requester', 'Delivery'];
if (!in_array($role, $validRoles, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid role']);
    exit;
}

require_once 'db_connect.php';
require_once __DIR__ . '/activity_log.php';

try {
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, full_name, email, role, province) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$username, $passwordHash, $fullname, $email, $role, $province]);
    $userId = $pdo->lastInsertId();
    recordSystemActivity($pdo, 'user_created', 'user', $userId, $province, 'User account created', [
        'username' => $username,
        'full_name' => $fullname,
        'email' => $email,
        'role' => $role,
    ]);

    $stmt = $pdo->prepare('SELECT id, username, full_name, email, role, province, last_login, created_at FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    echo json_encode(['success' => true, 'data' => $user]);
} catch (PDOException $e) {
    if ($e->errorInfo[1] === 1062) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Username already exists']);
        exit;
    }

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to add user']);
}
