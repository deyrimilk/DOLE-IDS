<?php
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
require_once 'db_connect.php';
require_once __DIR__ . '/activity_log.php';

$error = '';
$success = '';

if (!empty($_SESSION['flash_message'])) {
    $success = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $ipAddress = substr((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45);
    $maxAttempts = 5;
    $windowSeconds = 300;
    $isRateLimited = false;

    try {
        $attemptStmt = $pdo->prepare('SELECT attempts, window_started, locked_until FROM login_attempts WHERE ip_address = ? LIMIT 1');
        $attemptStmt->execute([$ipAddress]);
        $attemptRecord = $attemptStmt->fetch();
        if ($attemptRecord && !empty($attemptRecord['locked_until']) && strtotime($attemptRecord['locked_until']) > time()) {
            $isRateLimited = true;
        }
    } catch (PDOException $e) {
        error_log('Login rate-limit lookup failed: ' . $e->getMessage());
    }

    if ($isRateLimited) {
        $error = 'Too many failed login attempts. Please wait 5 minutes before trying again.';
    } elseif ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $pdo->prepare('SELECT id, username, password_hash, role, full_name, email, province, status FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && strcasecmp((string)($user['status'] ?? 'Operational'), 'Operational') !== 0) {
            $error = 'This account is not operational.';
        } elseif ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_COOKIE['csrf_token'] = $_SESSION['csrf_token'];
            setcookie('csrf_token', $_SESSION['csrf_token'], [
                'expires' => time() + 3600,
                'path' => '/',
                'samesite' => 'Lax',
                'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                'httponly' => false,
            ]);

            $updateStmt = $pdo->prepare('UPDATE users SET last_login = NOW() WHERE id = ?');
            $updateStmt->execute([$user['id']]);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email'] = $user['email'] ?? '';
            $_SESSION['province'] = $user['province'] ?? '';
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            recordSystemActivity($pdo, 'user_login', 'user', (int)$user['id'], (string)($user['province'] ?? ''), 'User signed in', [
                'role' => $user['role'],
            ]);
            $_SESSION['flash_message'] = 'Welcome, ' . $user['full_name'];
            $pdo->prepare('DELETE FROM login_attempts WHERE ip_address = ?')->execute([$ipAddress]);

            if (strcasecmp($user['role'], 'Admin') === 0) {
                header('Location: ../Index/ADMIN/Admin.php');
            } elseif (strcasecmp($user['role'], 'Approver') === 0) {
                header('Location: ../Index/SUPPLY/Central.php');
            } elseif (strcasecmp($user['role'], 'Delivery') === 0) {
                header('Location: ../Index/DELIVERY/DELI.php');
            } elseif (strcasecmp($user['role'], 'Requester') === 0) {
                header('Location: ../Index/REQUESTOR/REQ.php');
            } else {
                header('Location: login.php');
            }
            exit;
        }

        try {
            $attemptStmt = $pdo->prepare('SELECT attempts, window_started FROM login_attempts WHERE ip_address = ? LIMIT 1');
            $attemptStmt->execute([$ipAddress]);
            $attemptRecord = $attemptStmt->fetch();
            $windowStart = $attemptRecord ? strtotime($attemptRecord['window_started']) : false;
            $attempts = $attemptRecord && $windowStart !== false && (time() - $windowStart) < $windowSeconds
                ? (int)$attemptRecord['attempts'] + 1
                : 1;
            $lockedUntil = $attempts >= $maxAttempts ? date('Y-m-d H:i:s', time() + $windowSeconds) : null;
            $upsert = $pdo->prepare(
                'INSERT INTO login_attempts (ip_address, attempts, window_started, locked_until) VALUES (?, ?, NOW(), ?) '
                . 'ON DUPLICATE KEY UPDATE attempts = VALUES(attempts), window_started = IF(VALUES(locked_until) IS NULL AND window_started < DATE_SUB(NOW(), INTERVAL 5 MINUTE), NOW(), window_started), locked_until = VALUES(locked_until)'
            );
            $upsert->execute([$ipAddress, $attempts, $lockedUntil]);
        } catch (PDOException $e) {
            error_log('Login rate-limit update failed: ' . $e->getMessage());
        }
        $error = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link rel="stylesheet" href="Login.css?v=logo-fill-20260929">
</head>

<body>

<div class="background"></div>
<div class="bg-logo">
    <img src="../Images/LOGO%20BG.png" alt="Background Logo">
</div>

<div class="login-shell">
    <div class="login-card">
        <div class="brand-panel">
            <img class="brand-logo" src="../Images/LOGO.png" alt="DOLE Logo">
        </div>

        <div class="form-panel">
            <h2>Welcome back!</h2>
            <p class="form-subtitle">Please enter your details.</p>

            <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="post" action="login.php">
                <label class="field-label" for="username">Username</label>
                <div class="input-group">
                    <input id="username" type="text" name="username" placeholder="Username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" required>
                </div>

                <label class="field-label" for="password">Password</label>
                <div class="input-group">
                    <input id="password" type="password" name="password" placeholder="Password" required>
                    <span class="show-pass" title="Show/Hide password">👁</span>
                </div>

                <div class="options">
                    <label>
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                    <a href="forgot_password.php">Forgot Password?</a>
                </div>

                <button type="submit" class="login-btn">LOGIN</button>
            </form>

            <p class="panel-footer">© 2026 DOLE.</p>
        </div>
    </div>
</div>

<script src="Login.js"></script>

</body>
</html>
