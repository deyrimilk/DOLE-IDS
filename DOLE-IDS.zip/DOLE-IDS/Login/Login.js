document.querySelectorAll(".show-pass").forEach((showPass) => {
  showPass.addEventListener("click", () => {
    const input = showPass.parentElement.querySelector("input");
    if (!input) return;

    if (input.type === "password") {
      input.type = "text";
    } else {
      input.type = "password";
    }
  });
});
