// --- CENTRAL DATA ---
let inventoryData = [];
let requestsData = [];
let ppmpData = [];
let knownPpmpIds = new Set();
let ppmpDataInitialized = false;
let inventoryFilter = 'all';
let inventorySort = 'default';
let catalogFilter = 'all';
let approvalsTab = 'all';
let approvalsSort = 'newest';
let approvalsOfficeFilter = 'all';
let historyStartDate = '';
let historyEndDate = '';
let deliveryFilter = 'all';
let deliverySort = 'newest';
let deliveryOfficeFilter = 'all';
let deliveryHistoryStartDate = '';
let deliveryHistoryEndDate = '';
let ppmpYear = 'all';
let ppmpOffice = 'all';
let ppmpUnit = 'all';

const DELIVERY_STORAGE_KEY = 'central_delivery_meta_v1';

// --- NAVIGATION ---
const navItems = document.querySelectorAll(".nav li, .nav-logout li");
const pages = document.querySelectorAll(".page");
const userRole = String(window.currentUserRole || '').toLowerCase();
const canManageInventory = userRole === 'approver';
const canViewInventory = userRole === 'approver' || userRole === 'requester';

function deriveAppRoot() {
    return new URL('../../', window.location.href).pathname.replace(/\/$/, '');
}
const appRoot = deriveAppRoot();
const inventoryApiBase = `${window.location.origin}${appRoot}/Inventory/inventory.php`;
const requestsApiBase = `${window.location.origin}${appRoot}/Requests/requests.php`;
const deliveryApiBase = `${window.location.origin}${appRoot}/Index/DELIVERY/delivery_api.php`;
const ppmpApiBase = `${window.location.origin}${appRoot}/ppmp/ppmp_api.php`;

function getCsrfToken() {
    const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : '';
}

function withCsrfHeaders(headers = {}) {
    return {
        ...headers,
        'X-CSRF-Token': getCsrfToken()
    };
}

function publishNotification(payload) {
    try {
        const notification = {
            type: payload.type || 'info',
            title: payload.title || 'Notification',
            message: payload.message || '',
            requestId: payload.requestId || null,
            packageId: payload.packageId || null,
            status: payload.status || null,
            source: payload.source || 'supply',
            updatedAt: new Date().toISOString()
        };
        localStorage.setItem('dole_notification_v1', JSON.stringify(notification));
    } catch (error) {
        console.warn('Could not publish notification.', error);
    }
}

const titleMap = {
    dashboard: { title: 'Dashboard', subtitle: 'View system summaries and recent activities' },
    inventory: { title: 'Inventory', subtitle: 'View and maintain inventory item records' },
    catalog: { title: 'Catalog Management', subtitle: 'Manage and organize displayed supply items' },
    notifications: { title: 'Notifications', subtitle: 'Stay updated on requests and stock alerts' },
    approvals: { title: 'Request Approvals', subtitle: 'Review, approve, or reject submitted item requests' },
    history: { title: 'Request History', subtitle: 'Review requests submitted more than one week ago' },
    deliveryHistory: { title: 'Delivery History', subtitle: 'Review deliveries completed or recorded more than one week ago' },
    ppmp: { title: 'PPMP Management', subtitle: 'View and manage PPMP records by office and fiscal year' },
    delivery: { title: 'Delivery', subtitle: 'Manage item deliveries and track delivery status' },
    profile: { title: 'Profile', subtitle: 'View and manage your account information' }
};

navItems.forEach(item => {
    item.onclick = () => {
        if (item.dataset.page === 'logout') logout();
        else showPage(item.dataset.page);
    };
});

function showPage(pageId) {
    pages.forEach(p => p.classList.remove("active"));
    navItems.forEach(n => n.classList.remove("active"));
    closeAllMenus();

    if (pageId === 'inventory' && !canViewInventory) pageId = 'dashboard';
    if (!document.getElementById(pageId)) pageId = 'dashboard';

    document.getElementById(pageId).classList.add("active");
    document.querySelector(`.nav li[data-page="${pageId}"]`)?.classList.add("active");

    const meta = titleMap[pageId] || { title: pageId, subtitle: '' };
    document.getElementById("page-title").textContent = meta.title;
    const subtitleEl = document.getElementById("page-subtitle");
    if (subtitleEl) subtitleEl.textContent = meta.subtitle;

    if (pageId === 'dashboard') initDashboard();
    if (pageId === 'inventory') renderInventory(inventoryFilter);
    if (pageId === 'catalog') renderCatalog();
    if (pageId === 'approvals') renderApprovals(approvalsTab);
    if (pageId === 'history') renderRequestHistory();
    if (pageId === 'delivery') renderDelivery(deliveryFilter);
    if (pageId === 'deliveryHistory') renderDeliveryHistory();
    if (pageId === 'ppmp') fetchPpmpData();
    if (pageId === 'notifications') {
        renderNotifications();
        fetchPpmpData().then(renderNotifications);
    }
    if (pageId === 'profile') renderAccountSettings();
}

function showToast(message, type = 'success') {
    let toast = document.getElementById('toastMessage');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toastMessage';
        toast.className = 'toast-message';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = `toast-message toast-${type} show`;
    clearTimeout(toast.hideTimer);
    toast.hideTimer = setTimeout(() => {
        toast.className = `toast-message toast-${type}`;
    }, 3200);
}

function updateClock() {
    const el = document.getElementById('clock');
    if (!el) return;
    el.textContent = new Date().toLocaleString('en-US', {
        weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
setInterval(updateClock, 1000);

function pad2(n) { return String(n).padStart(2, '0'); }

function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function capitalize(s) {
    return String(s || '').charAt(0).toUpperCase() + String(s || '').slice(1);
}

function fetchDeliveryPackages() {
    return fetch(`${deliveryApiBase}?action=list`, { credentials: 'include' })
        .then(async response => {
            if (!response.ok) throw new Error(`Unable to load delivery packages (HTTP ${response.status})`);
            const data = await response.json();
            if (!data.success) throw new Error(data.message || 'Unable to load delivery packages');
            deliveryPackages = {};
            if (Array.isArray(data.data)) {
                data.data.forEach((row) => {
                    const pkgId = String(row.package_id || row.id || '').trim();
                    if (!pkgId) return;
                    deliveryPackages[pkgId.toUpperCase()] = row;
                });
            }
        })
        .catch((err) => {
            console.warn('Could not sync delivery packages.', err);
            deliveryPackages = {};
        });
}

function translateDeliveryToSupplyStatus(status) {
    const value = String(status || '').toLowerCase();
    if (value === 'ready') return 'preparing';
    if (value === 'picked' || value === 'delivering' || value === 'shipped') return 'shipped';
    if (value === 'completed') return 'delivered';
    if (value === 'cancelled') return 'cancelled';
    if (value === 'returned') return 'returned';
    return 'preparing';
}

function translateSupplyToDeliveryStatus(status) {
    const value = String(status || '').toLowerCase();
    if (value === 'preparing') return 'ready';
    if (value === 'shipped') return 'shipped';
    if (value === 'delivered') return 'completed';
    if (value === 'cancelled') return 'cancelled';
    if (value === 'returned') return 'returned';
    return null;
}

async function updateDeliveryPackageStatus(packageId, status) {
    if (!packageId || !status) return null;
    try {
        const requestId = Number(String(packageId).replace(/^PKG-/i, '')) || null;
        const body = { id: packageId, status };
        if (requestId && !Number.isNaN(requestId)) {
            body.request_id = requestId;
        }
        const response = await fetch(`${deliveryApiBase}?action=update_status`, {
            method: 'POST',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            credentials: 'include',
            body: JSON.stringify(body)
        });
        const payload = await response.json();
        if (!response.ok || !payload.success) throw new Error(payload.message || 'Unable to update delivery package status');
        await fetchDeliveryPackages();
        publishNotification({
            type: 'delivery_status',
            title: `Delivery ${packageId}`,
            message: `Delivery ${packageId} status changed to ${status}.`, 
            packageId,
            requestId,
            status,
            source: 'supply'
        });
        return payload.data || null;
    } catch (err) {
        console.warn('Delivery package status update failed.', err);
        return null;
    }
}

function getPackageIdForRequest(requestId) {
    return `PKG-${requestId}`;
}

function getDeliveryRecordForRequest(requestId) {
    return deliveryPackages[getPackageIdForRequest(requestId).toUpperCase()] || null;
}

function getDeliveryDriverText(record) {
    return String(record?.courier_name || record?.driver || '').trim() || '—';
}

function getDeliveryNoteText(status) {
    if (status === 'preparing') return 'Please prepare soon';
    if (status === 'shipped') return 'Out for delivery';
    if (status === 'delivered') return 'Delivery completed';
    if (status === 'cancelled') return 'Delivery cancelled';
    if (status === 'returned') return 'Delivery returned';
    return '';
}

function getDeliveryStatusText(status) {
    if (!status) return 'preparing';
    return status;
}

function getDeliveryMetaStatus(savedStatus, deliveryRecord) {
    if (deliveryRecord) {
        return translateDeliveryToSupplyStatus(deliveryRecord.status);
    }
    return savedStatus || 'preparing';
}

function getDeliveryMetaDriver(savedDriver, deliveryRecord) {
    return deliveryRecord?.courier_name || savedDriver || '—';
}

function getDeliveryMetaNote(savedNote, status, deliveryRecord) {
    return savedNote || getDeliveryNoteText(status);
}

function getDeliveryMetaFromRecord(saved, deliveryRecord) {
    const status = getDeliveryMetaStatus(saved.status, deliveryRecord);
    return {
        status,
        note: getDeliveryMetaNote(saved.note, status, deliveryRecord),
        driver: getDeliveryMetaDriver(saved.driver, deliveryRecord)
    };
}

function getStatus(stock, min) {
    if (stock <= 0) return "out";
    if (stock <= min) return "low";
    return "in";
}

function stockPercent(item) {
    if (getStatus(item.stock, item.min_stock) === 'out') return 100;
    if (!item.min_stock) return 0;
    return Math.max(0, Math.round((item.stock / item.min_stock) * 100));
}

function formatRis(id, risNumber = '') {
    return risNumber || `RIS-${String(id).padStart(8, '0')}`;
}

function formatShortDate(dateStr) {
    const d = new Date(dateStr);
    if (Number.isNaN(d.getTime())) return '—';
    return `${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}-${String(d.getFullYear()).slice(2)}`;
}

function formatOffice(name) {
    const n = String(name || '').trim();
    if (!n) return '—';
    if (/office/i.test(n)) return n.toUpperCase();
    return `${n.toUpperCase()} PROVINCIAL OFFICE`;
}

// --- DROPDOWN MENUS ---
function closeAllMenus(exceptId) {
    document.querySelectorAll('.action-menu.open').forEach(menu => {
        if (exceptId && menu.id === exceptId) return;
        menu.classList.remove('open');
    });
    document.querySelectorAll('.ghost-btn.active, .circle-btn.active, .row-menu-btn.active, .catalog-menu-btn.active')
        .forEach(btn => {
            if (exceptId && btn.getAttribute('aria-controls') === exceptId) return;
            btn.classList.remove('active');
        });
}

function bindMenuToggle(btnId, menuId) {
    const btn = document.getElementById(btnId);
    const menu = document.getElementById(menuId);
    if (!btn || !menu) return;
    btn.setAttribute('aria-controls', menuId);
    btn.onclick = (e) => {
        e.stopPropagation();
        const willOpen = !menu.classList.contains('open');
        closeAllMenus();
        if (willOpen) {
            menu.classList.add('open');
            btn.classList.add('active');
        }
    };
}

document.addEventListener('click', () => closeAllMenus());
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAllMenus();
});

window.addEventListener('storage', (e) => {
    if (e.key === DELIVERY_STORAGE_KEY || e.key === 'dole_delivery_record_v1') {
        renderDelivery(deliveryFilter);
        updateDashboardStats();
    }

    if (e.key === 'dole_notification_v1') {
        try {
            const payload = e.newValue ? JSON.parse(e.newValue) : null;
            if (payload?.message) {
                showToast(payload.message, payload.type === 'error' ? 'error' : 'success');
            }
            if (payload?.requestId || payload?.packageId) {
                renderNotifications();
            }
        } catch (error) {
            console.warn('Invalid notification payload.', error);
        }
    }
});

function setActiveMenuOption(menuId, attr, value) {
    const menu = document.getElementById(menuId);
    if (!menu) return;
    menu.querySelectorAll('button').forEach(btn => {
        const match = btn.dataset[attr] === value
            || btn.getAttribute(`data-${attr}`) === value;
        btn.classList.toggle('active', match);
    });
}

// --- DASHBOARD ---
function initDashboard() {
    updateDashboardLists();
    updateDashboardStats();
}

function updateDashboardLists() {
    const lowList = document.getElementById('lowStockList');
    const outList = document.getElementById('outStockList');
    if (!lowList || !outList) return;

    lowList.innerHTML = '';
    outList.innerHTML = '';
    const unit = item => item.unit || 'pcs';

    inventoryData.filter(item => getStatus(item.stock, item.min_stock) === 'low').slice(0, 5).forEach(item => {
        lowList.innerHTML += `
            <li>
                <div class="dash-item-meta">
                    <span class="dash-item-name">${escapeHtml(item.item_name)}</span>
                    <span class="dash-item-stock">${item.stock} ${escapeHtml(unit(item))} in Stock</span>
                </div>
                <span class="dash-item-pct">
                    <img src="assets/figma/icon-trend-down.png" alt=""> ${stockPercent(item)}%
                </span>
            </li>`;
    });

    inventoryData.filter(item => getStatus(item.stock, item.min_stock) === 'out').slice(0, 5).forEach(item => {
        outList.innerHTML += `
            <li>
                <div class="dash-item-meta">
                    <span class="dash-item-name">${escapeHtml(item.item_name)}</span>
                    <span class="dash-item-stock">0 ${escapeHtml(unit(item))}</span>
                </div>
                <span class="dash-item-pct">
                    <img src="assets/figma/icon-trend-down-red.png" alt=""> 100%
                </span>
            </li>`;
    });

    if (!lowList.children.length) lowList.innerHTML = '<li style="justify-content:center;color:#aaa;border:none;">No low stock items</li>';
    if (!outList.children.length) outList.innerHTML = '<li style="justify-content:center;color:#aaa;border:none;">No out of stock items</li>';
}

function updateDashboardStats() {
    const todayStr = new Date().toDateString();
    const todayCount = requestsData.filter(request => {
        const date = new Date(request.request_date);
        return !Number.isNaN(date.getTime()) && date.toDateString() === todayStr;
    }).length;
    const pendingCount = requestsData.filter(request => !isHistoryRequest(request) && String(request.status || '').toLowerCase() === 'pending').length;
    const activeDeliveries = buildDeliveryList().filter(delivery => delivery.status === 'preparing' || delivery.status === 'shipped').length;

    const reqEl = document.getElementById('requestsCount');
    const appEl = document.getElementById('approvalsCount');
    const delEl = document.getElementById('deliveriesCount');
    if (reqEl) reqEl.textContent = pad2(todayCount);
    if (appEl) appEl.textContent = pad2(pendingCount);
    if (delEl) delEl.textContent = pad2(activeDeliveries);
}

// --- INVENTORY ---
function getSortedInventory() {
    const items = inventoryData.map((item, index) => ({ item, index }));
    if (inventorySort === 'name') {
        items.sort((a, b) => String(a.item.item_name).localeCompare(String(b.item.item_name)));
    } else if (inventorySort === 'stock') {
        items.sort((a, b) => Number(b.item.stock) - Number(a.item.stock));
    } else if (inventorySort === 'status') {
        const order = { out: 0, low: 1, in: 2 };
        items.sort((a, b) => order[getStatus(a.item.stock, a.item.min_stock)] - order[getStatus(b.item.stock, b.item.min_stock)]);
    }
    return items;
}

function renderInventory(filter = 'all') {
    inventoryFilter = filter;
    const table = document.getElementById("inventoryTable");
    if (!table) return;

    table.innerHTML = "";
    let counts = { all: 0, in: 0, low: 0, out: 0 };
    const keyword = (document.getElementById("searchInput")?.value || '').trim().toLowerCase();

    inventoryData.forEach(item => {
        counts.all++;
        counts[getStatus(item.stock, item.min_stock)]++;
    });

    getSortedInventory().forEach(({ item, index }) => {
        const status = getStatus(item.stock, item.min_stock);
        const matchesFilter = filter === 'all' || filter === status;
        const matchesSearch = !keyword
            || item.item_name.toLowerCase().includes(keyword)
            || String(item.category || '').toLowerCase().includes(keyword);
        if (!matchesFilter || !matchesSearch) return;

        const statusClass = status === 'in' ? 'green' : status === 'low' ? 'yellow' : 'red';
        const statusText = status === 'in' ? 'In Stock' : status === 'low' ? 'Low Stock' : 'Out of Stock';
        const itemCode = `ITM${String(item.id).padStart(4, '0')}`;
        const imgStyle = item.image ? `style="background-image:url('${escapeHtml(item.image)}');background-size:cover;"` : '';

        table.innerHTML += `
            <tr>
                <td>
                    <div class="item-cell">
                        <div class="item-img-box" ${imgStyle}></div>
                        <div class="item-text">
                            <div class="item-name">${escapeHtml(item.item_name)}</div>
                            <div class="item-code">${itemCode}</div>
                        </div>
                    </div>
                </td>
                <td>${escapeHtml(item.category)}</td>
                <td>${item.stock} ${item.unit || 'pcs'}</td>
                <td><span class="status ${statusClass}">${statusText}</span></td>
                <td>${escapeHtml(item.last_modified || '—')}</td>
                <td>
                    ${canManageInventory
                        ? `<div class="stock-actions">
                                <button class="manage-stock-btn" type="button" data-index="${index}">Update Stock</button>
                            <button class="add-stock-btn" type="button" data-index="${index}" aria-label="Add one ${escapeHtml(item.unit || 'item')} to ${escapeHtml(item.item_name)}" title="Add one stock">+</button>
                                <button class="remove-stock-action-btn" type="button" data-index="${index}" aria-label="Remove stock from ${escapeHtml(item.item_name)}" title="Remove stock">−</button>
                                <div class="menu-wrap">
                                    <button type="button" class="row-menu-btn" data-menu="inv-row-${index}" aria-label="More">⋮</button>
                                    <div class="action-menu" id="inv-row-${index}">
                                        <button type="button" data-action="edit" data-index="${index}">Edit Item</button>
                                        <div class="menu-sep"></div>
                                        <button type="button" data-action="delete" data-index="${index}">Delete Item</button>
                                    </div>
                                </div>
                           </div>`
                        : `<span class="status">View only</span>`
                    }
                </td>
            </tr>
        `;
    });

    const setCnt = (id, n) => {
        const el = document.getElementById(id);
        if (el) el.textContent = `(${n})`;
    };
    setCnt('inv-cnt-all', counts.all);
    setCnt('inv-cnt-in', counts.in);
    setCnt('inv-cnt-low', counts.low);
    setCnt('inv-cnt-out', counts.out);

    table.querySelectorAll('.manage-stock-btn').forEach(btn => {
        btn.onclick = () => updateStock(Number(btn.dataset.index));
    });

    table.querySelectorAll('.add-stock-btn').forEach(btn => {
        btn.onclick = () => addStock(Number(btn.dataset.index));
    });

    table.querySelectorAll('.remove-stock-action-btn').forEach(btn => {
        btn.onclick = () => removeStock(Number(btn.dataset.index));
    });

    table.querySelectorAll('.row-menu-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const menuId = btn.dataset.menu;
            const menu = document.getElementById(menuId);
            const willOpen = menu && !menu.classList.contains('open');
            closeAllMenus();
            if (willOpen && menu) {
                menu.classList.add('open');
                btn.classList.add('active');
            }
        };
    });

    table.querySelectorAll('.action-menu button[data-action]').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            closeAllMenus();
            const idx = Number(btn.dataset.index);
            if (btn.dataset.action === 'edit') editInventoryItem(idx);
            if (btn.dataset.action === 'remove') removeStock(idx);
            if (btn.dataset.action === 'delete') deleteInventoryItem(idx);
        };
    });
}

document.querySelectorAll('#inventoryTabs .page-tab').forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll('#inventoryTabs .page-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderInventory(tab.dataset.filter);
    };
});

bindMenuToggle('inventoryMoreBtn', 'inventoryMoreMenu');
document.querySelectorAll('#inventoryMoreMenu button').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        const action = btn.dataset.action;
        if (action === 'sort-name') inventorySort = 'name';
        if (action === 'sort-stock') inventorySort = 'stock';
        if (action === 'sort-status') inventorySort = 'status';
        if (action === 'sort-reset') inventorySort = 'default';
        setActiveMenuOption('inventoryMoreMenu', 'action', action);
        closeAllMenus();
        renderInventory(inventoryFilter);
        showToast(
            inventorySort === 'default' ? 'Sort reset.' : `Sorted by ${inventorySort}.`,
            'info'
        );
    };
});

function updateInventoryDependencies() {
    updateDashboardLists();
    updateDashboardStats();
    renderInventory(inventoryFilter);
    renderCatalog();
    renderNotifications();
}

window.updateStock = function updateStock(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    const nextStock = prompt(`Enter new stock for "${item.item_name}"`, String(item.stock));
    if (nextStock === null) return;
    const parsed = Number(nextStock);
    if (!Number.isFinite(parsed) || parsed < 0) {
        showToast('Please enter a valid stock number.', 'error');
        return;
    }

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=updateStock`, {
                method: 'POST',
                credentials: 'include',
                headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ id: item.id, stock: Math.floor(parsed) })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to update stock');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Stock updated successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not update stock.', 'error');
        }
    })();
};

window.addStock = function addStock(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=updateStock`, {
                method: 'POST',
                credentials: 'include',
                headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ id: item.id, stock: Number(item.stock || 0) + 1 })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to add stock');
            await fetchInventory();
            updateInventoryDependencies();
            showToast(`Added 1 ${item.unit || 'item'} to stock.`, 'success');
        } catch (err) {
            showToast(err.message || 'Could not add stock.', 'error');
        }
    })();
};

window.removeStock = function removeStock(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    const nextRemove = prompt(`Remove how many from "${item.item_name}"? (Current: ${item.stock})`, "1");
    if (nextRemove === null) return;
    const qty = Number(nextRemove);
    if (!Number.isFinite(qty) || qty <= 0) {
        showToast('Please enter a valid quantity to remove.', 'error');
        return;
    }

    const newStock = item.stock - Math.floor(qty);
    if (newStock < 0) {
        showToast('Cannot remove more than current stock.', 'error');
        return;
    }

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=updateStock`, {
                method: 'POST',
                credentials: 'include',
                headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ id: item.id, stock: newStock })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to remove stock');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Stock removed successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not remove stock.', 'error');
        }
    })();
};

window.editInventoryItem = function editInventoryItem(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;

    const nextName = prompt('Edit item name', item.item_name);
    if (nextName === null) return;
    const nextCategory = prompt('Edit category', item.category);
    if (nextCategory === null) return;
    const nextMin = prompt('Edit minimum stock', String(item.min_stock));
    if (nextMin === null) return;

    const parsedMin = Number(nextMin);
    if (!nextName.trim() || !nextCategory.trim() || !Number.isFinite(parsedMin) || parsedMin < 0) {
        showToast('Please provide valid item details.', 'error');
        return;
    }

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=update`, {
                method: 'POST',
                credentials: 'include',
                headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({
                    id: item.id,
                    item_name: nextName.trim(),
                    category: nextCategory.trim(),
                    unit: item.unit || 'pcs',
                    min_stock: Math.floor(parsedMin)
                })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to update item');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Item updated successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not update item.', 'error');
        }
    })();
};

window.deleteInventoryItem = function deleteInventoryItem(index) {
    if (!canManageInventory) return;
    const item = inventoryData[index];
    if (!item) return;
    if (!confirm(`Delete "${item.item_name}" from inventory?`)) return;

    (async () => {
        try {
            const response = await fetch(`${inventoryApiBase}?action=delete`, {
                method: 'POST',
                credentials: 'include',
                headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ id: item.id })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.message || 'Unable to delete item');
            await fetchInventory();
            updateInventoryDependencies();
            showToast('Item deleted successfully.', 'success');
        } catch (err) {
            showToast(err.message || 'Could not delete item.', 'error');
        }
    })();
};

// --- CATALOG ---
function renderCatalog() {
    const grid = document.getElementById('catalogGrid');
    if (!grid) return;

    const keyword = (document.getElementById('catalogSearchInput')?.value || '').trim().toLowerCase();
    const items = inventoryData.map((item, index) => ({ item, index })).filter(({ item }) => {
        const status = getStatus(item.stock, item.min_stock);
        if (catalogFilter === 'in' || catalogFilter === 'low' || catalogFilter === 'out') {
            if (status !== catalogFilter) return false;
        } else if (catalogFilter !== 'all' && item.category !== catalogFilter) {
            return false;
        }
        if (!keyword) return true;
        return item.item_name.toLowerCase().includes(keyword)
            || String(item.category || '').toLowerCase().includes(keyword);
    });

    if (!items.length) {
        grid.innerHTML = `<p class="empty-state" style="grid-column:1/-1;">No catalog items found.</p>`;
        return;
    }

    grid.innerHTML = items.map(({ item, index }) => {
        const status = getStatus(item.stock, item.min_stock);
        const avail = status === 'out' ? 'Unavailable' : 'Available';
        const dotClass = status === 'out' ? 'out' : status === 'low' ? 'low' : '';
        const unit = item.unit || 'pcs';
        const imgStyle = item.image
            ? `style="background-image:url('${escapeHtml(item.image)}');"`
            : '';
        return `
            <article class="catalog-card" data-index="${index}">
                <div class="catalog-img" ${imgStyle}></div>
                <div class="catalog-body">
                    <h4 class="catalog-name">${escapeHtml(item.item_name)}</h4>
                    <div class="catalog-avail"><span class="dot ${dotClass}"></span>${avail}</div>
                    <div class="catalog-divider"></div>
                    <div class="catalog-stock-row">
                        <div>
                            <div class="catalog-stock-label">Stock</div>
                            <div>
                                <span class="catalog-stock-val">${item.stock}</span>
                                <span class="catalog-stock-unit">${escapeHtml(unit)}</span>
                            </div>
                        </div>
                        ${canManageInventory ? `
                        <div class="menu-wrap">
                            <button type="button" class="catalog-menu-btn" data-menu="cat-row-${index}">⋮</button>
                            <div class="action-menu" id="cat-row-${index}">
                                <button type="button" data-action="view" data-index="${index}">View in Inventory</button>
                                <button type="button" data-action="update" data-index="${index}">Update Stock</button>
                                <button type="button" data-action="edit" data-index="${index}">Edit Item</button>
                            </div>
                        </div>` : ''}
                    </div>
                </div>
            </article>`;
    }).join('');

    grid.querySelectorAll('.catalog-menu-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const menu = document.getElementById(btn.dataset.menu);
            const willOpen = menu && !menu.classList.contains('open');
            closeAllMenus();
            if (willOpen && menu) {
                menu.classList.add('open');
                btn.classList.add('active');
            }
        };
    });

    grid.querySelectorAll('.action-menu button[data-action]').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            closeAllMenus();
            const idx = Number(btn.dataset.index);
            if (btn.dataset.action === 'view') {
                showPage('inventory');
                showToast('Opened in Inventory.', 'info');
            }
            if (btn.dataset.action === 'update') updateStock(idx);
            if (btn.dataset.action === 'edit') editInventoryItem(idx);
        };
    });
}

bindMenuToggle('catalogFilterBtn', 'catalogFilterMenu');
document.querySelectorAll('#catalogFilterMenu button').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        catalogFilter = btn.dataset.filter || 'all';
        setActiveMenuOption('catalogFilterMenu', 'filter', catalogFilter);
        closeAllMenus();
        const label = document.getElementById('catalogFilterBtn');
        if (label) label.textContent = catalogFilter === 'all' ? 'Filter ▾' : `${catalogFilter} ▾`;
        renderCatalog();
    };
});

const catalogSearch = document.getElementById('catalogSearchInput');
if (catalogSearch) catalogSearch.addEventListener('input', renderCatalog);

// --- APPROVALS ---
function getRequestDate(request) {
    const date = new Date(request.request_date);
    return Number.isNaN(date.getTime()) ? null : date;
}

function isHistoryRequest(request) {
    const date = getRequestDate(request);
    return date !== null && date.getTime() <= Date.now() - (7 * 24 * 60 * 60 * 1000);
}

function getDateInputValue(request) {
    const date = getRequestDate(request);
    if (!date) return '';
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${date.getFullYear()}-${month}-${day}`;
}

function getApprovalsList() {
    const todayStr = new Date().toDateString();
    let list = requestsData.filter(r => !isHistoryRequest(r)).map(r => {
        const status = String(r.status || 'Pending').toLowerCase();
        const d = new Date(r.request_date);
        const isToday = !Number.isNaN(d.getTime()) && d.toDateString() === todayStr;
        return { ...r, _status: status, _isToday: isToday };
    });

    if (approvalsTab === 'today') list = list.filter(r => r._isToday);
    else if (approvalsTab !== 'all') list = list.filter(r => r._status === approvalsTab);

    if (approvalsOfficeFilter !== 'all') {
        list = list.filter(r => String(r.requestor || '').toLowerCase().includes(approvalsOfficeFilter.toLowerCase()));
    }

    const keyword = (document.getElementById('approvalsSearchInput')?.value || '').trim().toLowerCase();
    if (keyword) {
        list = list.filter(r =>
            String(r.id).includes(keyword)
            || String(r.item_name || '').toLowerCase().includes(keyword)
            || String(r.requestor || '').toLowerCase().includes(keyword)
            || formatRis(r.id, r.ris_number).toLowerCase().includes(keyword)
        );
    }

    if (approvalsSort === 'oldest') {
        list.sort((a, b) => new Date(a.request_date) - new Date(b.request_date));
    } else if (approvalsSort === 'ris') {
        list.sort((a, b) => String(a.ris_number || '').localeCompare(String(b.ris_number || '')));
    } else if (approvalsSort === 'office') {
        list.sort((a, b) => String(a.requestor || '').localeCompare(String(b.requestor || '')));
    } else {
        list.sort((a, b) => new Date(b.request_date) - new Date(a.request_date));
    }

    return list;
}

function parseItemDetails(value) {
    if (!value) return [];
    try {
        const parsed = JSON.parse(value);
        return Array.isArray(parsed) ? parsed : [];
    } catch {
        return [];
    }
}

function getRequestSummary(request) {
    const details = parseItemDetails(request.item_details);
    if (details.length) {
        return details.map(item => `${item.item_name || item.name || 'Item'} x${item.quantity || 0}`).join(', ');
    }
    return `${request.item_name || 'Item'} x${request.quantity || 0}`;
}

function renderApprovals(filter) {
    approvalsTab = filter || approvalsTab;
    const grid = document.getElementById("approvalsGrid");
    if (!grid) return;

    const todayStr = new Date().toDateString();
    const counts = { all: 0, today: 0, pending: 0, approved: 0, declined: 0 };
    requestsData.filter(r => !isHistoryRequest(r)).forEach(r => {
        counts.all++;
        const status = String(r.status || 'Pending').toLowerCase();
        if (counts[status] !== undefined) counts[status]++;
        const d = new Date(r.request_date);
        if (!Number.isNaN(d.getTime()) && d.toDateString() === todayStr) counts.today++;
    });

    Object.keys(counts).forEach(key => {
        const el = document.getElementById(`cnt-${key}`);
        if (el) el.textContent = `(${pad2(counts[key])})`;
    });

    const filtered = getApprovalsList();
    if (!filtered.length) {
        grid.innerHTML = `<p class="empty-state" style="grid-column:1/-1;">No requests found for this category.</p>`;
        return;
    }

    grid.innerHTML = filtered.map(r => `
        <div class="req-card" data-id="${r.id}" role="button" tabindex="0">
            <div class="req-header">
                <span>${escapeHtml(formatRis(r.id, r.ris_number))} <span class="ris-dot"></span></span>
                <span class="req-open">↗</span>
            </div>
            <div class="req-row">
                <span class="req-label">Items:</span>
                <span class="req-val">${escapeHtml(getRequestSummary(r))}</span>
            </div>
            <div class="req-row">
                <span class="req-label">Date Requested:</span>
                <span class="req-date-pill">${escapeHtml(formatShortDate(r.request_date))}</span>
            </div>
            <div class="req-row">
                <span class="req-label">From:</span>
                <span class="req-val">${escapeHtml(String(r.requestor || '').toUpperCase())}- ADMIN</span>
            </div>
            <div class="req-row">
                <span class="req-label">Purpose:</span>
                <span class="req-val">${escapeHtml(r.note || r.remarks || 'Supply')}</span>
            </div>
        </div>
    `).join('');

    grid.querySelectorAll('.req-card').forEach(card => {
        const open = () => showRequestDetails(Number(card.dataset.id));
        card.onclick = open;
        card.onkeydown = (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                open();
            }
        };
    });
}

document.querySelectorAll(".filter-tabs .tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".filter-tabs .tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        renderApprovals(tab.dataset.filter);
    };
});

function renderRequestHistory() {
    const grid = document.getElementById('historyGrid');
    if (!grid) return;

    let list = requestsData.filter(isHistoryRequest);
    if (historyStartDate) list = list.filter(r => getDateInputValue(r) >= historyStartDate);
    if (historyEndDate) list = list.filter(r => getDateInputValue(r) <= historyEndDate);
    list.sort((a, b) => new Date(b.request_date) - new Date(a.request_date));

    const summary = document.getElementById('historySummary');
    if (summary) summary.textContent = `${list.length} request${list.length === 1 ? '' : 's'} in history`;
    if (!list.length) {
        grid.innerHTML = '<p class="empty-state" style="grid-column:1/-1;">No requests found for this date range.</p>';
        return;
    }

    grid.innerHTML = list.map(r => `
        <div class="req-card history-card" data-id="${r.id}" role="button" tabindex="0">
            <div class="req-header">
                <span>${escapeHtml(formatRis(r.id, r.ris_number))} <span class="ris-dot"></span></span>
                <span class="req-open">↗</span>
            </div>
            <div class="req-row"><span class="req-label">Items:</span><span class="req-val">${escapeHtml(getRequestSummary(r))}</span></div>
            <div class="req-row"><span class="req-label">Date Requested:</span><span class="req-date-pill">${escapeHtml(formatShortDate(r.request_date))}</span></div>
            <div class="req-row"><span class="req-label">From:</span><span class="req-val">${escapeHtml(String(r.requestor || '').toUpperCase())}- ADMIN</span></div>
            <div class="req-row"><span class="req-label">Purpose:</span><span class="req-val">${escapeHtml(r.note || r.remarks || 'Supply')}</span></div>
        </div>
    `).join('');

    grid.querySelectorAll('.req-card').forEach(card => {
        const open = () => showRequestDetails(Number(card.dataset.id));
        card.onclick = open;
        card.onkeydown = (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                open();
            }
        };
    });
}

document.getElementById('openRequestHistoryBtn')?.addEventListener('click', () => showPage('history'));
document.getElementById('historyBackBtn')?.addEventListener('click', () => showPage('approvals'));
document.getElementById('historyStartDate')?.addEventListener('change', (event) => {
    historyStartDate = event.target.value;
    renderRequestHistory();
});
document.getElementById('historyEndDate')?.addEventListener('change', (event) => {
    historyEndDate = event.target.value;
    renderRequestHistory();
});
document.getElementById('clearHistoryDates')?.addEventListener('click', () => {
    historyStartDate = '';
    historyEndDate = '';
    document.getElementById('historyStartDate').value = '';
    document.getElementById('historyEndDate').value = '';
    renderRequestHistory();
});

bindMenuToggle('approvalsSortBtn', 'approvalsSortMenu');
document.querySelectorAll('#approvalsSortMenu button').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        approvalsSort = btn.dataset.sort || 'newest';
        setActiveMenuOption('approvalsSortMenu', 'sort', approvalsSort);
        closeAllMenus();
        renderApprovals(approvalsTab);
        showToast(`Sorted: ${btn.textContent}`, 'info');
    };
});

bindMenuToggle('approvalsFilterBtn', 'approvalsFilterMenu');
document.querySelectorAll('#approvalsFilterMenu button').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        approvalsOfficeFilter = btn.dataset.extra || 'all';
        setActiveMenuOption('approvalsFilterMenu', 'extra', approvalsOfficeFilter);
        closeAllMenus();
        const label = document.getElementById('approvalsFilterBtn');
        if (label) label.textContent = approvalsOfficeFilter === 'all' ? 'Filter ▾' : `${approvalsOfficeFilter} ▾`;
        renderApprovals(approvalsTab);
    };
});

const approvalsSearch = document.getElementById('approvalsSearchInput');
if (approvalsSearch) {
    approvalsSearch.addEventListener('input', () => renderApprovals(approvalsTab));
}

function showRequestDetails(requestId) {
    const req = requestsData.find(r => Number(r.id) === Number(requestId));
    if (!req) return;
    const modal = document.getElementById('requestDetailsModal');
    const status = String(req.status || 'Pending').toLowerCase();

    document.getElementById('detailRis').textContent = formatRis(req.id, req.ris_number);
    const statusEl = document.getElementById('detailStatus');
    statusEl.textContent = req.status || 'Pending';
    statusEl.className = `status-badge-inline ${status}`;
    const details = parseItemDetails(req.item_details);
    const summary = details.length
        ? details.map(item => `${item.item_name || item.name || 'Item'} x${item.quantity || 0}`).join(', ')
        : `${req.item_name || 'Item'} x${req.quantity || 0}`;
    document.getElementById('detailItem').textContent = summary;
    document.getElementById('detailQty').textContent = details.length ? `${details.reduce((sum, item) => sum + (Number(item.quantity) || 0), 0)}` : (req.quantity ?? '—');
    document.getElementById('detailFrom').textContent = formatOffice(req.requestor);
    document.getElementById('detailDate').textContent = formatShortDate(req.request_date);
    document.getElementById('detailNote').textContent = req.note || req.remarks || '—';

    modal.dataset.requestId = String(req.id);
    const actions = document.getElementById('requestActionButtons');
    if (actions) actions.style.display = status === 'pending' ? 'flex' : 'none';
    modal.classList.add('active');
}

document.getElementById('closeRequestDetails')?.addEventListener('click', () => {
    document.getElementById('requestDetailsModal')?.classList.remove('active');
});
document.getElementById('requestDetailsModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'requestDetailsModal') e.target.classList.remove('active');
});

function publishRequestStatusSync(requestId, status) {
    try {
        localStorage.setItem('dole_request_status_sync_v1', JSON.stringify({
            requestId: Number(requestId),
            status,
            updatedAt: new Date().toISOString()
        }));
    } catch (error) {
        console.warn('Could not publish request status sync.', error);
    }
}

async function updateRequestStatus(requestId, status) {
    try {
        const response = await fetch(`${requestsApiBase}?action=update_status`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ id: requestId, status })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Unable to update request');
        publishRequestStatusSync(requestId, status);
        publishNotification({
            type: 'request_status',
            title: `Request ${status}`,
            message: `Request ${requestId} was ${String(status).toLowerCase()}.`, 
            requestId: Number(requestId),
            status,
            source: 'supply'
        });
        if (String(status).toLowerCase() === 'approved') {
            await updateDeliveryPackageStatus(getPackageIdForRequest(requestId), 'ready');
        }
        showToast(`Request ${status.toLowerCase()} successfully.`, 'success');
        await fetchRequests();
        await fetchDeliveryPackages();
        updateDashboardStats();
        renderApprovals(approvalsTab);
        renderDelivery(deliveryFilter);
        renderNotifications();
        return true;
    } catch (err) {
        showToast(err.message || 'Could not update request.', 'error');
        return false;
    }
}

document.getElementById('approveRequestBtn')?.addEventListener('click', async () => {
    const modal = document.getElementById('requestDetailsModal');
    const id = modal?.dataset.requestId;
    if (!id) return;
    if (!confirm('Approve this request?')) return;
    if (await updateRequestStatus(id, 'Approved')) modal.classList.remove('active');
});

document.getElementById('declineRequestBtn')?.addEventListener('click', async () => {
    const modal = document.getElementById('requestDetailsModal');
    const id = modal?.dataset.requestId;
    if (!id) return;
    if (!confirm('Decline this request?')) return;
    if (await updateRequestStatus(id, 'Declined')) modal.classList.remove('active');
});

// --- DELIVERY ---
function loadDeliveryMeta() {
    try {
        return JSON.parse(localStorage.getItem(DELIVERY_STORAGE_KEY) || '{}') || {};
    } catch (e) {
        return {};
    }
}

function saveDeliveryMeta(meta) {
    localStorage.setItem(DELIVERY_STORAGE_KEY, JSON.stringify(meta));
}

function buildDeliveryList(includeHistory = false) {
    const meta = loadDeliveryMeta();
    return requestsData
        .filter(r => String(r.status || '').toLowerCase() === 'approved' && (includeHistory || !isHistoryRequest(r)))
        .map(r => {
            const saved = meta[r.id] || {};
            const deliveryRecord = getDeliveryRecordForRequest(r.id);
            const merged = getDeliveryMetaFromRecord(saved, deliveryRecord);
            return {
                id: r.id,
                ris: formatRis(r.id, r.ris_number),
                office: formatOffice(r.requestor),
                requestedBy: `${r.requestor || '—'} - ADMIN`,
                date: formatShortDate(r.request_date),
                items: `${r.item_name} x${r.quantity}`,
                purpose: r.note || 'Supply',
                scanCode: deliveryRecord?.scan_code || '',
                driver: merged.driver,
                status: merged.status,
                note: merged.note,
                rawDate: r.request_date
            };
        });
}

function renderDelivery(filter = 'all') {
    deliveryFilter = filter;
    const list = document.getElementById('deliveryList');
    if (!list) return;

    let deliveries = buildDeliveryList();
    const counts = { all: 0, preparing: 0, shipped: 0, delivered: 0, cancelled: 0, returned: 0 };
    deliveries.forEach(d => {
        counts.all++;
        if (counts[d.status] !== undefined) counts[d.status]++;
    });
    Object.keys(counts).forEach(key => {
        const el = document.getElementById(`del-cnt-${key}`);
        if (el) el.textContent = `(${counts[key]})`;
    });

    if (filter !== 'all') deliveries = deliveries.filter(d => d.status === filter);
    if (deliveryOfficeFilter !== 'all') {
        deliveries = deliveries.filter(d => d.office.toLowerCase().includes(deliveryOfficeFilter.toLowerCase()));
    }

    const keyword = (document.getElementById('deliverySearchInput')?.value || '').trim().toLowerCase();
    if (keyword) {
        deliveries = deliveries.filter(d =>
            d.ris.toLowerCase().includes(keyword)
            || d.items.toLowerCase().includes(keyword)
            || d.office.toLowerCase().includes(keyword)
        );
    }

    if (deliverySort === 'oldest') {
        deliveries.sort((a, b) => new Date(a.rawDate) - new Date(b.rawDate));
    } else if (deliverySort === 'office') {
        deliveries.sort((a, b) => a.office.localeCompare(b.office));
    } else if (deliverySort === 'status') {
        deliveries.sort((a, b) => a.status.localeCompare(b.status));
    } else {
        deliveries.sort((a, b) => new Date(b.rawDate) - new Date(a.rawDate));
    }

    if (!deliveries.length) {
        list.innerHTML = `<p class="empty-state">No deliveries found. Approve requests to create deliveries.</p>`;
        return;
    }

    list.innerHTML = deliveries.map(d => `
        <article class="delivery-card" data-id="${d.id}">
            <div class="delivery-meta">
                <span><span class="lbl">Office/Branch:</span> ${escapeHtml(d.office)}</span>
                <span><span class="lbl">Requested by/ Unit:</span> ${escapeHtml(d.requestedBy)}</span>
                <span><span class="lbl">Date Requested:</span> ${escapeHtml(d.date)}</span>
                <span style="margin-left:auto;">RIS#${escapeHtml(d.ris)}</span>
            </div>
            <div class="delivery-body">
                <div class="delivery-items">
                    <div class="delivery-thumbs"><span></span><span></span><span></span></div>
                    <div>
                        <div class="delivery-item-text">${escapeHtml(d.items)}</div>
                        <div class="delivery-purpose"><span>Purpose:</span> <b>${escapeHtml(d.purpose)}</b></div>
                    </div>
                </div>
                <div class="delivery-driver">${escapeHtml(d.driver)}</div>
                <div>
                    <div class="menu-wrap">
                        <button type="button" class="delivery-status ${d.status}" data-menu="del-status-${d.id}">${escapeHtml(capitalize(d.status))} ▾</button>
                        <div class="action-menu align-left" id="del-status-${d.id}">
                            <button type="button" data-status="preparing" data-id="${d.id}">Preparing</button>
                            <button type="button" data-status="shipped" data-id="${d.id}">Shipped</button>
                            <button type="button" data-status="delivered" data-id="${d.id}">Delivered</button>
                            <button type="button" data-status="cancelled" data-id="${d.id}">Cancelled</button>
                            <button type="button" data-status="returned" data-id="${d.id}">Returned</button>
                        </div>
                    </div>
                    ${d.note ? `<span class="delivery-note">${escapeHtml(d.note)}</span>` : ''}
                </div>
                <div>
                    <button type="button" class="print-label-btn" data-id="${d.id}">Print Label</button>
                </div>
            </div>
        </article>
    `).join('');

    list.querySelectorAll('.delivery-status').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const menu = document.getElementById(btn.dataset.menu);
            const willOpen = menu && !menu.classList.contains('open');
            closeAllMenus();
            if (willOpen && menu) menu.classList.add('open');
        };
    });

    list.querySelectorAll('#deliveryList .action-menu button[data-status]').forEach(btn => {
        btn.onclick = async (e) => {
            e.stopPropagation();
            const id = btn.dataset.id;
            const status = btn.dataset.status;
            const packageId = getPackageIdForRequest(id);
            const deliveryStatus = translateSupplyToDeliveryStatus(status);
            const updated = await updateDeliveryPackageStatus(packageId, deliveryStatus);

            if (updated || deliveryPackages[packageId.toUpperCase()]) {
                const meta = loadDeliveryMeta();
                meta[id] = {
                    ...(meta[id] || {}),
                    status,
                    note: status === 'preparing'
                        ? 'Please prepare soon'
                        : status === 'shipped'
                            ? 'Out for delivery'
                            : status === 'delivered'
                                ? 'Delivery completed'
                                : status === 'cancelled'
                                    ? 'Delivery cancelled'
                                    : status === 'returned'
                                        ? 'Delivery returned'
                                        : (meta[id]?.note || ''),
                    driver: deliveryPackages[packageId.toUpperCase()]?.courier_name || meta[id]?.driver || '—'
                };
                saveDeliveryMeta(meta);
                closeAllMenus();
                renderDelivery(deliveryFilter);
                updateDashboardStats();
                showToast(`Delivery marked as ${status}.`, 'success');
            } else {
                showToast('Could not update delivery status.', 'error');
            }
        };
    });

    list.querySelectorAll('.print-label-btn').forEach(btn => {
        btn.onclick = () => printDeliveryLabel(Number(btn.dataset.id));
    });
}

function renderDeliveryHistory() {
    const listElement = document.getElementById('deliveryHistoryList');
    if (!listElement) return;

    let deliveries = buildDeliveryList(true).filter(d => isHistoryRequest({ request_date: d.rawDate }));
    if (deliveryHistoryStartDate) deliveries = deliveries.filter(d => getDateInputValue({ request_date: d.rawDate }) >= deliveryHistoryStartDate);
    if (deliveryHistoryEndDate) deliveries = deliveries.filter(d => getDateInputValue({ request_date: d.rawDate }) <= deliveryHistoryEndDate);
    deliveries.sort((a, b) => new Date(b.rawDate) - new Date(a.rawDate));

    const summary = document.getElementById('deliveryHistorySummary');
    if (summary) summary.textContent = `${deliveries.length} ${deliveries.length === 1 ? 'delivery' : 'deliveries'} in history`;
    if (!deliveries.length) {
        listElement.innerHTML = '<p class="empty-state">No deliveries found for this date range.</p>';
        return;
    }

    listElement.innerHTML = deliveries.map(d => `
        <article class="delivery-card delivery-history-card" data-id="${d.id}">
            <div class="delivery-meta">
                <span><span class="lbl">Office/Branch:</span> ${escapeHtml(d.office)}</span>
                <span><span class="lbl">Requested by/ Unit:</span> ${escapeHtml(d.requestedBy)}</span>
                <span><span class="lbl">Date Requested:</span> ${escapeHtml(d.date)}</span>
                <span style="margin-left:auto;">RIS#${escapeHtml(d.ris)}</span>
            </div>
            <div class="delivery-body">
                <div class="delivery-items">
                    <div class="delivery-thumbs"><span></span><span></span><span></span></div>
                    <div>
                        <div class="delivery-item-text">${escapeHtml(d.items)}</div>
                        <div class="delivery-purpose"><span>Purpose:</span> <b>${escapeHtml(d.purpose)}</b></div>
                    </div>
                </div>
                <div class="delivery-driver">${escapeHtml(d.driver)}</div>
                <div><span class="delivery-status ${d.status}">${escapeHtml(capitalize(d.status))}</span>${d.note ? `<span class="delivery-note">${escapeHtml(d.note)}</span>` : ''}</div>
                <div><button type="button" class="print-label-btn" data-id="${d.id}">Print Label</button></div>
            </div>
        </article>
    `).join('');

    listElement.querySelectorAll('.print-label-btn').forEach(btn => {
        btn.onclick = () => printDeliveryLabel(Number(btn.dataset.id));
    });
}

function printDeliveryLabel(id) {
    const d = buildDeliveryList().find(x => Number(x.id) === Number(id));
    if (!d) {
        showToast('Delivery not found.', 'error');
        return;
    }
    const win = window.open('', '_blank', 'width=480,height=640');
    if (!win) {
        showToast('Pop-up blocked. Allow pop-ups to print labels.', 'warning');
        return;
    }
    // prepare a QR that points to the delivery details URL and render it locally in the print window
    const qrUrl = new URL('../DELIVERY/DELI.php', window.location.href);
    qrUrl.searchParams.set('pkg', 'PKG-' + d.id);
    const scanCode = String(d.scanCode || '').trim().toUpperCase();
    if (scanCode) qrUrl.searchParams.set('code', scanCode);
    const qrImageUrl = new URL('qr_code.php', window.location.href);
    qrImageUrl.searchParams.set('data', qrUrl.toString());

    const html = [
        '<!DOCTYPE html><html><head><title>Label ' + escapeHtml(d.ris) + '</title>',
        '<style>',
        'body{font-family:Inter,Segoe UI,Arial,sans-serif;padding:24px;color:#333;}',
        'h1{font-size:18px;margin:0 0 12px;}p{margin:6px 0;font-size:13px;}',
        '.box{border:2px solid #4784ff;border-radius:8px;padding:16px;position:relative;min-height:260px;}',
        '.ris{font-size:20px;font-weight:700;color:#4784ff;}',
        '#qr{width:180px;margin:16px auto 0;text-align:center;}',
        '#qr canvas, #qr img{width:160px;height:160px;display:block;margin:0 auto;}',
        '#qr .qr-code{display:block;margin-top:5px;font-size:11px;line-height:1.2;overflow-wrap:anywhere;}',
        '</style></head><body><div class="box">',
        '<div class="ris">' + escapeHtml(d.ris) + '</div>',
        '<h1>Delivery Label</h1>',
        '<p><strong>Office:</strong> ' + escapeHtml(d.office) + '</p>',
        '<p><strong>Requested by:</strong> ' + escapeHtml(d.requestedBy) + '</p>',
        '<p><strong>Items:</strong> ' + escapeHtml(d.items) + '</p>',
        '<p><strong>Purpose:</strong> ' + escapeHtml(d.purpose) + '</p>',
        '<p><strong>Status:</strong> ' + escapeHtml(capitalize(d.status)) + '</p>',
        '<p><strong>Driver:</strong> ' + escapeHtml(d.driver) + '</p>',
        '<p><strong>Package ID:</strong> PKG-' + escapeHtml(d.id) + '</p>',
        '<p><strong>Date:</strong> ' + escapeHtml(d.date) + '</p>',
        '<div id="qr" aria-label="Package QR code"><img src="' + escapeHtml(qrImageUrl.toString()) + '" alt="Package QR code"><strong class="qr-code">' + escapeHtml(scanCode || 'Code unavailable - refresh delivery data') + '</strong></div>',
        '<script>window.addEventListener("load", function(){ setTimeout(function(){ window.print(); }, 800); });</script>',
        '</div></body></html>'
    ].join('');
    win.document.write(html);
    win.document.close();
    win.focus();
    // print will be triggered from inside the print window after QR generation
    showToast('Print preview opened. Printing once QR is ready.', 'success');
}

document.querySelectorAll('#deliveryTabs .page-tab').forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll('#deliveryTabs .page-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderDelivery(tab.dataset.filter);
    };
});

bindMenuToggle('deliverySortBtn', 'deliverySortMenu');
document.querySelectorAll('#deliverySortMenu button').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        deliverySort = btn.dataset.sort || 'newest';
        setActiveMenuOption('deliverySortMenu', 'sort', deliverySort);
        closeAllMenus();
        renderDelivery(deliveryFilter);
        showToast(`Sorted: ${btn.textContent}`, 'info');
    };
});

bindMenuToggle('deliveryFilterBtn', 'deliveryFilterMenu');
document.querySelectorAll('#deliveryFilterMenu button').forEach(btn => {
    btn.onclick = (e) => {
        e.stopPropagation();
        deliveryOfficeFilter = btn.dataset.extra || 'all';
        setActiveMenuOption('deliveryFilterMenu', 'extra', deliveryOfficeFilter);
        closeAllMenus();
        const label = document.getElementById('deliveryFilterBtn');
        if (label) label.textContent = deliveryOfficeFilter === 'all' ? 'Filter ▾' : `${deliveryOfficeFilter} ▾`;
        renderDelivery(deliveryFilter);
    };
});

const deliverySearch = document.getElementById('deliverySearchInput');
if (deliverySearch) {
    deliverySearch.addEventListener('input', () => renderDelivery(deliveryFilter));
}

document.getElementById('openDeliveryHistoryBtn')?.addEventListener('click', () => showPage('deliveryHistory'));
document.getElementById('deliveryHistoryBackBtn')?.addEventListener('click', () => showPage('delivery'));
document.getElementById('deliveryHistoryStartDate')?.addEventListener('change', (event) => {
    deliveryHistoryStartDate = event.target.value;
    renderDeliveryHistory();
});
document.getElementById('deliveryHistoryEndDate')?.addEventListener('change', (event) => {
    deliveryHistoryEndDate = event.target.value;
    renderDeliveryHistory();
});
document.getElementById('clearDeliveryHistoryDates')?.addEventListener('click', () => {
    deliveryHistoryStartDate = '';
    deliveryHistoryEndDate = '';
    document.getElementById('deliveryHistoryStartDate').value = '';
    document.getElementById('deliveryHistoryEndDate').value = '';
    renderDeliveryHistory();
});

// --- PPMP ---
async function fetchPpmpData() {
    try {
        const response = await fetch(`${ppmpApiBase}?action=list`, { credentials: 'include' });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to load PPMPs');
        const nextPpmpData = (data.data || []).map(row => ({
            id: row.id,
            year: row.fiscal_year,
            office: row.province || 'Unassigned',
            unit: row.requestor_name || 'REQUESTOR',
            item: `${row.item_count || 0} item(s)`,
            qty: row.item_count || 0,
            status: row.status,
            reason: row.reason || '',
            reviewedBy: row.reviewed_by || '',
            uploadedAt: row.uploaded_at,
            fileName: row.file_name || '—'
        }));
        if (ppmpDataInitialized) {
            const newPending = nextPpmpData.filter(row => !knownPpmpIds.has(Number(row.id)) && String(row.status || '').toLowerCase() === 'pending');
            if (newPending.length) {
                showToast(`${newPending.length} new PPMP submission${newPending.length > 1 ? 's' : ''} waiting for review.`, 'info');
            }
        }
        ppmpData = nextPpmpData;
        knownPpmpIds = new Set(ppmpData.map(row => Number(row.id)));
        ppmpDataInitialized = true;
        renderPpmp();
    } catch (err) {
        showToast(err.message || 'Could not load PPMP records.', 'error');
        ppmpData = [];
        renderPpmp();
    }
}

function renderPpmp() {
    const body = document.getElementById('ppmpTableBody');
    if (!body) return;

    const keyword = (document.getElementById('ppmpSearchInput')?.value || '').trim().toLowerCase();
    const rows = ppmpData.filter(r => {
        if (ppmpYear !== 'all' && r.year !== ppmpYear) return false;
        if (ppmpOffice !== 'all' && r.office !== ppmpOffice) return false;
        if (ppmpUnit !== 'all' && r.unit !== ppmpUnit) return false;
        if (!keyword) return true;
        return String(r.item).toLowerCase().includes(keyword)
            || String(r.office).toLowerCase().includes(keyword)
            || String(r.unit).toLowerCase().includes(keyword)
            || String(r.fileName).toLowerCase().includes(keyword)
            || String(r.year).includes(keyword);
    });

    if (!rows.length) {
        body.innerHTML = `<tr><td colspan="6" class="empty-state">No PPMP records match these filters.</td></tr>`;
        return;
    }

    body.innerHTML = rows.map(r => `
        <tr>
            <td>${escapeHtml(r.year)}</td>
            <td>${escapeHtml(r.office)}</td>
            <td>${escapeHtml(r.unit)}</td>
            <td>${escapeHtml(r.item)}<small class="muted">${escapeHtml(r.fileName)}</small></td>
            <td>${r.qty}</td>
            <td>
                <div class="ppmp-status-cell">
                    <select class="status status-select ${r.status === 'Approved' ? 'green' : r.status === 'Rejected' ? 'red' : 'yellow'}" aria-label="PPMP status" onchange="changePpmpStatus(${r.id}, this.value, this)">
                        <option value="Pending" ${r.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Approved" ${r.status === 'Approved' ? 'selected' : ''}>Accepted</option>
                        <option value="Rejected" ${r.status === 'Rejected' ? 'selected' : ''}>Rejected</option>
                    </select>
                    <a class="ghost-btn small-btn" href="${ppmpApiBase}?action=download&id=${Number(r.id) || 0}" target="_blank" rel="noopener">Download</a>
                </div>
            </td>
        </tr>
    `).join('');
}

async function changePpmpStatus(id, status, selectElement) {
    const currentStatus = ppmpData.find(record => Number(record.id) === Number(id))?.status || '';
    if (!status || status === currentStatus) return;
    const reason = status === 'Rejected'
        ? window.prompt('Enter rejection reason:')?.trim()
        : '';
    if (status === 'Rejected' && !reason) {
        if (selectElement) selectElement.value = currentStatus;
        showToast('A rejection reason is required.', 'error');
        return;
    }

    try {
        const response = await fetch(`${ppmpApiBase}?action=review`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ id, status, reason, edit: true })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to edit PPMP decision');
        showToast(`PPMP marked ${status.toLowerCase()}.`, 'success');
        await fetchPpmpData();
    } catch (err) {
        if (selectElement) selectElement.value = currentStatus;
        showToast(err.message || 'Could not edit PPMP decision.', 'error');
    }
}

function bindPpmpFilter(btnId, menuId, attrSetter, labelPrefix) {
    bindMenuToggle(btnId, menuId);
    document.querySelectorAll(`#${menuId} button`).forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const value = btn.dataset.value || 'all';
            attrSetter(value);
            setActiveMenuOption(menuId, 'value', value);
            closeAllMenus();
            const label = document.getElementById(btnId);
            if (label) label.textContent = value === 'all' ? `${labelPrefix} ▾` : `${value} ▾`;
            renderPpmp();
        };
    });
}

bindPpmpFilter('ppmpYearBtn', 'ppmpYearMenu', (v) => { ppmpYear = v; }, 'Fiscal Year');
bindPpmpFilter('ppmpOfficeBtn', 'ppmpOfficeMenu', (v) => { ppmpOffice = v; }, 'Office/ Branch');
bindPpmpFilter('ppmpUnitBtn', 'ppmpUnitMenu', (v) => { ppmpUnit = v; }, 'Unit');

document.getElementById('ppmpSearchInput')?.addEventListener('input', renderPpmp);

// --- NOTIFICATIONS ---
let supplyNotificationFilter = 'all';

function renderNotifications() {
    const page = document.getElementById('notifications');
    if (!page) return;

    const low = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'low').length;
    const out = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'out').length;
    const pending = requestsData.filter(r => !isHistoryRequest(r) && String(r.status || '').toLowerCase() === 'pending').length;
    const pendingPpmp = ppmpData.filter(r => String(r.status || '').toLowerCase() === 'pending').length;

    const items = [];
    if (pending) items.push({ type: 'info', title: 'Pending Approvals', message: `${pending} request(s) waiting for review.`, action: () => showPage('approvals'), unread: true });
    if (pendingPpmp) items.push({ type: 'info', title: 'PPMP Review Needed', message: `${pendingPpmp} PPMP submission(s) waiting for review.`, action: () => showPage('ppmp'), unread: true });
    if (low) items.push({ type: 'warning', title: 'Low Stock Alert', message: `${low} item(s) need restock.`, action: () => { showPage('inventory'); document.querySelector('#inventoryTabs .page-tab[data-filter="low"]')?.click(); }, unread: true });
    if (out) items.push({ type: 'error', title: 'Out of Stock', message: `${out} item(s) are out of stock.`, action: () => { showPage('inventory'); document.querySelector('#inventoryTabs .page-tab[data-filter="out"]')?.click(); }, unread: true });

    const visibleItems = supplyNotificationFilter === 'unread'
        ? items.filter(item => item.unread)
        : items;
    const notificationRows = visibleItems.map((item, index) => `
        <article class="supply-notification-row ${item.unread ? 'unread' : ''}" data-notification-index="${index}" tabindex="0" role="button">
            <span class="supply-notification-icon ${item.type}" aria-hidden="true"></span>
            <div class="supply-notification-copy">
                <strong>${escapeHtml(item.title)}</strong>
                <span>${escapeHtml(item.message)}</span>
            </div>
            <time>Now</time>
            ${item.unread ? '<span class="supply-notification-dot" aria-label="Unread"></span>' : ''}
        </article>
    `).join('');

    page.innerHTML = `
        <div class="supply-notifications-tabs" role="tablist">
            <button type="button" class="${supplyNotificationFilter === 'all' ? 'active' : ''}" data-notification-filter="all">All <span>${items.length}</span></button>
            <button type="button" class="${supplyNotificationFilter === 'unread' ? 'active' : ''}" data-notification-filter="unread">Unread <span>${items.filter(item => item.unread).length}</span></button>
        </div>
        <div class="supply-notifications-search">
            <span aria-hidden="true">⌕</span>
            <input type="search" placeholder="Search by title or message" aria-label="Search notifications">
        </div>
        <section class="supply-notification-section">
            <h3>Today</h3>
            <div class="supply-notification-list">
                ${notificationRows || '<p class="empty-state">No notifications yet.</p>'}
            </div>
        </section>
    `;

    if (!items.length) {
        return;
    }

    page.querySelectorAll('[data-notification-filter]').forEach(button => {
        button.onclick = () => {
            supplyNotificationFilter = button.dataset.notificationFilter;
            renderNotifications();
        };
    });

    const search = page.querySelector('.supply-notifications-search input');
    search?.addEventListener('input', () => {
        const query = search.value.trim().toLowerCase();
        page.querySelectorAll('.supply-notification-row').forEach(row => {
            row.hidden = query !== '' && !row.textContent.toLowerCase().includes(query);
        });
    });

    page.querySelectorAll('.supply-notification-row').forEach(card => {
        const go = () => visibleItems[Number(card.dataset.notificationIndex)]?.action?.();
        card.onclick = go;
        card.onkeydown = (e) => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
        };
    });
}

// --- DASHBOARD ARROWS / STAT CARDS ---
document.querySelectorAll(".dashboard-arrow, .stat-card").forEach(el => {
    el.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const page = el.dataset.page || el.dataset.goto;
        if (!page) return;
        showPage(page);
        if (page === 'inventory') {
            const filter = el.dataset.filter || 'all';
            document.querySelectorAll('#inventoryTabs .page-tab').forEach(t => {
                t.classList.toggle('active', t.dataset.filter === filter);
            });
            renderInventory(filter);
        }
        if (page === 'approvals' && el.dataset.filter) {
            document.querySelectorAll('.filter-tabs .tab').forEach(t => {
                t.classList.toggle('active', t.dataset.filter === el.dataset.filter);
            });
            renderApprovals(el.dataset.filter);
        }
    };
});

document.getElementById('profileCard')?.addEventListener('click', () => {
    showPage('profile');
});

// --- PROFILE / ACCOUNT SETTINGS ---
const loginApiBase = `${window.location.origin}${appRoot}/Login`;

function getProfileStorageKey() {
    return 'central_profile_' + (window.currentUserName || 'default');
}

function loadProfileExtras() {
    try {
        return JSON.parse(localStorage.getItem(getProfileStorageKey()) || '{}') || {};
    } catch (e) {
        return {};
    }
}

function saveProfileExtras(data) {
    localStorage.setItem(getProfileStorageKey(), JSON.stringify(data));
}

function applyAvatar(url) {
    if (!url) return;
    const targets = [
        document.querySelector('.profile .avatar'),
        document.getElementById('settingsAvatar'),
        document.getElementById('editAvatarPreview')
    ];
    targets.forEach(el => {
        if (!el) return;
        el.style.backgroundImage = `url(${url})`;
        el.style.backgroundSize = 'cover';
        el.style.backgroundPosition = 'center';
    });
}

function loadCurrentUserAvatar() {
    const username = window.currentUserName || '';
    if (!username) return;
    const data = localStorage.getItem('avatar_' + username);
    if (data) applyAvatar(data);
}

function updateSidebarProfile(name, email) {
    const nameEl = document.querySelector('.profile-info h4');
    const emailEl = document.querySelector('.profile-info p');
    if (nameEl && name) nameEl.textContent = name;
    if (emailEl && email) emailEl.textContent = email;
}

function renderAccountSettings() {
    const extras = loadProfileExtras();
    const name = extras.displayName || window.currentUserFullName || window.currentUserName || '—';
    const email = extras.email || window.currentUserEmail || '—';
    const phone = extras.phone || '+63 9123456789';
    const address = extras.address || 'Calamba City, Laguna, Parian';
    const bureau = extras.bureau || 'Procurement and Supply Division';

    const setText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value || '—';
    };

    setText('settingsDisplayName', name);
    setText('settingsRole', window.currentUserRole || 'Approver');
    setText('settingsBureau', bureau);
    setText('settingsEmail', email);
    setText('settingsPhone', phone);
    setText('settingsAddress', address);
    setText('settingsFullName', extras.fullName || name);
    setText('settingsDob', extras.dob || 'June 13, 2003');
    setText('settingsGender', extras.gender || 'Male');
    setText('settingsCivil', extras.civil || 'Single');
    setText('settingsNationality', extras.nationality || 'Filipino');
    setText('settingsUsername', window.currentUserName || '—');
    setText('settingsPassword', '************');
    setText('settingsPosition', extras.position || 'Supply Officer');
    setText('settingsDivision', extras.division || bureau);
    setText('settingsEmployeeId', extras.employeeId || 'DOLE-2026-00013');
    setText('settingsEmployment', extras.employment || 'Permanent');
    setText('settingsPlantillaItemNo', extras.plantillaItemNo || 'DOL-BWC-2026-078');
    setText('settingsSalaryGrade', extras.salaryGrade || 'SG 15');
    setText('settingsStep', extras.step || '3');
    setText('settingsDateCreated', extras.dateCreated || 'June 5, 2026');

    loadCurrentUserAvatar();
    updateSidebarProfile(name, email);
}

function openEditProfileModal() {
    const modal = document.getElementById('editProfileModal');
    if (!modal) return;
    const extras = loadProfileExtras();
    document.getElementById('editDisplayName').value = extras.displayName || window.currentUserFullName || '';
    document.getElementById('editEmail').value = extras.email || window.currentUserEmail || '';
    document.getElementById('editPhone').value = extras.phone || '';
    document.getElementById('editAddress').value = extras.address || '';
    document.getElementById('editDob').value = extras.dob || 'June 13, 2003';
    document.getElementById('editGender').value = extras.gender || 'Male';
    document.getElementById('editCivil').value = extras.civil || 'Single';
    document.getElementById('editNationality').value = extras.nationality || 'Filipino';
    document.getElementById('editBureau').value = extras.bureau || 'Procurement and Supply Division';
    document.getElementById('editEmployeeId').value = extras.employeeId || 'DOLE-2026-00013';
    document.getElementById('editPosition').value = extras.position || 'Supply Officer';
    document.getElementById('editEmployment').value = extras.employment || 'Permanent';
    document.getElementById('editPlantillaItemNo').value = extras.plantillaItemNo || 'DOL-BWC-2026-078';
    document.getElementById('editSalaryGrade').value = extras.salaryGrade || 'SG 15';
    document.getElementById('editStep').value = extras.step || '3';
    document.getElementById('editDateCreated').value = extras.dateCreated || 'June 5, 2026';

    const preview = document.getElementById('editAvatarPreview');
    const saved = localStorage.getItem('avatar_' + (window.currentUserName || ''));
    if (preview) {
        preview.style.backgroundImage = saved ? `url(${saved})` : '';
        preview.style.backgroundSize = 'cover';
        delete preview.dataset.avatar;
    }
    const fileInput = document.getElementById('editAvatarInput');
    if (fileInput) fileInput.value = '';
    modal.classList.add('active');
}

document.getElementById('settingsEditBtn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    openEditProfileModal();
});

document.getElementById('closeEditProfileModal')?.addEventListener('click', () => {
    document.getElementById('editProfileModal')?.classList.remove('active');
});
document.getElementById('cancelEditProfileBtn')?.addEventListener('click', () => {
    document.getElementById('editProfileModal')?.classList.remove('active');
});
document.getElementById('editProfileModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'editProfileModal') e.target.classList.remove('active');
});

document.getElementById('editAvatarInput')?.addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
        const preview = document.getElementById('editAvatarPreview');
        if (!preview) return;
        preview.style.backgroundImage = `url(${r.result})`;
        preview.style.backgroundSize = 'cover';
        preview.dataset.avatar = r.result;
    };
    r.readAsDataURL(f);
});

document.getElementById('saveProfileBtn')?.addEventListener('click', () => {
    const username = window.currentUserName || '';
    const displayName = document.getElementById('editDisplayName')?.value.trim() || '';
    const email = document.getElementById('editEmail')?.value.trim() || '';
    const phone = document.getElementById('editPhone')?.value.trim() || '';
    const address = document.getElementById('editAddress')?.value.trim() || '';
    const dob = document.getElementById('editDob')?.value.trim() || '';
    const gender = document.getElementById('editGender')?.value.trim() || '';
    const civil = document.getElementById('editCivil')?.value.trim() || '';
    const nationality = document.getElementById('editNationality')?.value.trim() || '';
    const bureau = document.getElementById('editBureau')?.value.trim() || '';
    const employeeId = document.getElementById('editEmployeeId')?.value.trim() || '';
    const position = document.getElementById('editPosition')?.value.trim() || '';
    const employment = document.getElementById('editEmployment')?.value.trim() || '';
    const plantillaItemNo = document.getElementById('editPlantillaItemNo')?.value.trim() || '';
    const salaryGrade = document.getElementById('editSalaryGrade')?.value.trim() || '';
    const step = document.getElementById('editStep')?.value.trim() || '';
    const dateCreated = document.getElementById('editDateCreated')?.value.trim() || '';
    const avatarInput = document.getElementById('editAvatarInput');
    const avatarFile = avatarInput?.files?.[0] || null;
    const preview = document.getElementById('editAvatarPreview');

    if (!displayName) {
        showToast('Display name is required.', 'error');
        return;
    }

    (async () => {
        let uploadedUrl = null;
        if (avatarFile && username) {
            try {
                const fd = new FormData();
                fd.append('avatar', avatarFile);
                const res = await fetch(`${loginApiBase}/upload_avatar.php`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: withCsrfHeaders(),
                    body: fd
                });
                if (res.ok) {
                    const j = await res.json();
                    if (j.success && j.url) uploadedUrl = j.url;
                }
            } catch (err) {
                console.warn('Avatar upload failed', err);
            }
        }

        const avatarData = uploadedUrl || preview?.dataset.avatar || null;
        if (avatarData && username) {
            localStorage.setItem('avatar_' + username, avatarData);
            applyAvatar(avatarData);
        }

        const prev = loadProfileExtras();
        saveProfileExtras({
            ...prev,
            displayName,
            email,
            phone,
            address,
            dob,
            gender,
            civil,
            nationality,
            bureau,
            fullName: displayName,
            division: bureau,
            employeeId,
            position,
            employment,
            plantillaItemNo,
            salaryGrade,
            step,
            dateCreated
        });

        if (displayName) window.currentUserFullName = displayName;
        if (email) window.currentUserEmail = email;

        renderAccountSettings();
        document.getElementById('editProfileModal')?.classList.remove('active');
        showToast('Profile updated successfully.', 'success');
    })();
});

function closePasswordModal() {
    document.getElementById('changePasswordModal')?.classList.remove('active');
    ['currentPassword', 'newPassword', 'confirmPassword'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
}

document.getElementById('changePasswordBtn')?.addEventListener('click', () => {
    document.getElementById('changePasswordModal')?.classList.add('active');
});
document.getElementById('closeChangePasswordModal')?.addEventListener('click', closePasswordModal);
document.getElementById('cancelChangePasswordBtn')?.addEventListener('click', closePasswordModal);
document.getElementById('changePasswordModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'changePasswordModal') closePasswordModal();
});

document.getElementById('savePasswordBtn')?.addEventListener('click', () => {
    const current = document.getElementById('currentPassword')?.value || '';
    const next = document.getElementById('newPassword')?.value || '';
    const confirm = document.getElementById('confirmPassword')?.value || '';
    if (!current || !next || !confirm) {
        showToast('Please fill in all password fields.', 'error');
        return;
    }
    if (next.length < 6) {
        showToast('New password must be at least 6 characters.', 'error');
        return;
    }
    if (next !== confirm) {
        showToast('New passwords do not match.', 'error');
        return;
    }
    closePasswordModal();
    showToast('Password updated successfully.', 'success');
});

loadCurrentUserAvatar();
renderAccountSettings();

function logout() {
    window.location.href = '../../Login/logout.php';
}

// --- MODAL ---
const addModal = document.getElementById("addItemsModal");
const dropZone = document.getElementById("dropZone");
const fileInput = document.getElementById("fileInput");

if (addModal && dropZone && fileInput) {
    const addBtn = document.getElementById("addItemBtn");
    if (addBtn) {
        if (canManageInventory) {
            addBtn.onclick = () => {
                document.getElementById('newItemName').value = '';
                document.getElementById('newItemStock').value = '';
                document.getElementById('newItemMin').value = '0';
                document.getElementById('newItemCategory').value = '';
                dropZone.querySelector('p').textContent = 'Upload Image';
                dropZone.style.borderColor = '';
                const nextId = inventoryData.reduce((m, i) => Math.max(m, Number(i.id) || 0), 0) + 1;
                document.getElementById('itemID').value = `ITM${String(nextId).padStart(4, '0')}`;
                addModal.classList.add('active');
            };
        } else {
            addBtn.style.display = 'none';
        }
    }

    function closeModal() {
        addModal.classList.remove("active");
    }

    document.getElementById("closeModal").onclick = closeModal;
    document.getElementById("cancelBtn").onclick = closeModal;
    addModal.onclick = (e) => { if (e.target === addModal) closeModal(); };

    dropZone.onclick = () => fileInput.click();
    dropZone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropZone.classList.add("dragover");
    });
    dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragover"));
    dropZone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZone.classList.remove("dragover");
        if (e.dataTransfer.files.length) handleFileUpload(e.dataTransfer.files[0]);
    });
    fileInput.onchange = () => {
        if (fileInput.files.length) handleFileUpload(fileInput.files[0]);
    };

    function handleFileUpload(file) {
        if (file.type.startsWith("image/")) {
            dropZone.querySelector("p").textContent = `Selected: ${file.name}`;
            dropZone.style.borderColor = "#4784ff";
        } else {
            showToast('Please upload an image file.', 'error');
        }
    }

    const minInput = document.getElementById('newItemMin');
    document.querySelector('.spin-arrows .up')?.addEventListener('click', () => {
        minInput.value = String((parseInt(minInput.value, 10) || 0) + 1);
    });
    document.querySelector('.spin-arrows .down')?.addEventListener('click', () => {
        minInput.value = String(Math.max(0, (parseInt(minInput.value, 10) || 0) - 1));
    });

    document.getElementById("saveBtn").onclick = () => {
        const name = document.getElementById("newItemName").value.trim();
        const stock = parseInt(document.getElementById("newItemStock").value, 10) || 0;
        const min = parseInt(document.getElementById("newItemMin").value, 10) || 0;
        const cat = document.getElementById("newItemCategory").value;

        if (name && cat) {
            (async () => {
                try {
                    const response = await fetch(`${inventoryApiBase}?action=add`, {
                        method: 'POST',
                        credentials: 'include',
                        headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                        body: JSON.stringify({ item_name: name, category: cat, stock, min_stock: min })
                    });
                    const data = await response.json();
                    if (!response.ok || !data.success) throw new Error(data.message || 'Unable to add item');
                    await fetchInventory();
                    updateInventoryDependencies();
                    closeModal();
                    showToast("Item added successfully!", 'success');
                } catch (err) {
                    showToast(err.message || 'Could not add item.', 'error');
                }
            })();
        } else {
            showToast("Please fill in the required fields (*).", 'error');
        }
    };
}

async function fetchInventory() {
    try {
        const response = await fetch(`${inventoryApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) throw new Error(`Unable to load inventory (HTTP ${response.status})`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load inventory');
        inventoryData = Array.isArray(data.data) ? data.data : [];
    } catch (err) {
        inventoryData = [];
        showToast(err.message || 'Could not load inventory.', 'error');
    }
}

async function fetchRequests() {
    try {
        const response = await fetch(`${requestsApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) throw new Error(`Unable to load requests (HTTP ${response.status})`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load requests');
        requestsData = Array.isArray(data.data) ? data.data : [];
    } catch (err) {
        requestsData = [];
        console.error(err);
    }
}

const searchInput = document.getElementById("searchInput");
if (searchInput) {
    searchInput.addEventListener("input", () => renderInventory(inventoryFilter));
}

if (!canViewInventory) {
    document.querySelector('.nav li[data-page="inventory"]')?.remove();
}

// --- INIT ---
updateClock();

(async () => {
    await Promise.all([fetchInventory(), fetchRequests(), fetchPpmpData(), fetchDeliveryPackages()]);
    updateInventoryDependencies();
    renderApprovals('all');
    renderDelivery('all');
    renderPpmp();
    renderNotifications();
    initDashboard();

    setInterval(async () => {
        await Promise.all([fetchInventory(), fetchRequests(), fetchPpmpData(), fetchDeliveryPackages()]);
        updateInventoryDependencies();
        renderNotifications();
        initDashboard();
    }, 10000);

    if (window.flashMessage) {
        showToast(window.flashMessage, 'success');
        window.flashMessage = '';
    }
})();
