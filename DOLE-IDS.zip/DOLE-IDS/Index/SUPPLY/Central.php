<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Admin') === 0) {
    header('Location: ../../Index/ADMIN/Admin.php');
    exit;
}

if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Requester') === 0) {
    header('Location: ../../Index/REQUESTOR/REQ.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Approver') !== 0) {
    header('Location: ../../Login/login.php');
    exit;
}

$displayName = $_SESSION['full_name'] ?? $_SESSION['username'];
$displayEmail = $_SESSION['email'] ?? ($_SESSION['username'] . '@dole.gov.ph');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOLE Inventory System — Central</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Central.css">
    <link rel="stylesheet" href="Central.figma.css?v=20260906-profile-edit">
</head>
<body>

<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <img src="assets/figma/logo-dole.png" alt="DOLE Logo" onerror="this.src='../../Images/LOGO.png'">
            <div class="logo-text">Department of Labor and Employment</div>
        </div>
        <div class="profile" id="profileCard" title="<?php echo htmlspecialchars($displayName); ?>">
            <div class="avatar"></div>
            <div class="profile-info">
                <h4><?php echo htmlspecialchars($displayName); ?></h4>
                <p><?php echo htmlspecialchars($displayEmail); ?></p>
            </div>
        </div>
        <p class="nav-label">NAVIGATION</p>
        <ul class="nav">
            <li class="active" data-page="dashboard"><span class="nav-icon"></span> Dashboard</li>
            <li data-page="notifications"><span class="nav-icon"></span> Notifications</li>
            <li data-page="inventory"><span class="nav-icon"></span> Inventory</li>
            <li data-page="catalog"><span class="nav-icon"></span> Catalog Management</li>
            <li data-page="approvals"><span class="nav-icon"></span> Request Approvals</li>
            <li class="nav-sub" data-page="ppmp"><span class="nav-icon"></span> PPMP Management</li>
            <li data-page="delivery"><span class="nav-icon"></span> Delivery</li>
        </ul>
        <ul class="nav-logout">
            <li data-page="logout"><span class="nav-icon"></span> Log out</li>
        </ul>
    </aside>

    <main class="main">
        <header class="topbar">
            <div class="topbar-left">
                <h2 id="page-title">Dashboard</h2>
                <p class="subtitle" id="page-subtitle">View system summaries and recent activities</p>
            </div>
            <div class="time">
                <p>Philippine Standard Time:</p>
                <span id="clock"></span>
            </div>
        </header>

        <section id="dashboard" class="page active">
            <div class="stats">
                <div class="stat-card" data-goto="approvals" data-filter="today">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-request-stat.png" alt="" width="22" height="22">
                        <span>Requests Today</span>
                    </div>
                    <h1 id="requestsCount">00</h1>
                    <a href="#" class="card-link dashboard-arrow" data-page="approvals" data-filter="today">
                        <img src="assets/figma/icon-arrow-card.svg" alt="">
                    </a>
                </div>
                <div class="stat-card" data-goto="approvals" data-filter="pending">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-pending-stat.png" alt="" width="15" height="16">
                        <span>Pending Approvals</span>
                    </div>
                    <h1 id="approvalsCount">00</h1>
                    <a href="#" class="card-link dashboard-arrow" data-page="approvals" data-filter="pending">
                        <img src="assets/figma/icon-arrow-card.svg" alt="">
                    </a>
                </div>
                <div class="stat-card" data-goto="delivery">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-delivery-stat.png" alt="" width="15" height="15">
                        <span>Active Deliveries</span>
                    </div>
                    <h1 id="deliveriesCount">00</h1>
                    <a href="#" class="card-link dashboard-arrow" data-page="delivery">
                        <img src="assets/figma/icon-arrow-card.svg" alt="">
                    </a>
                </div>
            </div>

            <div class="dashboard-lower">
                <div class="dashboard-box">
                    <div class="box-title">
                        <img class="box-icon" src="assets/figma/icon-low-stock.png" alt="" width="33" height="33">
                        Low Stock
                        <p class="box-subtitle">Items needing restock</p>
                        <a href="#" class="card-link dashboard-arrow" data-page="inventory" data-filter="low">
                            <img src="assets/figma/icon-arrow-card.svg" alt="">
                        </a>
                    </div>
                    <ul id="lowStockList" class="dashboard-list"></ul>
                </div>
                <div class="dashboard-box">
                    <div class="box-title">
                        <img class="box-icon" src="assets/figma/icon-out-stock.png" alt="" width="30" height="32">
                        Out of Stock
                        <p class="box-subtitle">Immediate restock</p>
                        <a href="#" class="card-link dashboard-arrow" data-page="inventory" data-filter="out">
                            <img src="assets/figma/icon-arrow-card.svg" alt="">
                        </a>
                    </div>
                    <ul id="outStockList" class="dashboard-list"></ul>
                </div>
            </div>
        </section>

        <section id="inventory" class="page">
            <div class="page-tabs" id="inventoryTabs">
                <button type="button" class="page-tab active" data-filter="all">All <span class="count" id="inv-cnt-all">(0)</span></button>
                <button type="button" class="page-tab" data-filter="in">In Stock <span class="count" id="inv-cnt-in">(0)</span></button>
                <button type="button" class="page-tab" data-filter="low">Low Stock <span class="count" id="inv-cnt-low">(0)</span></button>
                <button type="button" class="page-tab" data-filter="out">Out of Stock <span class="count" id="inv-cnt-out">(0)</span></button>
            </div>
            <div class="toolbar-row">
                <div class="search-wrapper">
                    <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                    <input id="searchInput" placeholder="Search by RIS, Item...">
                </div>
                <div class="toolbar-actions">
                    <button id="addItemBtn" class="blue-btn" type="button">+ Add Item</button>
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="inventoryMoreBtn" title="More" aria-haspopup="true">☰</button>
                        <div class="action-menu" id="inventoryMoreMenu">
                            <button type="button" data-action="sort-name">Sort by Name</button>
                            <button type="button" data-action="sort-stock">Sort by Stock</button>
                            <button type="button" data-action="sort-status">Sort by Status</button>
                            <div class="menu-sep"></div>
                            <button type="button" data-action="sort-reset">Reset Sort</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="inventory-table-container">
                <table class="inventory-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Category</th>
                            <th>In Stock</th>
                            <th>Status</th>
                            <th>Last Modified</th>
                            <th>Manage Stock</th>
                        </tr>
                    </thead>
                    <tbody id="inventoryTable"></tbody>
                </table>
            </div>
        </section>

        <section id="catalog" class="page">
            <div class="toolbar-row">
                <div class="search-wrapper">
                    <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                    <input id="catalogSearchInput" placeholder="Search by RIS, Item...">
                </div>
                <div class="toolbar-actions">
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="catalogFilterBtn">Filter ▾</button>
                        <div class="action-menu" id="catalogFilterMenu">
                            <button type="button" data-filter="all" class="active">All Items</button>
                            <button type="button" data-filter="in">Available</button>
                            <button type="button" data-filter="low">Low Stock</button>
                            <button type="button" data-filter="out">Unavailable</button>
                            <div class="menu-sep"></div>
                            <button type="button" data-filter="Paper Products">Paper Products</button>
                            <button type="button" data-filter="Writing Supplies">Writing Supplies</button>
                            <button type="button" data-filter="Office Supplies">Office Supplies</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="catalog-grid" id="catalogGrid"></div>
        </section>

        <section id="approvals" class="page">
            <div class="approvals-top-actions">
                <div class="filter-tabs">
                    <div class="tab active" data-filter="all" data-color="blue">All <span class="count" id="cnt-all">(00)</span></div>
                    <div class="tab" data-filter="today" data-color="yellow">Today <span class="count" id="cnt-today">(00)</span></div>
                    <div class="tab" data-filter="pending" data-color="orange">Pending <span class="count" id="cnt-pending">(00)</span></div>
                    <div class="tab" data-filter="approved" data-color="green">Approved <span class="count" id="cnt-approved">(00)</span></div>
                    <div class="tab" data-filter="declined" data-color="red">Declined <span class="count" id="cnt-declined">(00)</span></div>
                </div>
                <div class="toolbar-row" style="margin-bottom:0;">
                    <div class="search-wrapper">
                        <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                        <input id="approvalsSearchInput" placeholder="Search by RIS, Item...">
                    </div>
                    <div class="action-buttons">
                        <button class="circle-btn history-btn" type="button" id="openRequestHistoryBtn" title="Request history" aria-label="Request history">▣</button>
                        <div class="menu-wrap">
                            <button class="circle-btn" type="button" id="approvalsSortBtn">Sort ▾</button>
                            <div class="action-menu" id="approvalsSortMenu">
                                <button type="button" data-sort="newest" class="active">Newest first</button>
                                <button type="button" data-sort="oldest">Oldest first</button>
                                <button type="button" data-sort="ris">RIS number</button>
                                <button type="button" data-sort="office">Office / Branch</button>
                            </div>
                        </div>
                        <div class="menu-wrap">
                            <button class="circle-btn" type="button" id="approvalsFilterBtn">Filter ▾</button>
                            <div class="action-menu" id="approvalsFilterMenu">
                                <button type="button" data-extra="all" class="active">All offices</button>
                                <button type="button" data-extra="Batangas">Batangas</button>
                                <button type="button" data-extra="Cavite">Cavite</button>
                                <button type="button" data-extra="Rizal">Rizal</button>
                                <button type="button" data-extra="Quezon">Quezon</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="approvals-grid" id="approvalsGrid"></div>
        </section>

        <section id="history" class="page">
            <div class="history-toolbar">
                <button class="back-btn" type="button" id="historyBackBtn" aria-label="Back to approvals">‹ Back</button>
                <div class="history-actions">
                    <label class="date-field">From <input type="date" id="historyStartDate"></label>
                    <label class="date-field">To <input type="date" id="historyEndDate"></label>
                    <button class="clear-date-btn" type="button" id="clearHistoryDates">Clear</button>
                </div>
            </div>
            <div class="history-summary" id="historySummary"></div>
            <div class="approvals-grid" id="historyGrid"></div>
        </section>

        <section id="ppmp" class="page">
            <div class="toolbar-row">
                <div class="search-wrapper">
                    <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                    <input id="ppmpSearchInput" placeholder="Search">
                </div>
                <div class="toolbar-actions">
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="ppmpYearBtn">Fiscal Year ▾</button>
                        <div class="action-menu" id="ppmpYearMenu">
                            <button type="button" data-value="all" class="active">All</button>
                            <button type="button" data-value="2026">2026</button>
                            <button type="button" data-value="2025">2025</button>
                            <button type="button" data-value="2024">2024</button>
                        </div>
                    </div>
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="ppmpOfficeBtn">Province ▾</button>
                        <div class="action-menu" id="ppmpOfficeMenu">
                            <button type="button" data-value="all" class="active">All</button>
                            <button type="button" data-value="Batangas">Batangas</button>
                            <button type="button" data-value="Cavite">Cavite</button>
                            <button type="button" data-value="Laguna">Laguna</button>
                            <button type="button" data-value="Rizal">Rizal</button>
                            <button type="button" data-value="Quezon">Quezon</button>
                        </div>
                    </div>
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="ppmpUnitBtn">Unit ▾</button>
                        <div class="action-menu" id="ppmpUnitMenu">
                            <button type="button" data-value="all" class="active">All</button>
                            <button type="button" data-value="ADMIN">ADMIN</button>
                            <button type="button" data-value="HR">HR</button>
                            <button type="button" data-value="SUPPLY">SUPPLY</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ppmp-panel">
                <table class="inventory-table" id="ppmpTable">
                    <thead>
                        <tr>
                            <th>Fiscal Year</th>
                            <th>Province</th>
                            <th>Unit</th>
                            <th>Item</th>
                            <th>Qty</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="ppmpTableBody"></tbody>
                </table>
            </div>
        </section>

        <section id="delivery" class="page">
            <div class="page-tabs" id="deliveryTabs">
                <button type="button" class="page-tab active" data-filter="all">All <span class="count" id="del-cnt-all">(0)</span></button>
                <button type="button" class="page-tab" data-filter="preparing">Preparing <span class="count" id="del-cnt-preparing">(0)</span></button>
                <button type="button" class="page-tab" data-filter="shipped">Shipped <span class="count" id="del-cnt-shipped">(0)</span></button>
                <button type="button" class="page-tab" data-filter="delivered">Delivered <span class="count" id="del-cnt-delivered">(0)</span></button>
                <button type="button" class="page-tab" data-filter="cancelled">Cancelled <span class="count" id="del-cnt-cancelled">(0)</span></button>
                <button type="button" class="page-tab" data-filter="returned">Returned <span class="count" id="del-cnt-returned">(0)</span></button>
            </div>
            <div class="toolbar-row">
                <div class="search-wrapper">
                    <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                    <input id="deliverySearchInput" placeholder="Search by RIS, Item...">
                </div>
                <div class="toolbar-actions">
                    <button class="circle-btn history-btn" type="button" id="openDeliveryHistoryBtn" title="Delivery history" aria-label="Delivery history">▣</button>
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="deliverySortBtn">Sort ▾</button>
                        <div class="action-menu" id="deliverySortMenu">
                            <button type="button" data-sort="newest" class="active">Newest first</button>
                            <button type="button" data-sort="oldest">Oldest first</button>
                            <button type="button" data-sort="office">Office</button>
                            <button type="button" data-sort="status">Status</button>
                        </div>
                    </div>
                    <div class="menu-wrap">
                        <button type="button" class="ghost-btn" id="deliveryFilterBtn">Filter ▾</button>
                        <div class="action-menu" id="deliveryFilterMenu">
                            <button type="button" data-extra="all" class="active">All offices</button>
                            <button type="button" data-extra="Batangas">Batangas</button>
                            <button type="button" data-extra="Cavite">Cavite</button>
                            <button type="button" data-extra="Rizal">Rizal</button>
                            <button type="button" data-extra="Quezon">Quezon</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="delivery-label-bar">
                <span>Item</span>
                <span>Driver</span>
                <span>Status</span>
                <span>Action</span>
            </div>
            <div class="delivery-list" id="deliveryList"></div>
        </section>

        <section id="deliveryHistory" class="page">
            <div class="history-toolbar">
                <button class="back-btn" type="button" id="deliveryHistoryBackBtn" aria-label="Back to deliveries">‹ Back</button>
                <div class="history-actions">
                    <label class="date-field">From <input type="date" id="deliveryHistoryStartDate"></label>
                    <label class="date-field">To <input type="date" id="deliveryHistoryEndDate"></label>
                    <button class="clear-date-btn" type="button" id="clearDeliveryHistoryDates">Clear</button>
                </div>
            </div>
            <div class="history-summary" id="deliveryHistorySummary"></div>
            <div class="delivery-label-bar">
                <span>Item</span>
                <span>Driver</span>
                <span>Status</span>
                <span>Action</span>
            </div>
            <div class="delivery-list" id="deliveryHistoryList"></div>
        </section>

        <section id="notifications" class="page">
            <p class="empty-state">No notifications yet.</p>
        </section>

        <section id="profile" class="page">
            <div class="account-settings">
                <div class="settings-profile-card">
                    <button type="button" class="settings-edit-btn" id="settingsEditBtn" title="Edit profile" aria-label="Edit profile">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9a2.1 2.1 0 0 0-4-4L4 16v4Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="m13.5 6.5 4 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        <span>Edit Profile</span>
                    </button>
                    <div class="settings-profile-main">
                        <div class="settings-avatar" id="settingsAvatar"></div>
                        <div class="settings-profile-info">
                            <h3 id="settingsDisplayName"><?php echo htmlspecialchars($displayName); ?></h3>
                            <p class="settings-role" id="settingsRole"><?php echo htmlspecialchars($_SESSION['role'] ?? 'Approver'); ?></p>
                            <p class="settings-bureau" id="settingsBureau">Procurement and Supply Division</p>
                            <p class="settings-org">Department of Labor and Employment</p>
                            <span class="settings-active-badge">Active</span>
                        </div>
                    </div>
                    <div class="settings-profile-contact">
                        <div class="settings-contact-row">
                            <span class="settings-contact-icon" aria-hidden="true">
                                <svg width="12" height="10" viewBox="0 0 12 10" fill="none"><path d="M1 2.2 5.2 5.1c.5.35 1.1.35 1.6 0L11 2.2M1.5 9h9A1.5 1.5 0 0 0 12 7.5v-5A1.5 1.5 0 0 0 10.5 1h-9A1.5 1.5 0 0 0 0 2.5v5A1.5 1.5 0 0 0 1.5 9Z" stroke="#5E5E5E" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <span id="settingsEmail"><?php echo htmlspecialchars($displayEmail); ?></span>
                        </div>
                        <div class="settings-contact-row">
                            <span class="settings-contact-icon" aria-hidden="true">
                                <svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M9.7 7.4v1.2a1 1 0 0 1-1.1 1A9.6 9.6 0 0 1 1.4 2.4a1 1 0 0 1 1-1.1h1.2a1 1 0 0 1 1 .8c.1.6.2 1.1.4 1.6a1 1 0 0 1-.2 1L4.3 5.2a7.7 7.7 0 0 0 1.5 1.5l.5-.5a1 1 0 0 1 1-.2c.5.2 1 .3 1.6.4a1 1 0 0 1 .8 1Z" stroke="#5E5E5E" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <span id="settingsPhone">+63 9123456789</span>
                        </div>
                        <div class="settings-contact-row">
                            <span class="settings-contact-icon" aria-hidden="true">
                                <svg width="10" height="12" viewBox="0 0 10 12" fill="none"><path d="M5 6.2a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2Z" stroke="#5E5E5E"/><path d="M5 1C2.8 1 1 2.7 1 4.8 1 7.5 5 11 5 11s4-3.5 4-6.2C9 2.7 7.2 1 5 1Z" stroke="#5E5E5E" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <span id="settingsAddress">Calamba City, Laguna, Parian</span>
                        </div>
                    </div>
                </div>

                <div class="settings-lower">
                    <div class="settings-lower-left">
                        <div class="settings-info-card">
                            <h4>Personal Information</h4>
                            <div class="settings-info-grid settings-info-grid-5">
                                <div class="settings-field">
                                    <span class="settings-label">Full Name</span>
                                    <strong id="settingsFullName"><?php echo htmlspecialchars($displayName); ?></strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Date of Birth</span>
                                    <strong id="settingsDob">June 13, 2003</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Gender</span>
                                    <strong id="settingsGender">Male</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Civil Status</span>
                                    <strong id="settingsCivil">Single</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Nationality</span>
                                    <strong id="settingsNationality">Filipino</strong>
                                </div>
                            </div>
                        </div>

                        <div class="settings-info-card settings-work-card">
                            <h4>Work Information</h4>
                            <div class="settings-info-grid settings-info-grid-4">
                                <div class="settings-field">
                                    <span class="settings-label">Employee ID</span>
                                    <strong id="settingsEmployeeId">DOLE-2026-00013</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Position</span>
                                    <strong id="settingsPosition">Supply Officer</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Division/ Unit</span>
                                    <strong id="settingsDivision">Procurement and Supply Division</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Employment Status</span>
                                    <strong id="settingsEmployment">Permanent</strong>
                                </div>
                            </div>
                            <div class="settings-info-grid settings-info-grid-4 settings-work-row-2">
                                <div class="settings-field">
                                    <span class="settings-label">Plantilla Item No.</span>
                                    <strong id="settingsPlantillaItemNo">DOL-BWC-2026-078</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Salary Grade</span>
                                    <strong id="settingsSalaryGrade">SG 15</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Step Increment</span>
                                    <strong id="settingsStep">3</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Date Created</span>
                                    <strong id="settingsDateCreated">June 5, 2026</strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="settings-security-card">
                        <h4>Security Settings</h4>
                        <div class="settings-field">
                            <span class="settings-label">Username <span class="req">*</span></span>
                            <strong id="settingsUsername"><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></strong>
                        </div>
                        <div class="settings-field settings-password-field">
                            <span class="settings-label">Password</span>
                            <strong id="settingsPassword">************</strong>
                        </div>
                        <button type="button" class="settings-password-btn" id="changePasswordBtn">Change Password</button>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>

<div class="modal-overlay" id="addItemsModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeModal">←</button>
            <h3>Add Items</h3>
        </div>
        <div class="modal-body">
            <div class="drop-zone" id="dropZone">
                <div class="drop-content">
                    <span class="upload-icon">☁️</span>
                    <p>Upload Image</p>
                </div>
                <input type="file" id="fileInput" hidden>
            </div>
            
            <div class="form-group">
                <label>ITEM ID</label>
                <input type="text" id="itemID" value="ITM0014" readonly class="readonly-input">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Item <span class="req">*</span></label>
                    <input type="text" placeholder="Item" id="newItemName">
                </div>
                <div class="form-group">
                    <label>Category <span class="req">*</span></label>
                    <div class="select-box">
                        <select id="newItemCategory">
                            <option value="">Category</option>
                            <option value="Paper Products">Paper Products</option>
                            <option value="Writing Supplies">Writing Supplies</option>
                            <option value="Office Supplies">Office Supplies</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>In Stock</label>
                    <input type="text" placeholder="In Stock" id="newItemStock">
                </div>
                <div class="form-group">
                    <label>Minimum Stock <span class="req">*</span></label>
                    <div class="number-input">
                        <input type="number" value="0" id="newItemMin">
                        <div class="spin-arrows">
                            <span class="up">▲</span>
                            <span class="down">▼</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelBtn">Cancel</button>
            <button class="btn-save" id="saveBtn">Save</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="requestDetailsModal">
    <div class="modal" style="width:480px;max-width:94vw;">
        <div class="modal-header">
            <button class="modal-back" id="closeRequestDetails" type="button">←</button>
            <h3>Request Details</h3>
        </div>
        <div class="modal-body">
            <div class="detail-grid">
                <div class="detail-field">
                    <label>RIS Number</label>
                    <p id="detailRis">—</p>
                </div>
                <div class="detail-field">
                    <label>Status</label>
                    <p><span id="detailStatus" class="status-badge-inline pending">Pending</span></p>
                </div>
                <div class="detail-field">
                    <label>Item</label>
                    <p id="detailItem">—</p>
                </div>
                <div class="detail-field">
                    <label>Quantity</label>
                    <p id="detailQty">—</p>
                </div>
                <div class="detail-field">
                    <label>From</label>
                    <p id="detailFrom">—</p>
                </div>
                <div class="detail-field">
                    <label>Date Requested</label>
                    <p id="detailDate">—</p>
                </div>
                <div class="detail-field" style="grid-column:1/-1;">
                    <label>Note / Purpose</label>
                    <p id="detailNote">—</p>
                </div>
            </div>
            <div class="detail-actions" id="requestActionButtons">
                <button type="button" id="declineRequestBtn" class="btn-decline">Decline</button>
                <button type="button" id="approveRequestBtn" class="blue-btn">Approve</button>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="editProfileModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeEditProfileModal" type="button">←</button>
            <h3>Edit Profile</h3>
        </div>
        <div class="modal-body">
            <div style="display:flex; gap:16px; align-items:center; margin-bottom:12px;">
                <div id="editAvatarPreview" style="width:72px; height:72px; border-radius:50%; background:#ddd; background-size:cover; flex-shrink:0;"></div>
                <div>
                    <label class="form-group" style="margin-bottom:6px;">Image (square)</label>
                    <input type="file" id="editAvatarInput" accept="image/*">
                </div>
            </div>
            <div class="form-group">
                <label>Display Name</label>
                <input type="text" id="editDisplayName" placeholder="Full name">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="editEmail" placeholder="Email">
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" id="editPhone" placeholder="Phone number">
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" id="editAddress" placeholder="Address">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="text" id="editDob" placeholder="June 13, 2003">
                </div>
                <div class="form-group">
                    <label>Gender</label>
                    <input type="text" id="editGender" placeholder="Male">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Civil Status</label>
                    <input type="text" id="editCivil" placeholder="Single">
                </div>
                <div class="form-group">
                    <label>Nationality</label>
                    <input type="text" id="editNationality" placeholder="Filipino">
                </div>
            </div>
            <div class="form-group">
                <label>Bureau / Unit</label>
                <input type="text" id="editBureau" placeholder="Procurement and Supply Division">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Employee ID</label>
                    <input type="text" id="editEmployeeId" placeholder="Employee ID">
                </div>
                <div class="form-group">
                    <label>Position</label>
                    <input type="text" id="editPosition" placeholder="Position">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Employment Status</label>
                    <input type="text" id="editEmployment" placeholder="Permanent">
                </div>
                <div class="form-group">
                    <label>Plantilla Item No.</label>
                    <input type="text" id="editPlantillaItemNo" placeholder="Plantilla item number">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Salary Grade</label>
                    <input type="text" id="editSalaryGrade" placeholder="SG 15">
                </div>
                <div class="form-group">
                    <label>Step Increment</label>
                    <input type="text" id="editStep" placeholder="3">
                </div>
            </div>
            <div class="form-group">
                <label>Date Created</label>
                <input type="text" id="editDateCreated" placeholder="June 5, 2026">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelEditProfileBtn" type="button">Cancel</button>
            <button class="btn-save" id="saveProfileBtn" type="button">Update Information</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="changePasswordModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeChangePasswordModal" type="button">←</button>
            <h3>Change Password</h3>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Current Password <span class="req">*</span></label>
                <input type="password" id="currentPassword" placeholder="Current password">
            </div>
            <div class="form-group">
                <label>New Password <span class="req">*</span></label>
                <input type="password" id="newPassword" placeholder="New password">
            </div>
            <div class="form-group">
                <label>Confirm New Password <span class="req">*</span></label>
                <input type="password" id="confirmPassword" placeholder="Confirm new password">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelChangePasswordBtn" type="button">Cancel</button>
            <button class="btn-save" id="savePasswordBtn" type="button">Update Password</button>
        </div>
    </div>
</div>

<div id="toastMessage" class="toast-message"></div>

<script>
    window.currentUserRole = <?php echo json_encode($_SESSION['role'] ?? ''); ?>;
    window.currentUserName = <?php echo json_encode($_SESSION['username'] ?? ''); ?>;
    window.currentUserFullName = <?php echo json_encode($displayName); ?>;
    window.currentUserEmail = <?php echo json_encode($displayEmail); ?>;
    window.flashMessage = <?php echo json_encode($_SESSION['flash_message'] ?? ''); ?>;
    <?php if (!empty($_SESSION['flash_message'])) unset($_SESSION['flash_message']); ?>
</script>
<script src="Central.js?v=20260911-qr-code-layout"></script>
</body>
</html>
