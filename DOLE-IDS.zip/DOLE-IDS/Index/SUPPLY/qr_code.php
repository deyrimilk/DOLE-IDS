<?php
$data = trim((string)($_GET['data'] ?? ''));
if ($data === '' || strlen($data) > 1000) {
    http_response_code(400);
    exit('Missing or invalid QR data');
}

$remoteUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=320x320&format=png&data=' . rawurlencode($data);
$image = false;

if (function_exists('curl_init')) {
    $curl = curl_init($remoteUrl);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_USERAGENT => 'DOLE-IDS QR renderer',
    ]);
    $image = curl_exec($curl);
    curl_close($curl);
} elseif (ini_get('allow_url_fopen')) {
    $image = @file_get_contents($remoteUrl);
}

if (!is_string($image) || $image === '') {
    http_response_code(502);
    exit('QR image service unavailable');
}

header('Content-Type: image/png');
header('Cache-Control: public, max-age=3600');
echo $image;
