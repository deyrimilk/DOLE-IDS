// ============================================================
// API BASE PATHS
// ============================================================

const appRoot = (() => {
    return new URL('../../', window.location.href).pathname.replace(/\/$/, '');
})();

const inventoryApiBase = `${window.location.origin}${appRoot}/ppmp/ppmp_api.php`;
const supplyInventoryApiBase = `${window.location.origin}${appRoot}/Inventory/inventory.php`;
const requestsApiBase = `${window.location.origin}${appRoot}/Requests/requests.php`;
const deliveryApiBase = `${window.location.origin}${appRoot}/Index/DELIVERY/delivery_api.php`;
const ppmpApiBase = `${window.location.origin}${appRoot}/ppmp/ppmp_api.php`;

function getCsrfToken() {
    const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : '';
}

function withCsrfHeaders(headers = {}) {
    return {
        ...headers,
        'X-CSRF-Token': getCsrfToken()
    };
}

let items = [];
let requests = [];
let inventoryAudit = [];
let cartItems = [];
let requestorNotifications = [];
let requestorNotificationFilter = 'all';
let requestorReadNotifications = new Set(JSON.parse(localStorage.getItem('dole_requestor_read_notifications_v1') || '[]'));
let requestorDeliveryRecords = [];
let ppmpRequests = [];
let requestType = 'items';
const requestorProvince = String(window.requestorProvince || '').trim();
const requestorLoginApiBase = `${window.location.origin}${appRoot}/Login`;

// ============================================================
// PAGE MANAGEMENT
// ============================================================

function showPage(pageName) {
    document.querySelectorAll('.page').forEach(page => page.classList.add('hidden'));

    const selectedPage = document.getElementById(pageName + '-page');
    if (selectedPage) selectedPage.classList.remove('hidden');

    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    const activeNav = document.getElementById('nav-' + pageName);
    if (activeNav) activeNav.classList.add('active');

    if (pageName === 'request') {
        Promise.all([fetchInventory(), fetchInventoryAudit()]).then(() => {
            renderItems();
            renderInventoryAudit();
        });
    }

    if (pageName === 'deliveries') {
        syncRequestorDeliveryStatus().then(() => {
            renderDeliveryStatusPanel();
            renderDeliveryHistory();
        });
    }

    if (pageName === 'my-requests') {
        Promise.all([fetchMyRequests(), fetchPpmpRequests()]).then(() => renderCurrentRequestType());
    }
}

// ============================================================
// HELPERS
// ============================================================

function stockStatus(stock, minStock) {
    const s = Number(stock) || 0;
    const m = Number(minStock) || 0;
    if (s <= 0) return 'Out of Stock';
    if (s <= m) return 'Low Stock';
    return 'In Stock';
}

function formatRis(id, risNumber = '') {
    return risNumber || `RIS-${String(id).padStart(8, '0')}`;
}

function formatShortDate(value) {
    if (!value) return '—';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const yy = String(d.getFullYear()).slice(-2);
    return `${mm}-${dd}-${yy}`;
}

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function readDeliveryRecord() {
    try {
        const raw = localStorage.getItem('dole_delivery_record_v1');
        return raw ? JSON.parse(raw) : null;
    } catch {
        return null;
    }
}

function updateProvinceBadge() {
    const badge = document.getElementById('requestorProvinceBadge');
    if (!badge) return;
    badge.textContent = requestorProvince ? `Province: ${requestorProvince}` : 'Province: —';
}

function updateInTransitDeliveryStat() {
    const stat = document.getElementById('statInTransitDeliveries');
    if (!stat) return;
    stat.textContent = String(requests.filter(request => String(request.status || '').toLowerCase() === 'in transit').length);
}

async function syncRequestorDeliveryStatus() {
    const requestDeliveryMap = new Map();

    try {
        const [activeResponse, completedResponse] = await Promise.all([
            fetch(`${deliveryApiBase}?action=list`, { credentials: 'include' }),
            fetch(`${deliveryApiBase}?action=list_completed`, { credentials: 'include' })
        ]);

        const activePayload = activeResponse.ok ? await activeResponse.json() : null;
        const completedPayload = completedResponse.ok ? await completedResponse.json() : null;

        if (activePayload?.success && Array.isArray(activePayload.data)) {
            activePayload.data.forEach((row) => {
                let requestId = Number(row.request_id ?? 0) || 0;
                if (!requestId && typeof row.package_id === 'string') {
                    const match = row.package_id.match(/^PKG-(\d+)$/i);
                    if (match) requestId = Number(match[1]) || 0;
                }
                if (!requestId) return;

                const status = String(row.status || 'ready').toLowerCase();
                const normalizedStatus = status === 'ready'
                    ? 'Ready'
                    : status === 'picked'
                        ? 'Picked Up'
                        : status === 'delivering' || status === 'shipped'
                            ? 'In Transit'
                            : status === 'completed'
                                ? 'Delivered'
                                : status === 'cancelled'
                                    ? 'Cancelled'
                                    : status === 'returned'
                                        ? 'Returned'
                                        : '—';

                requestDeliveryMap.set(requestId, {
                    packageId: row.package_id || row.id || '—',
                    office: requestorProvince || row.office || 'Office',
                    item: row.item_name || row.item || 'Unknown item',
                    eta: row.eta || '—',
                    status: normalizedStatus,
                    updatedAt: row.updated_at || row.created_at || new Date().toISOString()
                });
            });
        }

        if (completedPayload?.success && Array.isArray(completedPayload.data)) {
            completedPayload.data.forEach((row) => {
                let requestId = Number(row.request_id ?? 0) || 0;
                if (!requestId && typeof row.package_id === 'string') {
                    const match = row.package_id.match(/^PKG-(\d+)$/i);
                    if (match) requestId = Number(match[1]) || 0;
                }
                if (!requestId) return;

                requestDeliveryMap.set(requestId, {
                    packageId: row.package_id || row.id || '—',
                    office: requestorProvince || row.office || 'Office',
                    item: row.item_name || row.item || 'Unknown item',
                    eta: row.eta || '—',
                    status: 'Delivered',
                    updatedAt: row.completed_at || row.delivered_at || row.updated_at || row.created_at || new Date().toISOString()
                });
            });
        }
    } catch (error) {
        console.warn('Requestor delivery sync fell back to local record.', error);
    }

    requestorDeliveryRecords = Array.from(requestDeliveryMap.entries()).map(([requestId, delivery]) => ({
        requestId,
        ...delivery
    }));

    if (!requests.length) {
        updateInTransitDeliveryStat();
        return;
    }

    requests = requests.map((request) => {
        const requestId = Number(request.rawId || 0);
        if (!requestId || !requestDeliveryMap.has(requestId)) {
            return request;
        }

        const deliveryState = requestDeliveryMap.get(requestId);
        const nextRequest = {
            ...request,
            status: deliveryState.status,
        };

        if (deliveryState.packageId && deliveryState.packageId !== '—') {
            localStorage.setItem('dole_delivery_record_v1', JSON.stringify({
                id: deliveryState.packageId,
                requestId,
                office: deliveryState.office,
                item: deliveryState.item,
                eta: deliveryState.eta,
                status: String(deliveryState.status).toLowerCase().replace(/\s+/g, '_'),
                updatedAt: deliveryState.updatedAt
            }));
        }

        return nextRequest;
    });
    updateInTransitDeliveryStat();

    renderRequests();
}

function renderDeliveryStatusPanel() {
    const panel = document.getElementById('deliveryStatusPanel');
    if (!panel) return;

    const requestIds = new Set(requests.map(request => Number(request.rawId || 0)));
    const record = requestorDeliveryRecords
        .filter(delivery => requestIds.has(Number(delivery.requestId)))
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))[0];

    if (!record || !['ready', 'picked', 'delivering', 'shipped', 'completed', 'cancelled', 'returned'].includes(String(record.status || '').toLowerCase())) {
        panel.innerHTML = `
            <p class="delivery-panel-label">Latest delivery update</p>
            <div class="delivery-panel-empty">No pickup has been scanned yet.</div>
        `;
        return;
    }

    const statusLabel = record.status === 'ready'
        ? 'Ready'
        : record.status === 'picked'
            ? 'Picked Up'
            : record.status === 'delivering' || record.status === 'shipped'
                ? 'In Transit'
                : record.status === 'completed'
                    ? 'Delivered'
                    : record.status === 'cancelled'
                        ? 'Cancelled'
                        : record.status === 'returned'
                            ? 'Returned'
                            : 'No update';
    panel.innerHTML = `
        <p class="delivery-panel-label">Latest delivery update</p>
        <div class="delivery-panel-card">
            <div class="delivery-panel-row">
                <strong>Package:</strong>
                <span>${escapeHtml(record.packageId || record.id || 'Unknown')}</span>
            </div>
            <div class="delivery-panel-row">
                <strong>Status:</strong>
                <span>${escapeHtml(statusLabel)}</span>
            </div>
            <div class="delivery-panel-row">
                <strong>Updated:</strong>
                <span>${escapeHtml(new Date(record.updatedAt || Date.now()).toLocaleTimeString())}</span>
            </div>
        </div>
    `;
}

function showToast(message, type = 'info') {
    let toast = document.getElementById('reqToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'reqToast';
        toast.className = 'req-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = `req-toast show ${type}`;
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => toast.classList.remove('show'), 2800);
}

function parseItemDetails(value) {
    if (!value) return [];
    try {
        const parsed = JSON.parse(value);
        return Array.isArray(parsed) ? parsed : [];
    } catch {
        return [];
    }
}

function updateCartBadge() {
    const badge = document.getElementById('cartCountBadge');
    if (badge) badge.textContent = String(cartItems.length);
    const cartButton = document.getElementById('cartToggleBtn');
    if (cartButton) cartButton.classList.toggle('has-items', cartItems.length > 0);
}

function openCartDrawer() {
    const drawer = document.getElementById('cartDrawer');
    if (drawer) drawer.classList.add('open');
}

function closeCartDrawer() {
    const drawer = document.getElementById('cartDrawer');
    if (drawer) drawer.classList.remove('open');
}

function openPpmpHistoryDrawer() {
    document.getElementById('ppmpHistoryDrawer')?.classList.add('open');
    fetchInventoryAudit().then(renderInventoryAudit);
}

function closePpmpHistoryDrawer() {
    document.getElementById('ppmpHistoryDrawer')?.classList.remove('open');
}

function renderCart() {
    const list = document.getElementById('cartItemsList');
    const summary = document.getElementById('cartSummary');
    if (!list) return;

    if (!cartItems.length) {
        list.innerHTML = '<div class="cart-empty">Your cart is empty. Add items to begin a request.</div>';
        if (summary) summary.textContent = '0 items';
        updateCartBadge();
        return;
    }

    const totalQty = cartItems.reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);
    if (summary) summary.textContent = `${cartItems.length} item${cartItems.length > 1 ? 's' : ''} • ${totalQty} total qty`;

    list.innerHTML = cartItems.map((item, index) => `
        <div class="cart-item-card">
            <div class="cart-item-main">
                <div>
                    <strong>${escapeHtml(item.name)}</strong>
                    <p>${escapeHtml(item.note || 'No purpose provided')}</p>
                </div>
                <button type="button" class="cart-remove-btn" onclick="removeCartItem(${index})">Remove</button>
            </div>
            <div class="cart-item-footer">
                <label>Qty</label>
                <input type="number" min="1" value="${Number(item.quantity) || 1}" onchange="updateCartItemQty(${index}, this.value)">
            </div>
        </div>
    `).join('');

    updateCartBadge();
}

function addItemToCart(itemPayload) {
    const existingIndex = cartItems.findIndex(item => Number(item.id) === Number(itemPayload.id));
    if (existingIndex >= 0) {
        cartItems[existingIndex].quantity = Number(cartItems[existingIndex].quantity || 0) + Number(itemPayload.quantity || 1);
        cartItems[existingIndex].note = itemPayload.note || cartItems[existingIndex].note || '';
    } else {
        cartItems.push(itemPayload);
    }
    renderCart();
    showToast('Item added to cart.', 'success');
}

function removeCartItem(index) {
    cartItems.splice(index, 1);
    renderCart();
}

function updateCartItemQty(index, value) {
    const qty = Number(value);
    if (!Number.isFinite(qty) || qty < 1) {
        cartItems[index].quantity = 1;
    } else {
        cartItems[index].quantity = qty;
    }
    renderCart();
}

async function submitCartRequest() {
    if (!cartItems.length) {
        showToast('Your cart is empty.', 'error');
        return;
    }

    const submitBtn = document.getElementById('submitCartBtn');
    if (submitBtn) submitBtn.disabled = true;

    try {
        const response = await fetch(`${requestsApiBase}?action=create`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({
                items: cartItems.map(item => ({
                    item_id: Number(item.id),
                    item_name: item.name,
                    quantity: Number(item.quantity) || 1,
                    note: item.note || ''
                }))
            })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to submit cart request');

        const requestId = Number(data.data?.id || 0);
        cartItems = [];
        renderCart();
        closeCartDrawer();
        showToast('Request submitted for approval.', 'success');
        await fetchMyRequests();
        if (requestId) {
            window.open(`${requestsApiBase}?action=download_ris&id=${requestId}`, '_blank');
        }
    } catch (err) {
        showToast(err.message || 'Could not submit your request.', 'error');
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

// ============================================================
// DATA FETCHING
// ============================================================

async function fetchInventory() {
    try {
        const [supplyResponse, ppmpResponse] = await Promise.all([
            fetch(`${supplyInventoryApiBase}?action=list`, { credentials: 'include' }),
            fetch(`${inventoryApiBase}?action=inventory`, { credentials: 'include' })
        ]);
        const [supplyData, ppmpData] = await Promise.all([
            supplyResponse.json(),
            ppmpResponse.json()
        ]);
        if (!supplyResponse.ok || !supplyData.success) {
            throw new Error(supplyData.message || 'Failed to load Supply inventory');
        }
        if (!ppmpResponse.ok || !ppmpData.success) {
            throw new Error(ppmpData.message || 'Failed to load PPMP inventory');
        }

        const normalizeItemName = value => String(value || '')
            .trim()
            .toLowerCase()
            .replace(/\s+/g, ' ');
        const ppmpByItem = new Map();
        const ppmpByName = new Map();
        (Array.isArray(ppmpData.data) ? ppmpData.data : []).forEach(row => {
            const nameKey = normalizeItemName(row.item_name);
            const unitKey = String(row.unit || 'pcs').trim().toLowerCase();
            if (!nameKey) return;
            ppmpByItem.set(`${nameKey}|${unitKey}`, row);
            ppmpByName.set(nameKey, row);
        });

        items = (Array.isArray(supplyData.data) ? supplyData.data : []).map(row => {
            const name = String(row?.item_name ?? row?.name ?? '').trim();
            if (!name) return null;
            const unit = String(row.unit || 'pcs');
            const nameKey = normalizeItemName(name);
            const ppmpItem = ppmpByItem.get(`${nameKey}|${unit.toLowerCase()}`)
                || ppmpByName.get(nameKey);
            const ppmpQuantity = Number(ppmpItem?.quantity_left) || 0;
            return {
                // Keep the PPMP inventory id because requests are validated against PPMP quantities.
                id: ppmpItem?.id || 0,
                name,
                category: String(row.category || 'Uncategorized'),
                stock: ppmpQuantity,
                min_stock: Number(row.min_stock) || 0,
                unit,
                status: stockStatus(ppmpQuantity, 0),
                image: row.image || null
            };
        }).filter(Boolean);

        populateCategoryFilter();
        populatePopularItems();
        if (typeof renderItems === 'function') renderItems(items);
        return items;
    } catch (err) {
        showToast(err.message || 'Could not load inventory.', 'error');
        items = [];
        populatePopularItems();
        if (typeof renderItems === 'function') renderItems(items);
        return items;
    }
}

async function fetchInventoryAudit() {
    try {
        const response = await fetch(`${ppmpApiBase}?action=audit`, { credentials: 'include' });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to load inventory history');
        inventoryAudit = data.data || [];
    } catch (err) {
        inventoryAudit = [];
        showToast(err.message || 'Could not load inventory history.', 'error');
    }
}

function renderInventoryAudit() {
    const container = document.getElementById('inventoryAuditList');
    if (!container) return;
    if (!inventoryAudit.length) {
        container.innerHTML = '<div class="empty-state">No accepted PPMP inventory changes yet.</div>';
        return;
    }
    container.innerHTML = inventoryAudit.map(row => `
        <div class="delivery-card">
            <div class="delivery-card-header"><span>${escapeHtml(row.item_name)}</span><strong>+${Number(row.quantity_added) || 0} ${escapeHtml(row.unit)}</strong></div>
            <div class="delivery-card-row"><span>Quantity Left</span><strong>${Number(row.resulting_quantity) || 0} ${escapeHtml(row.unit)}</strong></div>
            <div class="delivery-card-row"><span>PPMP</span><strong>${escapeHtml(row.ppmp_file_name || `#${row.ppmp_id}`)}</strong></div>
            <div class="delivery-card-row"><span>Accepted</span><strong>${escapeHtml(row.accepted_at || '—')}</strong></div>
        </div>
    `).join('');
}

async function fetchMyRequests() {
    try {
        const response = await fetch(`${requestsApiBase}?action=mine`, { credentials: 'include' });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to load requests');

        requests = (data.data || []).map(row => {
            const details = parseItemDetails(row.item_details);
            const itemsText = details.length
                ? details.map(item => `${item.item_name || item.name || 'Item'} x${item.quantity || 0}`).join(', ')
                : `${row.item_name || 'Item'} x${row.quantity || 0}`;
            return {
                id: formatRis(row.id, row.ris_number),
                rawId: row.id,
                items: itemsText,
                dateRequested: formatShortDate(row.request_date),
                purpose: row.note || 'Supply',
                status: row.status || 'Pending',
                quantity: row.quantity,
                fullItems: details.length ? details : [{ item_name: row.item_name, quantity: row.quantity }]
            };
        });

        await syncRequestorDeliveryStatus();
        return requests;
    } catch (err) {
        showToast(err.message || 'Could not load your requests.', 'error');
        requests = [];
        return requests;
    }
}

async function fetchPpmpRequests() {
    try {
        const response = await fetch(`${ppmpApiBase}?action=list`, { credentials: 'include' });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to load PPMP requests');
        ppmpRequests = Array.isArray(data.data) ? data.data : [];
    } catch (error) {
        ppmpRequests = [];
        showToast(error.message || 'Could not load PPMP requests.', 'error');
    }
}

function renderPpmpRequests() {
    const container = document.getElementById('ppmpRequestsContainer');
    if (!container) return;
    if (!ppmpRequests.length) {
        container.innerHTML = '<div class="empty-state">No PPMP requests yet. Upload a PPMP to begin.</div>';
        return;
    }
    container.innerHTML = ppmpRequests.map(ppmp => {
        const status = String(ppmp.status || 'Pending');
        const statusClass = status === 'Approved' ? 'accepted' : status === 'Rejected' ? 'rejected' : 'pending';
        return `
            <article class="ppmp-request-card">
                <div class="ppmp-request-card-header">
                    <div>
                        <span class="ppmp-request-label">PPMP Request</span>
                        <h3>${escapeHtml(ppmp.file_name || `PPMP #${ppmp.id}`)}</h3>
                    </div>
                    <span class="ppmp-request-status ${statusClass}">${status === 'Approved' ? 'Accepted' : escapeHtml(status)}</span>
                </div>
                <div class="ppmp-request-details">
                    <div><span>Items</span><strong>${Number(ppmp.item_count) || 0}</strong></div>
                    <div><span>Fiscal Year</span><strong>${escapeHtml(ppmp.fiscal_year || '—')}</strong></div>
                    <div><span>Province</span><strong>${escapeHtml(ppmp.province || '—')}</strong></div>
                    <div><span>Submitted</span><strong>${escapeHtml(ppmp.uploaded_at || '—')}</strong></div>
                </div>
                ${ppmp.reason ? `<p class="ppmp-request-reason"><strong>Review note:</strong> ${escapeHtml(ppmp.reason)}</p>` : ''}
            </article>
        `;
    }).join('');
}

function renderCurrentRequestType() {
    const itemFilters = document.getElementById('itemRequestsFilters');
    const itemContainer = document.getElementById('requestsContainer');
    const ppmpContainer = document.getElementById('ppmpRequestsContainer');
    const isPpmp = requestType === 'ppmp';
    itemFilters?.classList.toggle('hidden', isPpmp);
    itemContainer?.classList.toggle('hidden', isPpmp);
    ppmpContainer?.classList.toggle('hidden', !isPpmp);
    if (isPpmp) renderPpmpRequests();
    else renderRequests();
}

function notificationStatusLabel(status) {
    const value = String(status || '').toLowerCase();
    if (value === 'approved') return 'Accepted';
    if (value === 'completed') return 'Delivered';
    if (value === 'rejected' || value === 'declined' || value === 'cancelled') return 'Rejected';
    if (value === 'ready') return 'Preparing';
    if (value === 'picked') return 'Picked Up';
    if (value === 'delivering') return 'In Transit';
    if (value === 'returned') return 'Returned';
    return 'Pending';
}

function notificationClass(status) {
    const value = String(status || '').toLowerCase();
    if (['approved', 'completed'].includes(value)) return 'success';
    if (['rejected', 'declined', 'cancelled', 'returned'].includes(value)) return 'error';
    return 'pending';
}

async function fetchRequestorNotifications() {
    try {
        const [ppmpResponse, requestResponse, deliveryResponse, completedDeliveryResponse] = await Promise.all([
            fetch(`${ppmpApiBase}?action=list`, { credentials: 'include' }),
            fetch(`${requestsApiBase}?action=mine`, { credentials: 'include' }),
            fetch(`${deliveryApiBase}?action=list`, { credentials: 'include' }),
            fetch(`${deliveryApiBase}?action=list_completed`, { credentials: 'include' })
        ]);
        const [ppmpPayload, requestPayload, deliveryPayload, completedDeliveryPayload] = await Promise.all([
            ppmpResponse.json(), requestResponse.json(), deliveryResponse.json(), completedDeliveryResponse.json()
        ]);
        if (!ppmpResponse.ok || !ppmpPayload.success) throw new Error(ppmpPayload.message || 'Could not load PPMP notifications');
        if (!requestResponse.ok || !requestPayload.success) throw new Error(requestPayload.message || 'Could not load request notifications');

        const next = [];
        (ppmpPayload.data || []).forEach(ppmp => {
            const status = String(ppmp.status || 'Pending');
            next.push({
                type: 'PPMP',
                status,
                title: `PPMP ${status === 'Approved' ? 'Accepted' : status}`,
                detail: `${ppmp.file_name || `PPMP #${ppmp.id}`} • ${ppmp.item_count || 0} item(s)`,
                date: ppmp.reviewed_at || ppmp.uploaded_at,
                className: notificationClass(status)
            });
        });

        const requestIds = new Set();
        (requestPayload.data || []).forEach(request => {
            requestIds.add(Number(request.id));
            const status = String(request.status || 'Pending');
            next.push({
                type: 'Item Request',
                status,
                title: `Item request ${notificationStatusLabel(status)}`,
                detail: `${request.item_name || 'Requested item'} • ${formatRis(request.id, request.ris_number)}`,
                date: request.approved_date || request.request_date,
                className: notificationClass(status)
            });
        });

        if (deliveryResponse.ok && deliveryPayload.success) {
            (deliveryPayload.data || []).forEach(delivery => {
                if (!requestIds.has(Number(delivery.request_id))) return;
                const status = String(delivery.status || 'ready');
                next.push({
                    type: 'Delivery',
                    status,
                    title: `Delivery ${notificationStatusLabel(status)}`,
                    detail: `${delivery.item_name || 'Requested item'} • ${delivery.package_id || 'Package'}`,
                    date: delivery.updated_at || delivery.created_at,
                    className: notificationClass(status)
                });
            });
        }

        if (completedDeliveryResponse.ok && completedDeliveryPayload.success) {
            (completedDeliveryPayload.data || []).forEach(delivery => {
                if (!requestIds.has(Number(delivery.request_id))) return;
                const status = String(delivery.status || 'completed');
                next.push({
                    type: 'Delivery',
                    status,
                    title: `Delivery ${notificationStatusLabel(status)}`,
                    detail: `${delivery.item_name || 'Requested item'} • ${delivery.package_id || 'Package'}`,
                    date: delivery.completed_at || delivery.delivered_at || delivery.updated_at || delivery.created_at,
                    className: notificationClass(status)
                });
            });
        }

        requestorNotifications = next.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
        renderRequestorNotifications();
    } catch (error) {
        requestorNotifications = [];
        renderRequestorNotifications(error.message || 'Could not load notifications.');
    }
}

function renderRequestorNotifications(errorMessage = '') {
    const todayList = document.getElementById('requestorTodayNotifications');
    const olderList = document.getElementById('requestorOlderNotifications');
    const badge = document.getElementById('requestorNotificationBadge');
    const allCount = document.getElementById('requestorNotifCountAll');
    const unreadCount = document.getElementById('requestorNotifCountUnread');
    if (!todayList || !olderList) return;

    const getKey = notification => `${notification.type}|${notification.detail}|${notification.date || ''}`;
    const unread = requestorNotifications.filter(notification => !requestorReadNotifications.has(getKey(notification)));
    const visible = requestorNotificationFilter === 'unread' ? unread : requestorNotifications;
    const today = new Date().toDateString();
    const renderItems = list => list.length ? list.map(notification => {
        const key = getKey(notification);
        const isUnread = !requestorReadNotifications.has(key);
        return `
            <article class="requestor-notification-item ${notification.className} ${isUnread ? 'unread' : ''}" data-notification-key="${escapeHtml(key)}">
                <div class="requestor-notification-item-top">
                    <span class="requestor-notification-type">${escapeHtml(notification.type)}</span>
                    <strong>${escapeHtml(notification.title)}</strong>
                </div>
                <p>${escapeHtml(notification.detail)}</p>
                <time>${escapeHtml(notification.date || 'Recently updated')}</time>
            </article>
        `;
    }).join('') : '<div class="empty-state">No notifications in this view.</div>';

    todayList.innerHTML = renderItems(visible.filter(notification => new Date(notification.date || 0).toDateString() === today));
    olderList.innerHTML = renderItems(visible.filter(notification => new Date(notification.date || 0).toDateString() !== today));
    allCount.textContent = String(requestorNotifications.length);
    unreadCount.textContent = String(unread.length);
    badge.textContent = String(unread.length);
    badge.classList.toggle('hidden', unread.length === 0);
}

function toggleRequestorNotifications(forceOpen) {
    const panel = document.getElementById('requestorNotificationPanel');
    const button = document.getElementById('requestorNotificationBtn');
    if (!panel) return;
    const isOpen = forceOpen ?? !panel.classList.contains('open');
    panel.classList.toggle('open', isOpen);
    panel.setAttribute('aria-hidden', String(!isOpen));
    button?.setAttribute('aria-expanded', String(isOpen));
    document.getElementById('requestorNotificationOverlay')?.classList.toggle('active', isOpen);
    if (isOpen) fetchRequestorNotifications();
}

async function fetchRequestStats() {
    try {
        const response = await fetch(`${requestsApiBase}?action=stats`, { credentials: 'include' });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to load request statistics');

        document.getElementById('statTotalItems').textContent = items.length;
        document.getElementById('statPendingRequests').textContent = data.data.pending || 0;
        document.getElementById('statApprovedRequests').textContent = data.data.approved || 0;
        updateInTransitDeliveryStat();
    } catch (err) {
        showToast(err.message || 'Could not load dashboard stats.', 'error');
        document.getElementById('statTotalItems').textContent = items.length;
        document.getElementById('statPendingRequests').textContent = '0';
        document.getElementById('statApprovedRequests').textContent = '0';
        updateInTransitDeliveryStat();
    }
}

function populateCategoryFilter() {
    const select = document.getElementById('categoryFilter');
    if (!select) return;
    const current = select.value;
    const categories = [...new Set(items.map(i => i.category).filter(Boolean))].sort();
    select.innerHTML = '<option value="">All Categories</option>' +
        categories.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    if (categories.includes(current)) select.value = current;
}

function populatePopularItems() {
    const popularGrid = document.getElementById('popularItemsGrid');
    if (!popularGrid) return;
    if (!items.length) {
        popularGrid.innerHTML = '<div class="empty-state">No featured items available yet.</div>';
        return;
    }
    const popularItems = items.slice(0, 5);
    popularGrid.innerHTML = popularItems.map(item => `
        <article class="popular-card">
            <div class="popular-card-image">
                ${item.image ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}">` : '<span class="item-placeholder-icon">📦</span>'}
            </div>
            <div class="popular-card-body">
                <strong>${escapeHtml(item.name)}</strong>
                <span class="item-status">Unit: ${escapeHtml(item.unit)}</span>
                <span class="item-status">Quantity Left: ${item.stock}</span>
            </div>
            <button class="popular-card-btn" type="button" ${item.status === 'Out of Stock' ? 'disabled' : ''} onclick="openRequestModal(${item.id})">Request Item Now</button>
        </article>
    `).join('');
}

// ============================================================
// MY REQUESTS - RENDERING
// ============================================================

const requestsContainer = document.getElementById('requestsContainer');
const requestsSearchInput = document.getElementById('requestsSearchInput');
const requestsStatusFilter = document.getElementById('requestsStatusFilter');

function renderRequests(requestsToRender = requests) {
    if (!requestsContainer) return;
    requestsContainer.innerHTML = '';

    if (!requestsToRender.length) {
        requestsContainer.innerHTML = '<div class="empty-state">No requests yet. Submit one from Request Item.</div>';
        return;
    }

    requestsToRender.forEach((request, index) => {
        requestsContainer.appendChild(createRequestCard(request, index));
    });
}

function createRequestCard(request) {
    const card = document.createElement('div');
    card.className = 'request-card';
    card.dataset.status = request.status;
    card.dataset.id = String(request.id).toLowerCase();

    let statusClass = 'status-pending';
    if (request.status === 'Approved') statusClass = 'status-approved';
    else if (request.status === 'Delivered') statusClass = 'status-delivered';
    else if (request.status === 'In Transit') statusClass = 'status-in-transit';
    else if (request.status === 'Picked Up') statusClass = 'status-picked-up';
    else if (request.status === 'Cancelled') statusClass = 'status-cancelled';
    else if (request.status === 'Returned') statusClass = 'status-returned';
    else if (request.status === 'Declined') statusClass = 'status-rejected';

    card.innerHTML = `
        <div class="request-header">
            <div class="request-id">${escapeHtml(request.id)}</div>
        </div>
        <div class="request-content">
            <div class="request-row">
                <label class="request-label">Items</label>
                <div class="request-value">${escapeHtml(request.items)} × ${escapeHtml(String(request.quantity ?? ''))}</div>
            </div>
            <div class="request-row">
                <label class="request-label">Date Requested</label>
                <div class="request-value">${escapeHtml(request.dateRequested)}</div>
            </div>
            <div class="request-row">
                <label class="request-label">Purpose</label>
                <div class="request-value">${escapeHtml(request.purpose)}</div>
            </div>
            <div class="request-footer">
                <span class="status-badge ${statusClass}">${escapeHtml(request.status)}</span>
            </div>
        </div>
    `;

    return card;
}

function filterRequests() {
    const searchTerm = (requestsSearchInput?.value || '').toLowerCase();
    const selectedStatus = requestsStatusFilter?.value || '';

    const filteredRequests = requests.filter(request => {
        const matchesSearch = String(request.id || '').toLowerCase().includes(searchTerm) ||
            String(request.items || '').toLowerCase().includes(searchTerm);
        const matchesStatus = !selectedStatus || request.status === selectedStatus;
        return matchesSearch && matchesStatus;
    });

    renderRequests(filteredRequests);
}

// ============================================================
// REQUEST ITEM PAGE - RENDERING
// ============================================================

const itemsContainer = document.getElementById('itemsContainer');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const statusFilter = document.getElementById('statusFilter');

function renderItems(itemsToRender = items) {
    if (!itemsContainer) return;
    itemsContainer.innerHTML = '';

    if (!itemsToRender.length) {
        itemsContainer.innerHTML = '<div class="empty-state">No inventory items found.</div>';
        return;
    }

    itemsToRender.forEach(item => {
        itemsContainer.appendChild(createItemCard(item));
    });
}

function createItemCard(item) {
    const card = document.createElement('div');
    card.className = 'item-card';
    card.dataset.category = item.category;
    card.dataset.name = String(item.name || '').toLowerCase();

    const disabled = item.stock <= 0 ? 'disabled' : '';

    card.innerHTML = `
        <div class="item-image item-image-placeholder" role="img" aria-label="Image for ${escapeHtml(item.name)}">
            ${item.image ? `<img src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}">` : '<span>Item image</span>'}
        </div>
        <div class="item-content">
            <div class="item-name">${escapeHtml(item.name)}</div>
            <div class="item-status">Unit: ${escapeHtml(item.unit)}</div>
            <div class="item-status">Quantity Left: ${item.stock}</div>
            <div class="item-buttons">
                <button class="item-btn request-btn" ${disabled} onclick="openRequestModal(${item.id})">Add to Cart</button>
            </div>
        </div>
    `;

    return card;
}

function filterItems() {
    const searchTerm = (searchInput?.value || '').toLowerCase();
    const selectedCategory = categoryFilter?.value || '';
    const selectedStatus = statusFilter?.value || '';

    const filteredItems = items.filter(item => {
        const matchesSearch = String(item.name || '').toLowerCase().includes(searchTerm);
        const matchesCategory = !selectedCategory || item.category === selectedCategory;
        const matchesStatus = !selectedStatus || item.status === selectedStatus;
        return matchesSearch && matchesCategory && matchesStatus;
    });

    renderItems(filteredItems);
}

function renderDeliveryHistory() {
    const container = document.getElementById('deliveryListContainer');
    if (!container) return;
    const requestIds = new Set(requests.map(request => Number(request.rawId || 0)));
    const records = requestorDeliveryRecords
        .filter(delivery => requestIds.has(Number(delivery.requestId)))
        .filter(delivery => ['ready', 'picked', 'delivering', 'completed', 'cancelled', 'returned'].includes(String(delivery.status || '').toLowerCase()))
        .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    if (!records.length) {
        container.innerHTML = '<div class="empty-state">No delivery history available yet.</div>';
        return;
    }

    container.innerHTML = records.map(record => `
        <div class="delivery-card">
            <div class="delivery-card-header">
                <span>${escapeHtml(record.item || 'Delivery')}</span>
                <strong>${escapeHtml(record.packageId || 'Package')}</strong>
            </div>
            <div class="delivery-card-row"><span>Office</span><strong>${escapeHtml(record.office || '—')}</strong></div>
            <div class="delivery-card-row"><span>Status</span><strong>${escapeHtml(record.status || '—')}</strong></div>
            <div class="delivery-card-row"><span>ETA</span><strong>${escapeHtml(record.eta || '—')}</strong></div>
            <div class="delivery-card-row"><span>Updated</span><strong>${escapeHtml(new Date(record.updatedAt || Date.now()).toLocaleString())}</strong></div>
        </div>
    `).join('');
}

async function uploadPpmp(formData) {
    try {
        const response = await fetch(`${ppmpApiBase}?action=upload`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders(),
            body: formData
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.message || 'Failed to upload PPMP');
        showToast('PPMP uploaded and pending review.', 'success');
        closePpmpModal();
    } catch (err) {
        showToast(err.message || 'Could not upload PPMP.', 'error');
    }
}

// ============================================================
// REQUEST MODAL
// ============================================================

function ensureRequestModal() {
    if (document.getElementById('requestModal')) return;

    const modal = document.createElement('div');
    modal.id = 'requestModal';
    modal.className = 'req-modal';
    modal.innerHTML = `
        <div class="req-modal-card">
            <div class="req-modal-header">
                <div>
                    <h3>Add to Cart</h3>
                    <p class="req-modal-subtitle">Choose the quantity and purpose for this item before adding it to your request.</p>
                </div>
                <button type="button" class="req-modal-close" id="closeRequestModal" aria-label="Close">&times;</button>
            </div>
            <form id="requestForm">
                <input type="hidden" id="requestItemId">
                <p class="req-modal-item" id="requestItemName">—</p>
                <div class="req-field-row">
                    <label class="req-field-label" for="requestQty">Quantity</label>
                    <input id="requestQty" type="number" min="1" value="1" required>
                </div>
                <div class="req-field-row">
                    <label class="req-field-label" for="requestNote">Purpose / Note</label>
                    <input id="requestNote" type="text" placeholder="e.g. Office supply restock" maxlength="255">
                </div>
                <div class="req-modal-actions">
                    <button type="button" class="req-btn-secondary" id="cancelRequestModal">Cancel</button>
                    <button type="submit" class="req-btn-primary">Add to Cart</button>
                </div>
            </form>
        </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('closeRequestModal').addEventListener('click', closeRequestModal);
    document.getElementById('cancelRequestModal').addEventListener('click', closeRequestModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeRequestModal();
    });
    document.getElementById('requestForm').addEventListener('submit', submitRequestForm);
}

function openRequestModal(itemId) {
    ensureRequestModal();
    const item = items.find(i => Number(i.id) === Number(itemId));
    if (!item) return;
    if (item.status === 'Out of Stock') {
        showToast('This item is out of stock.', 'error');
        return;
    }

    document.getElementById('requestItemId').value = String(item.id);
    document.getElementById('requestItemName').textContent = `${item.name} (${item.stock} ${item.unit} available)`;
    document.getElementById('requestQty').value = '1';
    document.getElementById('requestQty').max = String(Math.max(1, item.stock));
    document.getElementById('requestNote').value = '';
    document.getElementById('requestModal').classList.add('active');
}

function closeRequestModal() {
    document.getElementById('requestModal')?.classList.remove('active');
}

function ensurePpmpModal() {
    const modal = document.getElementById('ppmpModal');
    if (modal) return;
    showToast('PPMP upload modal is unavailable.', 'error');
}

function openPpmpModal() {
    const modal = document.getElementById('ppmpModal');
    if (!modal) return;
    modal.style.display = 'flex';
    modal.classList.add('open');
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
}

function closePpmpModal() {
    const modal = document.getElementById('ppmpModal');
    if (!modal) return;
    modal.style.display = 'none';
    modal.classList.remove('open');
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
}

function openRequestorProfile() {
    const drawer = document.getElementById('requestorProfileDrawer');
    const button = document.getElementById('requestorProfileBtn');
    if (!drawer) return;
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    button?.setAttribute('aria-expanded', 'true');
}

function closeRequestorProfile() {
    const drawer = document.getElementById('requestorProfileDrawer');
    const button = document.getElementById('requestorProfileBtn');
    if (!drawer) return;
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    button?.setAttribute('aria-expanded', 'false');
}

function closeRequestorProfileMenu() {
    const menu = document.getElementById('requestorProfileMenu');
    const button = document.getElementById('requestorProfileBtn');
    if (!menu) return;
    menu.classList.remove('open');
    menu.setAttribute('aria-hidden', 'true');
    button?.setAttribute('aria-expanded', 'false');
}

function toggleRequestorProfileMenu(force) {
    const menu = document.getElementById('requestorProfileMenu');
    const button = document.getElementById('requestorProfileBtn');
    if (!menu) return;
    const shouldOpen = typeof force === 'boolean' ? force : !menu.classList.contains('open');
    menu.classList.toggle('open', shouldOpen);
    menu.setAttribute('aria-hidden', String(!shouldOpen));
    button?.setAttribute('aria-expanded', String(shouldOpen));
}

function getRequestorProfileStorageKey() {
    return `requestor_profile_${window.requestorUsername || requestorProvince || 'default'}`;
}

function applyRequestorAvatar(url) {
    const avatar = document.getElementById('requestorSettingsAvatar');
    const preview = document.getElementById('requestorEditAvatarPreview');
    const headerAvatar = document.getElementById('requestorProfileBtn');
    const drawerAvatar = document.querySelector('#requestorProfileDrawer .requestor-profile-avatar');
    const menuAvatar = document.getElementById('requestorMenuAvatar');
    [avatar, preview, headerAvatar, drawerAvatar, menuAvatar].forEach((element) => {
        if (!element) return;
        element.style.backgroundImage = url ? `url(${url})` : '';
        element.style.backgroundSize = 'cover';
        element.style.backgroundPosition = 'center';
        const icon = element.querySelector('svg');
        if (icon) icon.style.display = url ? 'none' : 'block';
        if (element === headerAvatar) {
            element.style.backgroundColor = url ? '#385b86' : '';
        }
    });
}

function loadRequestorAvatar() {
    const username = window.requestorUsername || '';
    if (!username) return;
    applyRequestorAvatar(localStorage.getItem(`avatar_${username}`) || '');
}

function loadRequestorProfileExtras() {
    try {
        return JSON.parse(localStorage.getItem(getRequestorProfileStorageKey()) || '{}') || {};
    } catch {
        return {};
    }
}

function renderRequestorProfile() {
    const extras = loadRequestorProfileExtras();
    const defaults = {
        name: document.getElementById('requestorSettingsDisplayName')?.textContent || 'Requestor',
        email: document.getElementById('requestorSettingsEmail')?.textContent || 'Not provided',
        phone: '+63 9123456789',
        address: requestorProvince || 'Province not assigned',
        dob: 'June 13, 2003',
        gender: 'Not provided',
        civil: 'Not provided',
        nationality: 'Filipino',
        bureau: 'Requestor Office',
        employeeId: 'Not provided',
        position: 'Requestor',
        employment: 'Permanent',
        step: 'Not provided',
        dateCreated: 'Not provided'
    };
    const profile = { ...defaults, ...extras };
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value || 'Not provided';
    };
    setText('requestorSettingsDisplayName', profile.name);
    setText('requestorSettingsEmail', profile.email);
    setText('requestorSettingsPhone', profile.phone);
    setText('requestorSettingsAddress', profile.address);
    setText('requestorSettingsBureau', profile.bureau);
    setText('requestorSettingsFullName', profile.name);
    setText('requestorSettingsDob', profile.dob);
    setText('requestorSettingsGender', profile.gender);
    setText('requestorSettingsCivil', profile.civil);
    setText('requestorSettingsNationality', profile.nationality);
    setText('requestorSettingsEmployeeId', profile.employeeId);
    setText('requestorSettingsPosition', profile.position);
    setText('requestorSettingsDivision', profile.bureau);
    setText('requestorSettingsEmployment', profile.employment);
    setText('requestorSettingsStep', profile.step);
    setText('requestorSettingsDateCreated', profile.dateCreated);
    setText('requestorSettingsUsername', window.requestorUsername || '—');
    setText('requestorProfileMenuName', profile.name);
    loadRequestorAvatar();
}

function openRequestorProfileEdit() {
    const modal = document.getElementById('requestorProfileEditModal');
    if (!modal) return;
    const extras = loadRequestorProfileExtras();
    const values = {
        name: document.getElementById('requestorSettingsDisplayName')?.textContent || '',
        email: document.getElementById('requestorSettingsEmail')?.textContent || '',
        phone: document.getElementById('requestorSettingsPhone')?.textContent || '',
        address: document.getElementById('requestorSettingsAddress')?.textContent || '',
        dob: document.getElementById('requestorSettingsDob')?.textContent || '',
        gender: document.getElementById('requestorSettingsGender')?.textContent || '',
        civil: document.getElementById('requestorSettingsCivil')?.textContent || '',
        nationality: document.getElementById('requestorSettingsNationality')?.textContent || '',
        bureau: document.getElementById('requestorSettingsBureau')?.textContent || '',
        employeeId: document.getElementById('requestorSettingsEmployeeId')?.textContent || '',
        position: document.getElementById('requestorSettingsPosition')?.textContent || '',
        employment: document.getElementById('requestorSettingsEmployment')?.textContent || '',
        step: document.getElementById('requestorSettingsStep')?.textContent || '',
        dateCreated: document.getElementById('requestorSettingsDateCreated')?.textContent || ''
    };
    Object.assign(values, extras);
    const fields = {
        requestorEditDisplayName: values.name,
        requestorEditEmail: values.email,
        requestorEditPhone: values.phone,
        requestorEditAddress: values.address,
        requestorEditDob: values.dob,
        requestorEditGender: values.gender,
        requestorEditCivil: values.civil,
        requestorEditNationality: values.nationality,
        requestorEditBureau: values.bureau,
        requestorEditEmployeeId: values.employeeId,
        requestorEditPosition: values.position,
        requestorEditEmployment: values.employment,
        requestorEditStep: values.step,
        requestorEditDateCreated: values.dateCreated
    };
    Object.entries(fields).forEach(([id, value]) => {
        const field = document.getElementById(id);
        if (field) field.value = value || '';
    });
    const savedAvatar = localStorage.getItem(`avatar_${window.requestorUsername || ''}`) || '';
    applyRequestorAvatar(savedAvatar);
    const avatarInput = document.getElementById('requestorEditAvatarInput');
    if (avatarInput) avatarInput.value = '';
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
}

function closeRequestorProfileEdit() {
    const modal = document.getElementById('requestorProfileEditModal');
    if (!modal) return;
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
}

function saveRequestorProfile() {
    const field = (id) => document.getElementById(id)?.value.trim() || '';
    const profile = {
        name: field('requestorEditDisplayName'), email: field('requestorEditEmail'),
        phone: field('requestorEditPhone'), address: field('requestorEditAddress'),
        dob: field('requestorEditDob'), gender: field('requestorEditGender'),
        civil: field('requestorEditCivil'), nationality: field('requestorEditNationality'),
        bureau: field('requestorEditBureau'), employeeId: field('requestorEditEmployeeId'),
        position: field('requestorEditPosition'), employment: field('requestorEditEmployment'),
        step: field('requestorEditStep'), dateCreated: field('requestorEditDateCreated')
    };
    if (!profile.name) {
        showToast('Display name is required.', 'error');
        return;
    }
    const avatarInput = document.getElementById('requestorEditAvatarInput');
    const avatarFile = avatarInput?.files?.[0] || null;
    const preview = document.getElementById('requestorEditAvatarPreview');
    (async () => {
        let uploadedUrl = null;
        if (avatarFile && window.requestorUsername) {
            try {
                const formData = new FormData();
                formData.append('avatar', avatarFile);
                const response = await fetch(`${requestorLoginApiBase}/upload_avatar.php`, {
                    method: 'POST', credentials: 'include', headers: withCsrfHeaders(), body: formData
                });
                const payload = response.ok ? await response.json() : null;
                if (payload?.success && payload.url) uploadedUrl = payload.url;
            } catch (error) {
                console.warn('Requestor avatar upload failed.', error);
            }
        }
        const avatarUrl = uploadedUrl || preview?.dataset.avatar || localStorage.getItem(`avatar_${window.requestorUsername || ''}`) || '';
        if (avatarUrl && window.requestorUsername) {
            localStorage.setItem(`avatar_${window.requestorUsername}`, avatarUrl);
            applyRequestorAvatar(avatarUrl);
        }
        localStorage.setItem(getRequestorProfileStorageKey(), JSON.stringify(profile));
        renderRequestorProfile();
        closeRequestorProfileEdit();
        showToast('Profile updated successfully.', 'success');
    })();
}

function submitRequestForm(e) {
    e.preventDefault();
    const itemId = Number(document.getElementById('requestItemId').value);
    const quantity = Number(document.getElementById('requestQty').value);
    const note = document.getElementById('requestNote').value.trim();

    if (!itemId || quantity < 1) {
        showToast('Please enter a valid quantity.', 'error');
        return;
    }

    const item = items.find(i => Number(i.id) === Number(itemId));
    if (!item) {
        showToast('Selected item is unavailable.', 'error');
        return;
    }

    addItemToCart({
        id: item.id,
        name: item.name,
        quantity,
        note,
        unit: item.unit
    });
    closeRequestModal();
}

// Keep legacy name used by older markup if any
function requestItem(itemId) {
    openRequestModal(itemId);
}

function addToCart() {
    showToast('Cart is not required — use Request Item Now.', 'info');
}

// ============================================================
// EVENT LISTENERS
// ============================================================

searchInput?.addEventListener('input', filterItems);
categoryFilter?.addEventListener('change', filterItems);
statusFilter?.addEventListener('change', filterItems);
requestsSearchInput?.addEventListener('input', filterRequests);
requestsStatusFilter?.addEventListener('change', filterRequests);
document.querySelectorAll('[data-request-type]').forEach(tab => tab.addEventListener('click', async () => {
    requestType = tab.dataset.requestType || 'items';
    document.querySelectorAll('[data-request-type]').forEach(item => {
        const active = item === tab;
        item.classList.toggle('active', active);
        item.setAttribute('aria-selected', String(active));
    });
    if (requestType === 'ppmp' && !ppmpRequests.length) await fetchPpmpRequests();
    renderCurrentRequestType();
}));
document.getElementById('uploadPpmpBtn')?.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    openPpmpModal();
});
document.getElementById('cartToggleBtn')?.addEventListener('click', () => {
    if (cartItems.length) openCartDrawer(); else showToast('Your cart is empty.', 'info');
});
document.getElementById('openCartFromPage')?.addEventListener('click', () => {
    if (cartItems.length) openCartDrawer(); else showToast('Your cart is empty.', 'info');
});
document.getElementById('openPpmpHistoryBtn')?.addEventListener('click', openPpmpHistoryDrawer);
document.getElementById('closePpmpHistoryDrawer')?.addEventListener('click', closePpmpHistoryDrawer);
document.getElementById('closeCartDrawer')?.addEventListener('click', closeCartDrawer);
document.getElementById('submitCartBtn')?.addEventListener('click', submitCartRequest);
document.getElementById('requestorLogoutBtn')?.addEventListener('click', () => {
    window.location.href = '../../Login/logout.php';
});
document.getElementById('requestorProfileBtn')?.addEventListener('click', () => {
    renderRequestorProfile();
    toggleRequestorProfileMenu();
});
document.getElementById('requestorProfileMenuAccount')?.addEventListener('click', () => {
    closeRequestorProfileMenu();
    renderRequestorProfile();
    showPage('profile');
});
document.addEventListener('click', (event) => {
    const menu = document.getElementById('requestorProfileMenu');
    const button = document.getElementById('requestorProfileBtn');
    if (menu?.classList.contains('open') && !menu.contains(event.target) && !button?.contains(event.target)) {
        closeRequestorProfileMenu();
    }
});
document.getElementById('requestorEditProfileBtn')?.addEventListener('click', openRequestorProfileEdit);
document.getElementById('closeRequestorProfileEdit')?.addEventListener('click', closeRequestorProfileEdit);
document.getElementById('cancelRequestorProfileEdit')?.addEventListener('click', closeRequestorProfileEdit);
document.getElementById('saveRequestorProfile')?.addEventListener('click', saveRequestorProfile);
document.getElementById('requestorEditAvatarInput')?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
        const preview = document.getElementById('requestorEditAvatarPreview');
        if (!preview) return;
        preview.style.backgroundImage = `url(${reader.result})`;
        preview.style.backgroundSize = 'cover';
        preview.style.backgroundPosition = 'center';
        preview.dataset.avatar = reader.result;
        const icon = preview.querySelector('svg');
        if (icon) icon.style.display = 'none';
    };
    reader.readAsDataURL(file);
});
document.getElementById('requestorProfileEditModal')?.addEventListener('click', (event) => {
    if (event.target.id === 'requestorProfileEditModal') closeRequestorProfileEdit();
});
document.getElementById('closeRequestorProfile')?.addEventListener('click', closeRequestorProfile);
document.getElementById('requestorProfileDrawer')?.addEventListener('click', (event) => {
    if (event.target.id === 'requestorProfileDrawer') closeRequestorProfile();
});
document.getElementById('requestorNotificationBtn')?.addEventListener('click', () => toggleRequestorNotifications());
document.getElementById('closeRequestorNotifications')?.addEventListener('click', () => toggleRequestorNotifications(false));
document.getElementById('requestorNotificationOverlay')?.addEventListener('click', () => toggleRequestorNotifications(false));
document.querySelectorAll('[data-notification-filter]').forEach(tab => tab.addEventListener('click', () => {
    requestorNotificationFilter = tab.dataset.notificationFilter || 'all';
    document.querySelectorAll('[data-notification-filter]').forEach(item => item.classList.toggle('active', item === tab));
    renderRequestorNotifications();
}));
document.getElementById('markRequestorNotificationsRead')?.addEventListener('click', () => {
    requestorNotifications.forEach(notification => requestorReadNotifications.add(`${notification.type}|${notification.detail}|${notification.date || ''}`));
    localStorage.setItem('dole_requestor_read_notifications_v1', JSON.stringify([...requestorReadNotifications]));
    renderRequestorNotifications();
});
document.addEventListener('click', (event) => {
    const panel = document.getElementById('requestorNotificationPanel');
    const button = document.getElementById('requestorNotificationBtn');
    if (panel?.classList.contains('open') && !panel.contains(event.target) && !button?.contains(event.target)) {
        toggleRequestorNotifications(false);
    }
});
document.getElementById('closePpmpModal')?.addEventListener('click', closePpmpModal);
document.getElementById('cancelPpmpModal')?.addEventListener('click', closePpmpModal);
document.getElementById('ppmpModal')?.addEventListener('click', (e) => { if (e.target.id === 'ppmpModal') closePpmpModal(); });
document.getElementById('ppmpUploadForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const fiscalYear = document.getElementById('ppmpFiscalYear')?.value?.trim() || '2026';
    const fileInput = document.getElementById('ppmpFile');
    if (!fileInput?.files?.length) {
        showToast('Please select an Excel file.', 'error');
        return;
    }
    formData.set('fiscal_year', fiscalYear);
    await uploadPpmp(formData);
});
document.getElementById('ppmpFile')?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    const label = document.getElementById('ppmpFileName');
    if (label) label.textContent = file ? file.name : 'Choose File';
});
window.addEventListener('storage', async (event) => {
    if (event.key === 'dole_delivery_record_v1') {
        await syncRequestorDeliveryStatus();
        renderDeliveryStatusPanel();
        renderDeliveryHistory();
    }

    if (event.key === 'dole_request_status_sync_v1') {
        await fetchMyRequests();
        renderRequests();
        renderDeliveryStatusPanel();
        renderDeliveryHistory();
    }

    if (event.key === 'dole_delivery_notification_v1' || event.key === 'dole_notification_v1') {
        const payload = event.newValue ? JSON.parse(event.newValue) : null;
        if (payload?.message) {
            showToast(payload.message, payload.type === 'error' ? 'error' : 'success');
        }
        if (payload?.type === 'request_status') {
            await fetchMyRequests();
            renderRequests();
        }
        if (payload?.type === 'delivery_status') {
            await syncRequestorDeliveryStatus();
            renderDeliveryStatusPanel();
            renderDeliveryHistory();
        }
    }
});

// ============================================================
// INITIALIZATION
// ============================================================

async function initRequestorPage() {
    ensureRequestModal();
    ensurePpmpModal();
    updateProvinceBadge();
    await Promise.all([fetchInventory(), fetchMyRequests(), fetchPpmpRequests(), fetchInventoryAudit(), fetchRequestorNotifications()]);
    await fetchRequestStats();
    renderDeliveryStatusPanel();
    renderDeliveryHistory();
    renderCart();
    renderInventoryAudit();
    updateCartBadge();
    renderRequestorProfile();
    showPage('home');
}

initRequestorPage();
setInterval(fetchRequestorNotifications, 30000);
