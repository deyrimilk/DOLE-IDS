<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Requester') !== 0) {
    if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Admin') === 0) {
        header('Location: ../../Index/ADMIN/Admin.php');
    } elseif (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Approver') === 0) {
        header('Location: ../../Index/SUPPLY/Central.php');
    } else {
        header('Location: ../../Login/login.php');
    }
    exit;
}

$requestorProfile = [
    'name' => trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Requestor')),
    'username' => trim((string)($_SESSION['username'] ?? '')),
    'email' => trim((string)($_SESSION['email'] ?? '')),
    'role' => trim((string)($_SESSION['role'] ?? 'Requester')),
    'province' => trim((string)($_SESSION['province'] ?? '')),
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department of Labor and Employment - Supply Management System</title>
    <link rel="stylesheet" href="REQ.css?v=logo-fill-nav-20260929">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <div class="logo-section">
                <div class="logo-placeholder" title="Department of Labor and Employment logo">
                    <img src="../../Images/LOGO.png" alt="DOLE Logo" class="logo-img">
                </div>
                <div class="header-text">
                    <h1>Department of Labor </h1>
                    <h1>and Employment</h1>
                </div>
            </div>
            <nav class="navigation">
                <!-- Navigation items - click handlers in JavaScript -->
                <a href="javascript:void(0)" onclick="showPage('home')" class="nav-link active" id="nav-home">Home</a>
                <a href="javascript:void(0)" onclick="showPage('request')" class="nav-link" id="nav-request">Request Item</a>
                <a href="javascript:void(0)" onclick="showPage('my-requests')" class="nav-link" id="nav-my-requests">My Requests</a>
                <a href="javascript:void(0)" onclick="showPage('deliveries')" class="nav-link" id="nav-deliveries">Deliveries</a>
            </nav>
            <div class="header-actions">
                <button class="upload-btn" type="button" id="uploadPpmpBtn" onclick="openPpmpModal(); return false;" aria-controls="ppmpModal">
                    <span>Upload PPMP</span>
                </button>
                <button class="header-cart-btn" type="button" id="cartToggleBtn" aria-label="Shopping cart">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.2 9.1a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 6H7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="10" cy="18" r="1.4" fill="currentColor" stroke="none"/><circle cx="17" cy="18" r="1.4" fill="currentColor" stroke="none"/></svg>
                    <span class="cart-badge" id="cartCountBadge">0</span>
                </button>
                <button class="notification-btn" type="button" id="requestorNotificationBtn" aria-label="Notifications" aria-expanded="false">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 17h8l-1.2-1.2V11a3.8 3.8 0 1 0-7.6 0v4.8L8 17Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M10 18.5a2 2 0 0 0 4 0" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                    <span class="notification-badge hidden" id="requestorNotificationBadge">0</span>
                </button>
                <button class="profile-icon" type="button" id="requestorProfileBtn" title="Profile" aria-label="Profile" aria-controls="requestorProfileMenu" aria-expanded="false">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                </button>
                <div class="requestor-profile-menu" id="requestorProfileMenu" aria-hidden="true">
                    <button type="button" class="requestor-profile-menu-account" id="requestorProfileMenuAccount">
                        <span class="requestor-menu-avatar" id="requestorMenuAvatar" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        </span>
                        <span id="requestorProfileMenuName"><?php echo htmlspecialchars($requestorProfile['name'], ENT_QUOTES, 'UTF-8'); ?></span>
                    </button>
                    <button type="button" class="requestor-profile-menu-logout" id="requestorLogoutBtn">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 5H6.5A1.5 1.5 0 0 0 5 6.5v11A1.5 1.5 0 0 0 6.5 19H10M14 8l4 4-4 4M9 12h9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <span>Log out</span>
                    </button>
                </div>
            </div>
        </div>
    </header>

    <aside class="requestor-notification-panel" id="requestorNotificationPanel" aria-hidden="true">
        <div class="notifications-header">
            <h3>Notifications</h3>
            <div class="notifications-header-actions">
                <button class="mark-all-read" type="button" id="markRequestorNotificationsRead" title="Mark all as read">✓✓</button>
                <button class="close-notifications" type="button" id="closeRequestorNotifications" aria-label="Close notifications">&times;</button>
            </div>
        </div>
        <div class="notifications-tabs">
            <button class="notif-tab active" type="button" data-notification-filter="all">All <span class="notif-count" id="requestorNotifCountAll">0</span></button>
            <button class="notif-tab" type="button" data-notification-filter="unread">Unread <span class="notif-count" id="requestorNotifCountUnread">0</span></button>
        </div>
        <div class="notifications-content">
            <section class="notif-section">
                <h4 class="notif-section-title">Today</h4>
                <div class="notif-list" id="requestorTodayNotifications"></div>
            </section>
            <section class="notif-section">
                <h4 class="notif-section-title">Earlier</h4>
                <div class="notif-list" id="requestorOlderNotifications"></div>
            </section>
        </div>
    </aside>
    <div class="requestor-notification-overlay" id="requestorNotificationOverlay"></div>

    <div id="requestorProfileDrawer" class="req-drawer" aria-hidden="true">
        <div class="req-drawer-panel requestor-profile-panel">
            <div class="req-drawer-header">
                <div>
                    <h3>My Profile</h3>
                    <p>Registered account information</p>
                </div>
                <button type="button" class="req-modal-close" id="closeRequestorProfile" aria-label="Close profile">&times;</button>
            </div>
            <div class="requestor-profile-content">
                <div class="requestor-profile-avatar" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                </div>
                <h4><?php echo htmlspecialchars($requestorProfile['name'], ENT_QUOTES, 'UTF-8'); ?></h4>
                <p class="requestor-profile-username">@<?php echo htmlspecialchars($requestorProfile['username'], ENT_QUOTES, 'UTF-8'); ?></p>
                <dl class="requestor-profile-details">
                    <div><dt>Email</dt><dd><?php echo htmlspecialchars($requestorProfile['email'] ?: 'Not provided', ENT_QUOTES, 'UTF-8'); ?></dd></div>
                    <div><dt>Role</dt><dd><?php echo htmlspecialchars($requestorProfile['role'], ENT_QUOTES, 'UTF-8'); ?></dd></div>
                    <div><dt>Province</dt><dd><?php echo htmlspecialchars($requestorProfile['province'] ?: 'Not assigned', ENT_QUOTES, 'UTF-8'); ?></dd></div>
                </dl>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="main-content">

        <!-- HOME PAGE -->
        <div id="home-page" class="page">
            <div class="home-dashboard-heading">
                <h2>Dashboard</h2>
            </div>
            <section class="home-stats">
                <article class="stat-card">
                    <span class="stat-label">Total Items</span>
                    <strong id="statTotalItems">0</strong>
                    <p>Available in the inventory</p>
                </article>
                <article class="stat-card">
                    <span class="stat-label">In-Transit Deliveries</span>
                    <strong id="statInTransitDeliveries">0</strong>
                    <p>Deliveries currently on the way</p>
                </article>
                <article class="stat-card">
                    <span class="stat-label">Pending Requests</span>
                    <strong id="statPendingRequests">0</strong>
                    <p>Requests awaiting approval</p>
                </article>
                <article class="stat-card">
                    <span class="stat-label">Approved Requests</span>
                    <strong id="statApprovedRequests">0</strong>
                    <p>Requests approved for fulfillment</p>
                </article>
            </section>

            <section class="popular-section">
                <div class="section-header">
                    <h3>Popular Requested Items</h3>
                </div>
                <div class="popular-grid" id="popularItemsGrid">
                    <!-- Popular items loaded from inventory -->
                </div>
            </section>
        </div>

        <!-- REQUEST ITEM PAGE -->
        <div id="request-page" class="page hidden">
            <div class="page-title request-page-title">
                <div>
                    <h2>Request Item</h2>
                    <p>Build a single request from several items and submit it once you are done.</p>
                </div>
                <div class="request-page-actions">
                    <button class="page-cta-btn page-secondary-btn" type="button" id="openPpmpHistoryBtn">PPMP History</button>
                </div>
            </div>

            <!-- Search and Filters Section -->
            <div class="filters-section">
                <div class="search-bar">
                    <!-- PLACEHOLDER: Search icon - to be replaced with actual icon -->
                    <span class="search-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="10.8" cy="10.8" r="6.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m15.5 15.5 4.2 4.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></span>
                    <input type="text" id="searchInput" placeholder="Search" class="search-input">
                </div>
                
                <div class="filter-group">
                    <div class="filter-item">
                        <label>Category</label>
                        <select id="categoryFilter" class="dropdown">
                            <option value="">All Categories</option>
                            <option value="Paper Products">Paper Products</option>
                            <option value="Writing Supplies">Writing Supplies</option>
                            <option value="Office Supplies">Office Supplies</option>
                            <option value="Office Equipment">Office Equipment</option>
                        </select>
                    </div>
                    
                    <div class="filter-item">
                        <label>Status</label>
                        <select id="statusFilter" class="dropdown">
                            <option value="">All Status</option>
                            <option value="In Stock">In Stock</option>
                            <option value="Low Stock">Low Stock</option>
                            <option value="Out of Stock">Out of Stock</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Items Grid -->
            <div class="items-container" id="itemsContainer">
                <!-- Items will be generated here by JavaScript -->
            </div>

        </div>

        <!-- MY REQUESTS PAGE -->
        <div id="my-requests-page" class="page hidden">
            <div class="page-title request-page-title">
                <div>
                    <h2>My Requests</h2>
                    <p>Monitor every request after it is sent for approval.</p>
                </div>
            </div>

            <div class="request-type-tabs" role="tablist" aria-label="Request type">
                <button type="button" class="request-type-tab active" data-request-type="items" role="tab" aria-selected="true">Item Requests</button>
                <button type="button" class="request-type-tab" data-request-type="ppmp" role="tab" aria-selected="false">PPMP Requests</button>
            </div>

            <!-- Search and Filters Section for My Requests -->
            <div class="filters-section" id="itemRequestsFilters">
                <div class="search-bar">
                    <!-- PLACEHOLDER: Search icon - to be replaced with actual icon -->
                    <span class="search-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="10.8" cy="10.8" r="6.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m15.5 15.5 4.2 4.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></span>
                    <input type="text" id="requestsSearchInput" placeholder="Search" class="search-input">
                </div>
                
                <div class="filter-group">
                    <div class="filter-item">
                        <label>Status</label>
                        <select id="requestsStatusFilter" class="dropdown">
                            <option value="">All Status</option>
                            <option value="Pending">Pending</option>
                            <option value="Approved">Approved</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Declined">Declined</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Requests Container - Grid Layout -->
            <div class="requests-container" id="requestsContainer">
                <!-- Request cards will be generated here by JavaScript -->
            </div>
            <div class="ppmp-requests-container hidden" id="ppmpRequestsContainer">
                <!-- PPMP request cards will be generated here by JavaScript -->
            </div>
        </div>

        <!-- DELIVERIES PAGE -->
        <div id="deliveries-page" class="page hidden">
            <div class="page-title">
                <div>
                    <h2>Deliveries</h2>
                </div>
                <div class="province-badge" id="requestorProvinceBadge">Province: —</div>
            </div>

            <div class="delivery-panel" id="deliveryStatusPanel">
                <p class="delivery-panel-label">Latest delivery update</p>
                <div class="delivery-panel-empty">No pickup has been scanned yet.</div>
            </div>

            <section class="delivery-list-section">
                <div class="section-header">
                    <h3>Delivery History</h3>
                </div>
                <div class="delivery-list" id="deliveryListContainer">
                    <div class="empty-state">No delivery history available yet.</div>
                </div>
            </section>
        </div>

        <div id="profile-page" class="page hidden">
            <div class="requestor-profile-heading">
                <div>
                    <h2>Profile</h2>
                    <p>View and manage your account information</p>
                </div>
            </div>
            <div class="requestor-account-settings">
                <section class="requestor-profile-card">
                    <button type="button" class="requestor-edit-profile-btn" id="requestorEditProfileBtn" title="Edit profile" aria-label="Edit profile">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9a2.1 2.1 0 0 0-4-4L4 16v4Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="m13.5 6.5 4 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        <span>Edit Profile</span>
                    </button>
                    <div class="requestor-profile-main">
                        <div class="requestor-settings-avatar" id="requestorSettingsAvatar" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        </div>
                        <div class="requestor-profile-info">
                            <h3 id="requestorSettingsDisplayName"><?php echo htmlspecialchars($requestorProfile['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
                            <p class="requestor-settings-role" id="requestorSettingsRole"><?php echo htmlspecialchars($requestorProfile['role'], ENT_QUOTES, 'UTF-8'); ?></p>
                            <p id="requestorSettingsBureau">Requestor Office</p>
                            <p>Department of Labor and Employment</p>
                            <span class="requestor-active-badge">Active</span>
                        </div>
                    </div>
                    <div class="requestor-profile-contact">
                        <div><span aria-hidden="true">@</span><span id="requestorSettingsEmail"><?php echo htmlspecialchars($requestorProfile['email'] ?: 'Not provided', ENT_QUOTES, 'UTF-8'); ?></span></div>
                        <div><span aria-hidden="true">⌕</span><span id="requestorSettingsPhone">+63 9123456789</span></div>
                        <div><span aria-hidden="true">⌖</span><span id="requestorSettingsAddress"><?php echo htmlspecialchars($requestorProfile['province'] ?: 'Province not assigned', ENT_QUOTES, 'UTF-8'); ?></span></div>
                    </div>
                </section>
                <div class="requestor-profile-lower">
                    <div class="requestor-profile-lower-left">
                        <section class="requestor-info-card">
                            <h4>Personal Information</h4>
                            <div class="requestor-info-grid five-columns">
                                <div><span>Full Name</span><strong id="requestorSettingsFullName"><?php echo htmlspecialchars($requestorProfile['name'], ENT_QUOTES, 'UTF-8'); ?></strong></div>
                                <div><span>Date of Birth</span><strong id="requestorSettingsDob">June 13, 2003</strong></div>
                                <div><span>Gender</span><strong id="requestorSettingsGender">Not provided</strong></div>
                                <div><span>Civil Status</span><strong id="requestorSettingsCivil">Not provided</strong></div>
                                <div><span>Nationality</span><strong id="requestorSettingsNationality">Filipino</strong></div>
                            </div>
                        </section>
                        <section class="requestor-info-card requestor-work-card">
                            <h4>Work Information</h4>
                            <div class="requestor-info-grid four-columns">
                                <div><span>Employee ID</span><strong id="requestorSettingsEmployeeId">Not provided</strong></div>
                                <div><span>Position</span><strong id="requestorSettingsPosition">Requestor</strong></div>
                                <div><span>Division/ Unit</span><strong id="requestorSettingsDivision">Requestor Office</strong></div>
                                <div><span>Employment Status</span><strong id="requestorSettingsEmployment">Permanent</strong></div>
                            </div>
                            <div class="requestor-info-grid two-columns requestor-work-row-2">
                                <div><span>Step Increment</span><strong id="requestorSettingsStep">Not provided</strong></div>
                                <div><span>Date Created</span><strong id="requestorSettingsDateCreated">Not provided</strong></div>
                            </div>
                        </section>
                    </div>
                    <section class="requestor-security-card">
                        <h4>Security Settings</h4>
                        <div><span>Username</span><strong id="requestorSettingsUsername"><?php echo htmlspecialchars($requestorProfile['username'], ENT_QUOTES, 'UTF-8'); ?></strong></div>
                        <div><span>Password</span><strong>************</strong></div>
                        <button type="button" id="requestorChangePasswordBtn">Change Password</button>
                    </section>
                </div>
            </div>
        </div>

    </main>

    <div id="cartDrawer" class="req-drawer">
        <div class="req-drawer-panel">
            <div class="req-drawer-header">
                <div>
                    <h3>Request Cart</h3>
                    <p id="cartSummary">0 items</p>
                </div>
                <button type="button" class="req-modal-close" id="closeCartDrawer" aria-label="Close">&times;</button>
            </div>
            <div class="req-drawer-body" id="cartItemsList"></div>
            <div class="req-drawer-footer">
                <button type="button" class="req-btn-secondary" id="keepShoppingBtn" onclick="closeCartDrawer()">Continue</button>
                <button type="button" class="req-btn-primary" id="submitCartBtn">Submit Request</button>
            </div>
        </div>
    </div>

    <div id="ppmpHistoryDrawer" class="req-drawer">
        <div class="req-drawer-panel">
            <div class="req-drawer-header">
                <div>
                    <h3>PPMP History</h3>
                    <p>Accepted PPMP inventory changes</p>
                </div>
                <button type="button" class="req-modal-close" id="closePpmpHistoryDrawer" aria-label="Close PPMP history">&times;</button>
            </div>
            <div class="req-drawer-body" id="inventoryAuditList">
                <div class="empty-state">No accepted PPMP inventory changes yet.</div>
            </div>
        </div>
    </div>

    <div id="ppmpModal" class="req-drawer">
        <div class="req-drawer-panel ppmp-upload-panel">
            <div class="req-drawer-header">
                <div>
                    <h3>Upload PPMP</h3>
                    <p>Submit a PPMP for Supply review</p>
                </div>
                <button type="button" class="req-modal-close" id="closePpmpModal" aria-label="Close">&times;</button>
            </div>
            <form id="ppmpUploadForm" enctype="multipart/form-data">
                <div class="ppmp-upload-field">
                    <label class="req-field-label" for="ppmpFiscalYear">Fiscal Year <span>*</span></label>
                    <select id="ppmpFiscalYear" name="fiscal_year" required>
                        <option value="2026">2026</option>
                        <option value="2027">2027</option>
                        <option value="2028">2028</option>
                    </select>
                </div>
                <div class="ppmp-upload-field">
                    <label class="req-field-label" for="ppmpFile">Select File <span>*</span></label>
                    <label class="ppmp-drop-zone" for="ppmpFile">
                        <span class="ppmp-upload-icon">⇧</span>
                        <strong id="ppmpFileName">Choose File</strong>
                        <small>Only .xlsx files are accepted</small>
                    </label>
                    <input id="ppmpFile" name="ppmp_file" type="file" accept=".xlsx" required hidden>
                </div>
                <div class="ppmp-upload-actions">
                    <button type="submit" class="req-btn-primary">⇧ &nbsp; Upload PPMP</button>
                </div>
                <div class="ppmp-upload-note"><strong>ⓘ &nbsp; Note</strong><span>Only PPMP .xlsx files are allowed. Maximum file size is 10MB.</span></div>
            </form>
        </div>
    </div>

    <div id="requestorProfileEditModal" class="requestor-profile-edit-modal" aria-hidden="true">
        <div class="requestor-profile-edit-panel" role="dialog" aria-modal="true" aria-labelledby="requestorProfileEditTitle">
            <div class="requestor-profile-edit-header">
                <div><h3 id="requestorProfileEditTitle">Edit Profile</h3><p>Update the information displayed on your profile</p></div>
                <button type="button" id="closeRequestorProfileEdit" aria-label="Close">&times;</button>
            </div>
            <div class="requestor-profile-edit-body">
                <div class="requestor-avatar-upload">
                    <div class="requestor-avatar-preview" id="requestorEditAvatarPreview" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                    </div>
                    <div class="requestor-edit-field"><label for="requestorEditAvatarInput">Profile Image</label><input id="requestorEditAvatarInput" type="file" accept="image/png,image/jpeg,image/gif,image/webp"></div>
                </div>
                <div class="requestor-edit-field"><label for="requestorEditDisplayName">Display Name</label><input id="requestorEditDisplayName" type="text"></div>
                <div class="requestor-edit-field"><label for="requestorEditEmail">Email</label><input id="requestorEditEmail" type="email"></div>
                <div class="requestor-edit-field"><label for="requestorEditPhone">Phone Number</label><input id="requestorEditPhone" type="text"></div>
                <div class="requestor-edit-field"><label for="requestorEditAddress">Address</label><input id="requestorEditAddress" type="text"></div>
                <div class="requestor-edit-row"><div class="requestor-edit-field"><label for="requestorEditDob">Date of Birth</label><input id="requestorEditDob" type="text"></div><div class="requestor-edit-field"><label for="requestorEditGender">Gender</label><input id="requestorEditGender" type="text"></div></div>
                <div class="requestor-edit-row"><div class="requestor-edit-field"><label for="requestorEditCivil">Civil Status</label><input id="requestorEditCivil" type="text"></div><div class="requestor-edit-field"><label for="requestorEditNationality">Nationality</label><input id="requestorEditNationality" type="text"></div></div>
                <div class="requestor-edit-field"><label for="requestorEditBureau">Bureau / Unit</label><input id="requestorEditBureau" type="text"></div>
                <div class="requestor-edit-row"><div class="requestor-edit-field"><label for="requestorEditEmployeeId">Employee ID</label><input id="requestorEditEmployeeId" type="text"></div><div class="requestor-edit-field"><label for="requestorEditPosition">Position</label><input id="requestorEditPosition" type="text"></div></div>
                <div class="requestor-edit-row"><div class="requestor-edit-field"><label for="requestorEditEmployment">Employment Status</label><input id="requestorEditEmployment" type="text"></div><div class="requestor-edit-field"><label for="requestorEditStep">Step Increment</label><input id="requestorEditStep" type="text"></div></div>
                <div class="requestor-edit-field"><label for="requestorEditDateCreated">Date Created</label><input id="requestorEditDateCreated" type="text"></div>
            </div>
            <div class="requestor-profile-edit-footer"><button type="button" class="requestor-edit-cancel" id="cancelRequestorProfileEdit">Cancel</button><button type="button" class="requestor-edit-save" id="saveRequestorProfile">Update Information</button></div>
        </div>
    </div>

    <script>
        window.requestorProvince = <?php echo json_encode(trim((string)($_SESSION['province'] ?? ''))); ?>;
        window.requestorUsername = <?php echo json_encode(trim((string)($_SESSION['username'] ?? ''))); ?>;
    </script>
    <script src="REQ.js?v=20260906-ppmp-upload-panel"></script>
</body>
</html>
