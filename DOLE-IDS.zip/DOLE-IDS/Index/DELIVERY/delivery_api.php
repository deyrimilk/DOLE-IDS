<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

require_once __DIR__ . '/../../Login/db_connect.php';
require_once __DIR__ . '/../../Login/activity_log.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$role = strtolower((string)($_SESSION['role'] ?? ''));
$province = trim((string)($_SESSION['province'] ?? ''));

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$allowedRoles = ['admin', 'approver', 'requester', 'delivery'];
if (!in_array($role, $allowedRoles, true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden']);
    exit;
}

if ($role === 'requester' && $province === '' && in_array($action, ['list', 'list_completed'], true)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Your account must have a province assigned to view delivery records.']);
    exit;
}

if ($method !== 'GET' && !in_array($role, ['delivery', 'approver', 'admin'], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You are not allowed to update delivery status']);
    exit;
}

function readJsonBody(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function findProvinceCourier(PDO $pdo, string $province): ?string
{
    $province = trim($province);
    if ($province === '') {
        return null;
    }

    $stmt = $pdo->prepare(
        "SELECT full_name FROM users
         WHERE LOWER(role) = 'delivery'
           AND LOWER(TRIM(COALESCE(province, ''))) = LOWER(TRIM(?))
         ORDER BY id ASC LIMIT 1"
    );
    $stmt->execute([$province]);
    $name = trim((string)($stmt->fetchColumn() ?: ''));
    return $name !== '' ? $name : null;
}

function requireCsrfToken(): void
{
    $headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    $sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
    $cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

    if ($headerToken === '') {
        throw new Exception('Missing CSRF token');
    }

    $valid = $sessionToken !== '' && hash_equals($sessionToken, $headerToken);
    if (!$valid) {
        throw new Exception('Invalid CSRF token');
    }
}

try {
    if ($method === 'GET' && $action === 'list_completed') {
        $sql = "SELECT dl.*, r.requestor AS requestor_province
                FROM delivery_logs dl
                LEFT JOIN requests r ON r.id = dl.request_id";
        if (strcasecmp($role, 'delivery') === 0 && $province !== '') {
            $sql .= " WHERE (LOWER(TRIM(COALESCE(dl.office, ''))) = LOWER(TRIM(:province_a))
                                 OR LOWER(TRIM(COALESCE(r.requestor, ''))) = LOWER(TRIM(:province_b)))";
        } elseif (strcasecmp($role, 'requester') === 0 && $province !== '') {
            $sql .= " WHERE dl.completed_at IS NOT NULL
                         AND (LOWER(TRIM(COALESCE(dl.office, ''))) = LOWER(TRIM(:province_a))
                                 OR LOWER(TRIM(COALESCE(r.requestor, ''))) = LOWER(TRIM(:province_b)))";
        } else {
            $sql .= " WHERE dl.completed_at IS NOT NULL";
        }
        $sql .= " ORDER BY dl.completed_at DESC";

        $stmt = $pdo->prepare($sql);
        if ((strcasecmp($role, 'delivery') === 0 || strcasecmp($role, 'requester') === 0) && $province !== '') {
            $stmt->execute([':province_a' => $province, ':province_b' => $province]);
        } else {
            $stmt->execute();
        }
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as &$row) {
            if (empty($row['courier_name'])) {
                $row['courier_name'] = findProvinceCourier($pdo, (string)($row['requestor_province'] ?? $row['office'] ?? ''));
            }
            if ($role === 'delivery') {
                unset($row['scan_code']);
            }
            unset($row['requestor_province']);
        }
        unset($row);

        echo json_encode([
            'success' => true,
            'data' => $rows
        ]);
        exit;
    }

    if ($method === 'GET' && $action === 'list') {
        $sql = "SELECT dp.*, r.requestor AS requestor_province
                FROM delivery_packages dp
                LEFT JOIN requests r ON r.id = dp.request_id
                WHERE NOT EXISTS (
                        SELECT 1
                        FROM delivery_logs dl
                        WHERE dl.request_id = dp.request_id
                            AND dl.completed_at IS NOT NULL
                )
                AND (dp.request_id IS NULL OR r.status = 'Approved')";

        if ((strcasecmp($role, 'delivery') === 0 || strcasecmp($role, 'requester') === 0) && $province !== '') {
            $sql .= " AND (LOWER(TRIM(COALESCE(dp.office, ''))) = LOWER(TRIM(:province_a))
                         OR LOWER(TRIM(COALESCE(r.requestor, ''))) = LOWER(TRIM(:province_b)))";
        }

        $sql .= " ORDER BY dp.created_at DESC";

        $stmt = $pdo->prepare($sql);
        if ((strcasecmp($role, 'delivery') === 0 || strcasecmp($role, 'requester') === 0) && $province !== '') {
            $stmt->execute([':province_a' => $province, ':province_b' => $province]);
        } else {
            $stmt->execute();
        }
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as &$row) {
            if (empty($row['courier_name'])) {
                $row['courier_name'] = findProvinceCourier($pdo, (string)($row['requestor_province'] ?? $row['office'] ?? ''));
            }
            if ($role === 'delivery') {
                unset($row['scan_code']);
            }
            unset($row['requestor_province']);
        }
        unset($row);

        $existingRequestIds = [];
        foreach ($rows as $row) {
            if (isset($row['request_id']) && $row['request_id'] !== null) {
                $existingRequestIds[(int)$row['request_id']] = true;
            }
        }

        $reqSql = "SELECT r.*
                       FROM requests r
                       WHERE r.status = 'Approved'
                         AND NOT EXISTS (
                             SELECT 1
                             FROM delivery_packages dp2
                             WHERE dp2.request_id = r.id
                         )
                         AND NOT EXISTS (
                             SELECT 1
                             FROM delivery_logs dl
                             WHERE dl.request_id = r.id
                               AND dl.completed_at IS NOT NULL
                         )";

            if ((strcasecmp($role, 'delivery') === 0 || strcasecmp($role, 'requester') === 0) && $province !== '') {
                $reqSql .= " AND LOWER(TRIM(COALESCE(r.requestor, ''))) = LOWER(TRIM(:province))";
            }

            $reqSql .= " ORDER BY r.request_date DESC";
            $reqStmt = $pdo->prepare($reqSql);

            if ((strcasecmp($role, 'delivery') === 0 || strcasecmp($role, 'requester') === 0) && $province !== '') {
                $reqStmt->execute([':province' => $province]);
            } else {
                $reqStmt->execute();
            }

        $requests = $reqStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($requests as $request) {
                if (isset($existingRequestIds[(int)$request['id']])) {
                    continue;
                }
                $items = [];
                if (!empty($request['item_details'])) {
                    $decoded = json_decode((string)$request['item_details'], true);
                    if (is_array($decoded)) {
                        $items = $decoded;
                    }
                }
                if (!$items) {
                    $items[] = ['item_name' => $request['item_name'] ?? 'Item', 'quantity' => (int)($request['quantity'] ?? 0)];
                }

                $formattedItems = [];
                foreach ($items as $entry) {
                    $itemName = trim((string)($entry['item_name'] ?? $entry['name'] ?? ''));
                    $quantity = (int)($entry['quantity'] ?? 0);
                    if ($itemName === '' || $quantity <= 0) {
                        continue;
                    }
                    $formattedItems[] = $itemName . ' x' . $quantity;
                }

                $rows[] = [
                    'id' => (int)$request['id'],
                    'package_id' => 'PKG-' . $request['id'],
                    'request_id' => (int)$request['id'],
                    'office' => $request['requestor'] ?: 'Unknown office',
                    'item_name' => implode(', ', $formattedItems) ?: ($request['item_name'] ?? 'Unknown item'),
                    'status' => 'ready',
                    'eta' => '—',
                    'courier_name' => findProvinceCourier($pdo, (string)($request['requestor'] ?? '')),
                    'scanned_at' => null,
                    'delivered_at' => null,
                    'created_at' => $request['request_date'] ?? null,
                    'updated_at' => $request['request_date'] ?? null,
                ];
        }

        echo json_encode([
            'success' => true,
            'data' => $rows
        ]);
        exit;
    }

    if ($method === 'POST' && $action === 'update_status') {
        requireCsrfToken();

        $input = readJsonBody();

        if (!isset($input['id']) || !isset($input['status'])) {
            throw new Exception('Missing required fields: id, status');
        }

        $allowedStatuses = ['ready', 'picked', 'delivering', 'shipped', 'completed', 'cancelled', 'returned'];
        $status = strtolower((string)$input['status']);

        if (!in_array($status, $allowedStatuses, true)) {
            throw new Exception('Invalid status value');
        }

        $packageId = trim((string)$input['id']);
        $submittedScanCode = strtoupper(trim((string)($input['scan_code'] ?? '')));
        $requestId = null;
        if (isset($input['request_id']) && is_numeric($input['request_id'])) {
            $requestId = (int)$input['request_id'];
        } elseif (preg_match('/^PKG-(\d+)$/i', $packageId, $matches)) {
            $requestId = (int)$matches[1];
        }

        $existingStmt = $pdo->prepare('SELECT * FROM delivery_packages WHERE package_id = ? LIMIT 1');
        $existingStmt->execute([$packageId]);
        $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);
        $previousStatus = $existing['status'] ?? null;

        $allowedTransitions = [
            'ready' => ['picked', 'shipped', 'completed', 'cancelled'],
            'picked' => ['delivering', 'shipped', 'completed', 'cancelled'],
            'delivering' => ['completed', 'returned'],
            'shipped' => ['completed', 'returned'],
        ];
        if ($existing && $status !== strtolower((string)$previousStatus)
            && !in_array($status, $allowedTransitions[strtolower((string)$previousStatus)] ?? [], true)) {
            throw new Exception('Invalid delivery status transition.');
        }
        if ($existing && $status === strtolower((string)$previousStatus)) {
            throw new Exception('Delivery is already in that status.');
        }

        $assignedOffice = $province !== '' ? $province : 'Province-synced';
        if ($requestId) {
            $requestStmt = $pdo->prepare('SELECT requestor, status FROM requests WHERE id = ? LIMIT 1');
            $requestStmt->execute([$requestId]);
            $requestRow = $requestStmt->fetch(PDO::FETCH_ASSOC);
            if (!$requestRow || strcasecmp((string)$requestRow['status'], 'Approved') !== 0) {
                throw new Exception('A delivery can only be created for an approved request.');
            }
            if (!empty($requestRow['requestor'])) {
                $assignedOffice = (string)$requestRow['requestor'];
            }
        } elseif (!$existing) {
            throw new Exception('A new delivery must reference an approved request.');
        }

        $assignedCourier = findProvinceCourier($pdo, $assignedOffice);

        if (strcasecmp($role, 'delivery') === 0 && $province !== '') {
            $provinceMatches = strcasecmp(trim($assignedOffice), trim($province)) === 0;
            if (!$provinceMatches) {
                http_response_code(403);
                echo json_encode([
                    'success' => false,
                    'message' => 'This delivery is assigned to another province.'
                ]);
                exit;
            }
        }

        if (!$existing) {
            $generatedScanCode = 'DLV-' . strtoupper(bin2hex(random_bytes(10)));
            $insertStmt = $pdo->prepare(
                'INSERT INTO delivery_packages (package_id, scan_code, request_id, office, item_name, status, eta, courier_name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())'
            );
            $insertStmt->execute([$packageId, $generatedScanCode, $requestId, $assignedOffice, 'Pending sync', $status, '—', $assignedCourier]);
            $existingStmt->execute([$packageId]);
            $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);
        } else {
            if ($requestId && empty($existing['request_id'])) {
                $pdo->prepare('UPDATE delivery_packages SET request_id = ? WHERE package_id = ?')
                    ->execute([$requestId, $packageId]);
            }
            if ($assignedOffice !== 'Province-synced' && ($existing['office'] === 'Province-synced' || empty($existing['office']))) {
                $pdo->prepare('UPDATE delivery_packages SET office = ? WHERE package_id = ?')
                    ->execute([$assignedOffice, $packageId]);
            }
            if ($assignedCourier !== null && empty($existing['courier_name'])) {
                $pdo->prepare('UPDATE delivery_packages SET courier_name = ? WHERE package_id = ?')
                    ->execute([$assignedCourier, $packageId]);
            }
            if (empty($existing['scan_code'])) {
                $generatedScanCode = 'DLV-' . strtoupper(bin2hex(random_bytes(10)));
                $pdo->prepare('UPDATE delivery_packages SET scan_code = ? WHERE package_id = ?')
                    ->execute([$generatedScanCode, $packageId]);
                $existing['scan_code'] = $generatedScanCode;
            }
        }

        if ($role === 'delivery' && $status === 'completed') {
            if ($submittedScanCode === '' || empty($existing['scan_code']) || !hash_equals(strtoupper((string)$existing['scan_code']), $submittedScanCode)) {
                throw new Exception('Invalid delivery code. Enter the code printed by Supply.');
            }
        }

        if ($status === 'completed') {
            $logStmt = $pdo->prepare(
                'INSERT INTO delivery_logs (package_id, scan_code, request_id, office, item_name, status, eta, courier_name, scanned_at, delivered_at, completed_at)
                 SELECT package_id, scan_code, request_id, office, item_name, "completed", eta, courier_name, scanned_at, NOW(), NOW()
                 FROM delivery_packages WHERE package_id = ?'
            );
            $logStmt->execute([$packageId]);

            $deleteStmt = $pdo->prepare('DELETE FROM delivery_packages WHERE package_id = ?');
            $deleteStmt->execute([$packageId]);

            recordSystemActivity(
                $pdo,
                'delivery_status_changed',
                'delivery',
                $packageId,
                (string)($existing['office'] ?? $assignedOffice),
                'Delivery marked completed',
                [
                    'request_id' => $requestId,
                    'from_status' => $previousStatus,
                    'to_status' => 'completed',
                    'item_name' => $existing['item_name'] ?? '',
                    'courier_name' => $existing['courier_name'] ?? $assignedCourier,
                ]
            );

            echo json_encode([
                'success' => true,
                'message' => 'Package completed and archived to delivery logs',
                'data' => ['package_id' => $packageId, 'status' => 'completed']
            ]);
            exit;
        }

        $pdo->prepare(
            'UPDATE delivery_packages SET status = ?, updated_at = NOW(), scanned_at = IF(scanned_at IS NULL, NOW(), scanned_at), delivered_at = IF(? = "completed", NOW(), delivered_at) WHERE package_id = ?'
        )->execute([$status, $status, $packageId]);

        $stmt = $pdo->prepare('SELECT * FROM delivery_packages WHERE package_id = ? LIMIT 1');
        $stmt->execute([$packageId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (strcasecmp((string)$previousStatus, $status) !== 0) {
            recordSystemActivity(
                $pdo,
                'delivery_status_changed',
                'delivery',
                $packageId,
                (string)($row['office'] ?? $assignedOffice),
                'Delivery status changed to ' . $status,
                [
                    'request_id' => $requestId,
                    'from_status' => $previousStatus,
                    'to_status' => $status,
                    'item_name' => $row['item_name'] ?? '',
                    'courier_name' => $row['courier_name'] ?? $assignedCourier,
                ]
            );
        }

        echo json_encode([
            'success' => true,
            'message' => 'Package status updated successfully',
            'data' => $row
        ]);
        exit;
    }

    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid action or method'
    ]);
} catch (Throwable $e) {
    error_log('Delivery API error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => getenv('DOLE_DEBUG') === '1'
            ? $e->getMessage()
            : 'The delivery request could not be completed.'
    ]);
}
