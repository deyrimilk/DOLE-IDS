const deliveryQueueKey = 'dole_delivery_queue_v1';
const recordKey = 'dole_delivery_record_v1';
const historyKey = 'dole_delivery_history_v1';
const sessionKey = 'dole_delivery_session_v1';
const sharedDeliveryMetaKey = 'central_delivery_meta_v1';
const selectedPackageKey = 'dole_selected_package_v1';
const deliveryApiPath = 'delivery_api.php';
const deliveryProvince = String(window.deliveryProvince || '').trim();
let activeCameraStream = null;
let verifiedPackageId = '';
let verifiedScanCode = '';
let expectedScanPackageId = '';
let deliveryQueue = null;
let deliveryHistory = null;

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function getCsrfToken() {
    const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : '';
}

function withCsrfHeaders(headers = {}) {
    return {
        ...headers,
        'X-CSRF-Token': getCsrfToken()
    };
}

const seedQueue = [];

function safeRead(key, fallback) {
    try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
    } catch {
        return fallback;
    }
}

function safeWrite(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

function publishNotification(payload) {
    try {
        const notification = {
            type: payload.type || 'info',
            title: payload.title || 'Notification',
            message: payload.message || '',
            requestId: payload.requestId || null,
            packageId: payload.packageId || null,
            status: payload.status || null,
            source: payload.source || 'delivery',
            updatedAt: new Date().toISOString()
        };
        localStorage.setItem('dole_notification_v1', JSON.stringify(notification));
    } catch (error) {
        console.warn('Could not publish notification.', error);
    }
}

function normalizeQueueEntry(row) {
    return {
        id: row.package_id || row.id || '—',
        requestId: row.request_id || null,
        office: row.office || 'Office',
        item: row.item_name || row.item || 'Unknown item',
        status: String(row.status || 'ready').toLowerCase(),
        eta: row.eta || '—',
        courier: row.courier_name || '—'
    };
}

async function fetchDeliveryQueue() {
    try {
        const response = await fetch(`${deliveryApiPath}?action=list`, {
            credentials: 'same-origin'
        });

        const payload = await response.json();
        if (!payload?.success) {
            throw new Error(payload?.message || 'Delivery queue unavailable.');
        }

        const queue = Array.isArray(payload.data) ? payload.data.map(normalizeQueueEntry) : [];
        deliveryQueue = queue;
        safeWrite(deliveryQueueKey, queue);
        return queue;
    } catch (error) {
        console.warn('Delivery API list failed, falling back to local queue.', error);
        const queue = safeRead(deliveryQueueKey, seedQueue);
        deliveryQueue = Array.isArray(queue) ? queue : [];
        return Array.isArray(queue) && queue.length ? queue : [];
    }
}

async function fetchDeliveryHistory() {
    try {
        const response = await fetch(`${deliveryApiPath}?action=list_completed`, {
            credentials: 'same-origin',
            cache: 'no-store'
        });
        const payload = await response.json();
        if (!payload?.success) {
            throw new Error(payload?.message || 'Delivery history unavailable.');
        }
        const history = Array.isArray(payload.data) ? payload.data.map(normalizeQueueEntry) : [];
        deliveryHistory = history;
        safeWrite(historyKey, history);
        return history;
    } catch (error) {
        console.warn('Delivery history API failed, using saved history.', error);
        const history = safeRead(historyKey, []);
        deliveryHistory = Array.isArray(history) ? history : [];
        return deliveryHistory;
    }
}

function loadQueue() {
    if (Array.isArray(deliveryQueue)) {
        return deliveryQueue;
    }
    const queue = safeRead(deliveryQueueKey, null);
    if (!queue || !Array.isArray(queue) || !queue.length) {
        safeWrite(deliveryQueueKey, seedQueue);
        return [...seedQueue];
    }
    return queue;
}

function updateProvinceBadge() {
    const badge = document.getElementById('deliveryProvinceBadge');
    if (!badge) return;
    badge.textContent = deliveryProvince ? `Province: ${deliveryProvince}` : 'Province: —';
}

function renderQueue() {
    const queue = loadQueue();
    const list = document.getElementById('packageList');
    const pendingCount = document.getElementById('pendingCount');
    const pickedCount = document.getElementById('pickedCount');
    const routeCount = document.getElementById('routeCount');
    const selectedId = safeRead(selectedPackageKey, null);

    if (!list) return;

    list.innerHTML = queue.map((item) => {
        const status = ['ready', 'picked', 'delivering', 'shipped', 'completed', 'cancelled', 'returned'].includes(item.status)
            ? item.status
            : 'ready';
        const isSelected = selectedId && String(item.id).toLowerCase() === String(selectedId).toLowerCase();
        const label = status === 'ready'
            ? 'Ready'
            : status === 'picked'
                ? 'Picked up'
                : status === 'delivering' || status === 'shipped'
                    ? 'In transit'
                    : 'Completed';
        return `
            <article class="package-item ${isSelected ? 'selected' : ''}" data-package-id="${escapeHtml(item.id)}">
                <div class="package-top">
                    <div>
                        <h4 class="package-title">${escapeHtml(item.id)}</h4>
                        <p class="package-meta">${escapeHtml(item.office)} • ${escapeHtml(item.item)}</p>
                        <p class="package-meta">Courier: ${escapeHtml(item.courier)}</p>
                    </div>
                    <span class="package-chip ${status}">${label}</span>
                </div>
                <div class="package-bottom">
                    <span class="package-meta">ETA ${escapeHtml(item.eta)}</span>
                    <span class="package-meta">${status === 'ready' ? 'Awaiting courier' : status === 'completed' ? 'Delivery finished' : 'Delivery active'}</span>
                </div>
            </article>
        `;
    }).join('');

    const readyCount = queue.filter((item) => item.status === 'ready').length;
    const picked = queue.filter((item) => item.status === 'picked').length;
    const delivering = queue.filter((item) => item.status === 'delivering' || item.status === 'shipped').length;

    if (pendingCount) pendingCount.textContent = String(readyCount).padStart(2, '0');
    if (pickedCount) pickedCount.textContent = String(picked).padStart(2, '0');
    if (routeCount) routeCount.textContent = String(delivering).padStart(2, '0');
}

function renderTimeline() {
    const queue = loadQueue();
    const current = queue.find((item) => item.status === 'picked' || item.status === 'delivering' || item.status === 'shipped') || queue[0];
    const timeline = document.getElementById('timeline');

    if (!timeline) return;

    const steps = [
        { title: 'Approved by Supply', text: 'Package has been released to dispatch.' },
        { title: 'Picked up by Delivery', text: current ? `${current.id} is now physically in the courier’s custody.` : 'Awaiting scan.' },
        { title: 'Out for delivery', text: 'Requestor and supply team will see live status on their views.' }
    ];

    timeline.innerHTML = steps.map((step, index) => `
        <div class="timeline-item">
            <span class="timeline-dot"></span>
            <div class="timeline-copy">
                <h4>${index + 1}. ${escapeHtml(step.title)}</h4>
                <p>${escapeHtml(step.text)}</p>
            </div>
        </div>
    `).join('');
}

function getActivePackageDetails() {
    const queue = loadQueue();
    const selectedId = safeRead(selectedPackageKey, null);
    const record = safeRead(recordKey, null);

    const current = queue.find((item) => String(item.id).toLowerCase() === String(selectedId || '').toLowerCase())
        || queue.find((item) => item.status === 'picked' || item.status === 'delivering')
        || queue[0];

    const activeRecord = record && String(record.id || '').toLowerCase() === String(selectedId || '').toLowerCase()
        ? record
        : current;

    return activeRecord || current || null;
}

function renderSummaryCard() {
    const activeRecord = getActivePackageDetails();
    const id = document.getElementById('summaryId');
    const office = document.getElementById('summaryOffice');
    const item = document.getElementById('summaryItem');
    const eta = document.getElementById('summaryEta');
    const badge = document.getElementById('summaryStatusBadge');

    if (!id || !office || !item || !eta || !badge) return;

    if (!activeRecord) {
        id.textContent = '—';
        office.textContent = '—';
        item.textContent = '—';
        eta.textContent = '—';
        badge.textContent = 'Awaiting scan';
        return;
    }

    id.textContent = activeRecord.id || '—';
    office.textContent = activeRecord.office || '—';
    item.textContent = activeRecord.item || '—';
    eta.textContent = activeRecord.eta || '—';
    badge.textContent = activeRecord.status === 'ready' ? 'Ready' : activeRecord.status === 'picked' ? 'Picked up' : activeRecord.status === 'delivering' || activeRecord.status === 'shipped' ? 'In transit' : 'Awaiting scan';
}

function renderDispatchDetailCard() {
    const activeRecord = getActivePackageDetails();
    const id = document.getElementById('dispatchId');
    const office = document.getElementById('dispatchOffice');
    const item = document.getElementById('dispatchItem');
    const eta = document.getElementById('dispatchEta');
    const badge = document.getElementById('dispatchStatusBadge');

    if (!id || !office || !item || !eta || !badge) return;

    if (!activeRecord) {
        id.textContent = '—';
        office.textContent = '—';
        item.textContent = '—';
        eta.textContent = '—';
        badge.textContent = 'Awaiting scan';
        return;
    }

    id.textContent = activeRecord.id || '—';
    office.textContent = activeRecord.office || '—';
    item.textContent = activeRecord.item || '—';
    eta.textContent = activeRecord.eta || '—';
    badge.textContent = activeRecord.status === 'ready' ? 'Ready' : activeRecord.status === 'picked' ? 'Picked up' : activeRecord.status === 'delivering' || activeRecord.status === 'shipped' ? 'In transit' : 'Awaiting scan';
}

function renderMyPickups() {
    const queue = loadQueue();
    const list = document.getElementById('pickupList');
    if (!list) return;

    const activeItems = queue.filter((item) => item.status === 'ready' || item.status === 'picked' || item.status === 'delivering' || item.status === 'shipped');

    if (!activeItems.length) {
        list.innerHTML = `
            <article class="pickup-item">
                <h4>No active pickups</h4>
                <p>Scan a package to add it to your active pickups.</p>
            </article>
        `;
        return;
    }

    list.innerHTML = activeItems.map((item) => `
        <article class="pickup-item">
            <h4>${escapeHtml(item.id)}</h4>
            <p>${escapeHtml(item.office)} • ${escapeHtml(item.item)}</p>
            <p>Status: ${item.status === 'ready' ? 'Ready for pickup' : item.status === 'picked' ? 'Picked up' : item.status === 'shipped' || item.status === 'delivering' ? 'In transit' : 'In transit'} • ETA ${escapeHtml(item.eta)}</p>
            <div class="pickup-actions">
                <button class="ghost-btn summary-btn" data-summary-id="${escapeHtml(item.id)}">Summary</button>
                <button type="button" class="pickup-finished scan-package-btn" data-scan-package="${escapeHtml(item.id)}">Scan package QR</button>
            </div>
        </article>
    `).join('');
}

function renderPickupHistory() {
    const list = document.getElementById('pickupHistoryList');
    if (!list) return;

    const completedItems = Array.isArray(deliveryHistory) ? deliveryHistory : [];
    if (!completedItems.length) {
        list.innerHTML = '<article class="pickup-item"><h4>No pickup history</h4><p>Completed deliveries will appear here.</p></article>';
        return;
    }

    list.innerHTML = completedItems.map(item => `
        <article class="pickup-item">
            <h4>${escapeHtml(item.id)}</h4>
            <p>${escapeHtml(item.office)} • ${escapeHtml(item.item)}</p>
            <p>Status: Completed • ETA ${escapeHtml(item.eta)}</p>
            <div class="pickup-actions">
                <button class="ghost-btn summary-btn" data-summary-id="${escapeHtml(item.id)}">Summary</button>
                <span class="pickup-finished">Finished</span>
            </div>
        </article>
    `).join('');
}

function openScannerForPackage(packageId) {
    document.querySelectorAll('.page-screen').forEach(page => page.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
    document.getElementById('scanner-screen')?.classList.add('active');
    document.querySelector('[data-screen="pickups"]')?.classList.add('active');
    const modal = document.getElementById('requestModal');
    modal?.classList.add('hidden');
    modal?.setAttribute('aria-hidden', 'true');
    const input = document.getElementById('barcodeInput');
    expectedScanPackageId = String(packageId || '').trim().toUpperCase();
    verifiedPackageId = '';
    verifiedScanCode = '';
    if (input) input.value = '';
    startCameraScanner();
    const status = document.getElementById('scannerStatus');
    if (status) status.textContent = `Scan the printed QR for ${expectedScanPackageId}.`;
}

function openSummaryModal(packageId) {
    const queue = loadQueue();
    const item = queue.find((entry) => String(entry.id || '').toLowerCase() === String(packageId || '').toLowerCase());
    const summaryModal = document.getElementById('summaryModal');
    const summaryId = document.getElementById('summaryModalId');
    const summaryOffice = document.getElementById('summaryModalOffice');
    const summaryItem = document.getElementById('summaryModalItem');
    const summaryEta = document.getElementById('summaryModalEta');

    if (!summaryModal || !summaryId || !summaryOffice || !summaryItem || !summaryEta) return;

    if (!item) {
        summaryModal.classList.add('hidden');
        summaryModal.setAttribute('aria-hidden', 'true');
        return;
    }

    summaryId.textContent = item.id;
    summaryOffice.textContent = item.office;
    summaryItem.textContent = item.item;
    summaryEta.textContent = item.eta;
    summaryModal.classList.remove('hidden');
    summaryModal.setAttribute('aria-hidden', 'false');
}

function renderScanModal() {
    const modal = document.getElementById('requestModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalId = document.getElementById('modalId');
    const modalOffice = document.getElementById('modalOffice');
    const modalItem = document.getElementById('modalItem');
    const modalEta = document.getElementById('modalEta');
    const modalActions = document.getElementById('modalActions');

    if (!modal || !modalTitle || !modalId || !modalOffice || !modalItem || !modalEta || !modalActions) return;

    const activeRecord = getActivePackageDetails();
    if (!activeRecord || !verifiedPackageId || String(activeRecord.id).toLowerCase() !== String(verifiedPackageId).toLowerCase()) {
        modal.classList.add('hidden');
        modal.setAttribute('aria-hidden', 'true');
        return;
    }

    modalTitle.textContent = 'Request Details';
    modalId.textContent = activeRecord.id || '—';
    modalOffice.textContent = activeRecord.office || '—';
    modalItem.textContent = activeRecord.item || '—';
    modalEta.textContent = activeRecord.eta || '—';
    const scanActionStatus = 'completed';
    modalActions.innerHTML = '<button id="confirmScanBtn" class="primary-btn full-width">Confirm Delivery</button>';
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');

    document.getElementById('confirmScanBtn')?.addEventListener('click', async () => {
        const completed = await updateStatus(activeRecord.id, scanActionStatus);
        if (!completed) return;

        modalTitle.textContent = 'Scan Complete';
        modalId.textContent = activeRecord.id || '—';
        modalOffice.textContent = scanActionStatus === 'completed' ? 'Delivery completed successfully' : 'Package picked up successfully';
        modalItem.textContent = 'Courier confirmation complete';
        modalEta.textContent = 'Ready for summary';
        modalActions.innerHTML = `
            <div class="scan-success-wrap">
                <div class="scan-success-icon">✓</div>
                <p class="scan-success-text">Scan Complete</p>
            </div>
            <button id="scanAnotherBtn" class="primary-btn full-width">Scan Another Package</button>
            <button id="showSummaryBtn" class="ghost-btn full-width">Show Summary</button>
        `;

        document.getElementById('scanAnotherBtn')?.addEventListener('click', () => {
            const input = document.getElementById('barcodeInput');
            if (input) input.value = '';
            modal.classList.add('hidden');
            modal.setAttribute('aria-hidden', 'true');
        });

        document.getElementById('showSummaryBtn')?.addEventListener('click', () => {
            modal.classList.add('hidden');
            modal.setAttribute('aria-hidden', 'true');
            document.querySelector('[data-screen="pickups"]')?.click();
            setTimeout(() => openSummaryModal(activeRecord.id), 60);
        });
    });
}

function showToast(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast.hideTimer);
    showToast.hideTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, 2600);
}

function normalizeDeliveryId(id) {
    return String(id || '')
        .trim()
        .toLowerCase()
        .replace(/^pkg-/, '')
        .replace(/[^a-z0-9]/g, '');
}

function risToPackageId(ris) {
    const raw = String(ris || '').trim();
    const match = raw.match(/(\d+)\s*$/);
    if (!match) return '';
    return 'PKG-' + parseInt(match[1], 10);
}

function parsePackageCode(raw) {
    const value = String(raw || '').trim();
    if (!value) return '';

    const upperValue = value.toUpperCase();
    if (/^DLV-[A-Z0-9]+$/i.test(value)) {
        return '';
    }

    try {
        const url = new URL(value, window.location.origin);
        const pkgParam = url.searchParams.get('pkg');
        if (pkgParam) return String(pkgParam).trim().toUpperCase();

        const risParam = url.searchParams.get('ris');
        if (risParam) {
            const pkgFromRis = risToPackageId(risParam);
            if (pkgFromRis) return pkgFromRis;
        }
        if (url.searchParams.has('code') && !pkgParam) {
            return '';
        }
    } catch (e) {
        // not a URL, continue parsing as raw value
    }

    if (/^PKG-[A-Z0-9-]+$/i.test(value)) {
        return upperValue;
    }

    const pkgMatch = value.match(/(PKG-\d+)/i);
    if (pkgMatch) return String(pkgMatch[1]).toUpperCase();

    const risMatch = value.match(/(\d+\.\d+)$/);
    if (risMatch) {
        const pkgFromRis = risToPackageId(risMatch[1]);
        if (pkgFromRis) return pkgFromRis;
    }

    if (/^\d+$/.test(value) || /^PKG-\d+$/i.test(value)) {
        return upperValue;
    }

    return '';
}

function parseSecureDeliveryCode(raw) {
    const value = String(raw || '').trim();
    if (!value) return '';

    try {
        const url = new URL(value, window.location.origin);
        const codeParam = url.searchParams.get('code');
        if (codeParam) return String(codeParam).trim().toUpperCase();
    } catch (e) {
        // not a URL, continue parsing as raw code
    }

    const codeMatch = value.match(/(DLV-[A-F0-9]{20})/i);
    return codeMatch ? codeMatch[1].toUpperCase() : '';
}

function getInitialPackageFromQuery() {
    const params = new URLSearchParams(window.location.search);
    const pkgParam = params.get('pkg');
    const risParam = params.get('ris');
    if (pkgParam) return parsePackageCode(pkgParam);
    if (risParam) return parsePackageCode(risParam);
    return '';
}

function syncSharedDeliveryState(id, status) {
    const sharedMeta = safeRead(sharedDeliveryMetaKey, {});
    const normalized = normalizeDeliveryId(id);
    const note = status === 'picked'
        ? 'Package picked up by courier.'
        : status === 'delivering'
            ? 'Package is now in transit for delivery.'
            : status === 'completed'
                ? 'Package has arrived and delivery is complete.'
                : 'Package status updated.';

    sharedMeta[String(id).trim()] = {
        status,
        note,
        driver: 'Courier',
        updatedAt: new Date().toISOString()
    };

    sharedMeta[normalized] = {
        status,
        note,
        driver: 'Courier',
        updatedAt: new Date().toISOString()
    };

    safeWrite(sharedDeliveryMetaKey, sharedMeta);
}

async function updateStatus(id, nextStatus) {
    const queue = loadQueue();
    const target = queue.find((item) => String(item.id || '').toLowerCase() === String(id || '').toLowerCase());

    if (!target) {
        showToast('Package not found.');
        return;
    }

    if (nextStatus === 'completed' && String(verifiedPackageId).toLowerCase() !== String(target.id).toLowerCase()) {
        showToast('Scan this package QR code before finishing the delivery.');
        return;
    }
    if (nextStatus === 'completed' && !verifiedScanCode) {
        showToast('Enter the secure delivery code printed by Supply.');
        return;
    }

    try {
        const response = await fetch(`${deliveryApiPath}?action=update_status`, {
            method: 'POST',
            headers: withCsrfHeaders({
                'Content-Type': 'application/json'
            }),
            credentials: 'same-origin',
            body: JSON.stringify({ id: target.id, status: nextStatus, scan_code: verifiedScanCode })
        });

        const payload = await response.json();
        if (!payload?.success) {
            throw new Error(payload?.message || 'Could not update package status.');
        }

        const updatedQueue = await fetchDeliveryQueue();
        if (nextStatus === 'completed') {
            verifiedPackageId = '';
            verifiedScanCode = '';
            localStorage.removeItem(selectedPackageKey);
            await fetchDeliveryHistory();
        }
        safeWrite(recordKey, {
            id: target.id,
            requestId: normalizeDeliveryId(target.id),
            office: target.office,
            item: target.item,
            eta: target.eta,
            status: nextStatus,
            updatedAt: new Date().toISOString()
        });
        publishNotification({
            type: 'delivery_status',
            title: `Delivery ${target.id}`,
            message: `Delivery ${target.id} status changed to ${nextStatus}.`, 
            packageId: target.id,
            requestId: normalizeDeliveryId(target.id),
            status: nextStatus,
            source: 'delivery'
        });
        syncSharedDeliveryState(target.id, nextStatus);
        renderQueue();
        renderTimeline();
        renderSummaryCard();
        renderDispatchDetailCard();
        renderMyPickups();
        renderPickupHistory();
        showToast(`Package ${target.id} marked as ${nextStatus}.`);
        return updatedQueue;
    } catch (error) {
        console.warn('Delivery update failed.', error);
        showToast(error.message || 'Could not update package status.');
        return null;
    }
}

function scanPackage() {
    const input = document.getElementById('barcodeInput');
    const rawBarcode = (input?.value || '').trim();
    const scannedCode = parseSecureDeliveryCode(rawBarcode);
    let barcode = parsePackageCode(rawBarcode);

    if (expectedScanPackageId && scannedCode && !barcode) {
        barcode = expectedScanPackageId;
    }

    if (!barcode && !scannedCode) {
        showToast('Enter a package code or secure delivery code first.');
        return;
    }

    if (!scannedCode && expectedScanPackageId) {
        verifiedPackageId = '';
        showToast('Enter the secure delivery code printed by Supply.');
        return;
    }

    if (expectedScanPackageId && barcode && barcode.toUpperCase() !== expectedScanPackageId) {
        verifiedPackageId = '';
        const modal = document.getElementById('requestModal');
        modal?.classList.add('hidden');
        modal?.setAttribute('aria-hidden', 'true');
        showToast(`QR mismatch. Scan the printed QR for ${expectedScanPackageId}.`);
        return;
    }

    const finalBarcode = expectedScanPackageId ? expectedScanPackageId : barcode;
    safeWrite(selectedPackageKey, finalBarcode);
    const statusNode = document.getElementById('scannerStatus');
    if (statusNode) statusNode.textContent = `Package scanned: ${finalBarcode}. Ready to confirm details...`;

    const queue = loadQueue();
    const target = queue.find((item) => String(item.id || '').toLowerCase() === finalBarcode.toLowerCase());
    if (target && target.status !== 'completed' && scannedCode) {
        verifiedPackageId = target.id;
        verifiedScanCode = scannedCode;
        expectedScanPackageId = '';
        safeWrite(recordKey, {
            id: target.id,
            requestId: normalizeDeliveryId(target.id),
            office: target.office,
            item: target.item,
            eta: target.eta,
            status: target.status,
            updatedAt: new Date().toISOString()
        });
        renderScanModal();
        renderMyPickups();
        showToast(`Package ${target.id} ready for confirmation.`);
    } else if (target && !scannedCode) {
        verifiedPackageId = '';
        showToast('Enter the secure delivery code printed by Supply.');
    } else {
        verifiedPackageId = '';
        document.getElementById('requestModal')?.classList.add('hidden');
        document.getElementById('requestModal')?.setAttribute('aria-hidden', 'true');
        showToast(target ? 'This package is already completed.' : 'Package QR code not recognized.');
    }

    input.value = '';
}

function setupLogin() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        showToast('Please use the main system login to access the delivery dashboard.');
    });
}

function ensureSession() {
    const isPhpPage = window.location.pathname.toLowerCase().endsWith('deli.php');
    if (!isPhpPage) {
        return;
    }
}

function handleLogout() {
    window.location.href = '../../Login/logout.php';
}

function applyDeliveryAvatar(url) {
    const elements = [
        document.getElementById('deliveryHeaderAvatar'),
        document.getElementById('deliveryMenuAvatar')
    ];
    elements.forEach((element) => {
        if (!element) return;
        element.style.backgroundImage = url ? `url(${url})` : '';
        element.style.backgroundSize = 'cover';
        element.style.backgroundPosition = 'center';
        const icon = element.querySelector('svg');
        if (icon) icon.style.display = url ? 'none' : 'block';
    });
}

function loadDeliveryAvatar() {
    const username = window.deliveryUsername || '';
    if (username) applyDeliveryAvatar(localStorage.getItem(`avatar_${username}`) || '');
}

function closeDeliveryProfileMenu() {
    const menu = document.getElementById('deliveryProfileMenu');
    const button = document.getElementById('deliveryProfileBtn');
    if (!menu) return;
    menu.classList.remove('open');
    menu.setAttribute('aria-hidden', 'true');
    button?.setAttribute('aria-expanded', 'false');
}

function toggleDeliveryProfileMenu() {
    const menu = document.getElementById('deliveryProfileMenu');
    const button = document.getElementById('deliveryProfileBtn');
    if (!menu) return;
    const open = !menu.classList.contains('open');
    menu.classList.toggle('open', open);
    menu.setAttribute('aria-hidden', String(!open));
    button?.setAttribute('aria-expanded', String(open));
}

async function startCameraScanner() {
    const status = document.getElementById('scannerStatus');
    const video = document.getElementById('cameraPreview');

    if (!video || !navigator.mediaDevices?.getUserMedia) {
        if (status) status.textContent = 'Camera access is not available on this browser.';
        return;
    }

    if (activeCameraStream) {
        return;
    }

    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' }
        });

        activeCameraStream = stream;
        video.srcObject = stream;
        video.style.display = 'block';
        if (status) status.textContent = 'Camera is active. Aim at the QR code.';

        if ('BarcodeDetector' in window) {
            const detector = new window.BarcodeDetector({ formats: ['qr_code', 'code_128', 'ean_13'] });
            const loop = async () => {
                try {
                    const barcodes = await detector.detect(video);
                    if (barcodes.length) {
                        const decoded = barcodes[0].rawValue;
                        if (decoded) {
                            const input = document.getElementById('barcodeInput');
                            const packageId = parsePackageCode(decoded);
                            if (input) input.value = decoded;
                            if (status) status.textContent = `QR code detected: ${packageId || decoded}`;
                        }
                    }
                } catch (error) {
                    console.warn('Barcode detection warning:', error);
                }
                requestAnimationFrame(loop);
            };
            loop();
        }
    } catch (error) {
        if (status) status.textContent = 'Camera permission denied. You can still type the package code manually.';
    }
}

function bindEvents() {
    document.getElementById('scanBtn')?.addEventListener('click', scanPackage);
    document.getElementById('clearBtn')?.addEventListener('click', () => {
        const input = document.getElementById('barcodeInput');
        if (input) input.value = '';
    });
    document.getElementById('closeModalBtn')?.addEventListener('click', () => {
        const modal = document.getElementById('requestModal');
        modal?.classList.add('hidden');
        modal?.setAttribute('aria-hidden', 'true');
    });
    document.getElementById('closeSummaryModalBtn')?.addEventListener('click', () => {
        const modal = document.getElementById('summaryModal');
        modal?.classList.add('hidden');
        modal?.setAttribute('aria-hidden', 'true');
    });
    document.getElementById('summaryBackBtn')?.addEventListener('click', () => {
        const modal = document.getElementById('summaryModal');
        modal?.classList.add('hidden');
        modal?.setAttribute('aria-hidden', 'true');
        document.querySelector('[data-screen="pickups"]')?.click();
    });

    document.getElementById('refreshQueueBtn')?.addEventListener('click', async () => {
        await fetchDeliveryQueue();
        renderQueue();
        renderTimeline();
        renderSummaryCard();
        renderDispatchDetailCard();
        renderMyPickups();
        renderPickupHistory();
        showToast('Queue refreshed.');
    });

    document.getElementById('logoutBtn')?.addEventListener('click', handleLogout);
    document.getElementById('deliveryProfileBtn')?.addEventListener('click', (event) => {
        event.stopPropagation();
        toggleDeliveryProfileMenu();
    });
    document.getElementById('deliveryProfileAccount')?.addEventListener('click', () => {
        closeDeliveryProfileMenu();
        showToast(`Signed in as ${window.deliveryName || 'Delivery'}.`);
    });
    document.addEventListener('click', (event) => {
        const menu = document.getElementById('deliveryProfileMenu');
        const button = document.getElementById('deliveryProfileBtn');
        if (menu?.classList.contains('open') && !menu.contains(event.target) && !button?.contains(event.target)) {
            closeDeliveryProfileMenu();
        }
    });
    document.getElementById('backToPickupsBtn')?.addEventListener('click', () => {
        document.querySelectorAll('.page-screen').forEach(page => page.classList.remove('active'));
        document.getElementById('pickups-screen')?.classList.add('active');
        document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
        document.querySelector('[data-screen="pickups"]')?.classList.add('active');
    });

    document.querySelectorAll('.package-item').forEach((item) => {
        item.addEventListener('click', () => {
            const packageId = item.dataset.packageId;
            safeWrite(selectedPackageKey, packageId);
            renderQueue();
            renderSummaryCard();
            renderDispatchDetailCard();
            renderMyPickups();
            showToast(`Selected ${packageId}.`);
        });
    });

    document.getElementById('pickupList')?.addEventListener('click', async (event) => {
        const scanButton = event.target.closest('[data-scan-package]');
        const summaryButton = event.target.closest('[data-summary-id]');
        const finishButton = event.target.closest('[data-finish-id]');

        if (scanButton) {
            openScannerForPackage(scanButton.dataset.scanPackage);
            return;
        }

        if (summaryButton) {
            openSummaryModal(summaryButton.dataset.summaryId);
            return;
        }

        if (finishButton) {
            await updateStatus(finishButton.dataset.finishId, 'completed');
        }
    });

    document.getElementById('pickupHistoryList')?.addEventListener('click', (event) => {
        const summaryButton = event.target.closest('[data-summary-id]');
        if (summaryButton) openSummaryModal(summaryButton.dataset.summaryId);
    });

    document.querySelectorAll('.nav-tab').forEach((button) => {
        button.addEventListener('click', () => {
            const screen = button.dataset.screen;
            document.querySelectorAll('.page-screen').forEach((page) => page.classList.remove('active'));
            document.querySelectorAll('.nav-tab').forEach((tab) => tab.classList.remove('active'));
            document.getElementById(`${screen}-screen`)?.classList.add('active');
            button.classList.add('active');
        });
    });

    window.addEventListener('storage', async (event) => {
        if (event.key === deliveryQueueKey || event.key === recordKey) {
            renderQueue();
            renderTimeline();
            renderSummaryCard();
            renderDispatchDetailCard();
            renderMyPickups();
            renderPickupHistory();
        }

        if (event.key === 'dole_notification_v1') {
            try {
                const payload = event.newValue ? JSON.parse(event.newValue) : null;
                if (payload?.type === 'delivery_status' || payload?.type === 'request_status') {
                    await fetchDeliveryQueue();
                    await fetchDeliveryHistory();
                    renderQueue();
                    renderTimeline();
                    renderSummaryCard();
                    renderDispatchDetailCard();
                    renderMyPickups();
                    renderPickupHistory();
                }
            } catch (error) {
                console.warn('Invalid notification payload.', error);
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    ensureSession();
    setupLogin();
    updateProvinceBadge();
    await fetchDeliveryQueue();
    await fetchDeliveryHistory();
    renderQueue();
    renderTimeline();
    renderSummaryCard();
    renderDispatchDetailCard();
    renderMyPickups();
    renderPickupHistory();
    renderScanModal();
    bindEvents();
    loadDeliveryAvatar();

});
