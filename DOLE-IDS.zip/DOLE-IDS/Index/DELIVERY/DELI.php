<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Delivery') !== 0) {
    if (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Admin') === 0) {
        header('Location: ../ADMIN/Admin.php');
    } elseif (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Approver') === 0) {
        header('Location: ../SUPPLY/Central.php');
    } elseif (!empty($_SESSION['role']) && strcasecmp($_SESSION['role'], 'Requester') === 0) {
        header('Location: ../REQUESTOR/REQ.php');
    } else {
        header('Location: ../../Login/login.php');
    }
    exit;
}

$deliveryName = trim((string)($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Delivery'));
$deliveryUsername = trim((string)($_SESSION['username'] ?? ''));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>DOLE Delivery</title>
    <link rel="stylesheet" href="DELI.css">
</head>
<body class="delivery-body">
    <div class="phone-app-shell" id="deliveryApp">
        <header class="topbar mobile-topbar">
            <div class="brand-wrap">
                <span class="brand-logo-frame"><img src="../../Images/LOGO.png" alt="DOLE Logo" class="brand-logo"></span>
                <div>
                    <p class="eyebrow">Department of Labor</p>
                    <h1>Dispatcher</h1>
                </div>
            </div>
            <div class="header-side-stack">
                <div class="province-badge province-badge-light" id="deliveryProvinceBadge">Province: —</div>
                <div class="delivery-profile-wrap">
                    <button class="delivery-profile-btn" id="deliveryProfileBtn" type="button" aria-label="Profile" aria-controls="deliveryProfileMenu" aria-expanded="false">
                        <span class="delivery-profile-avatar" id="deliveryHeaderAvatar" aria-hidden="true">
                            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        </span>
                    </button>
                    <div class="delivery-profile-menu" id="deliveryProfileMenu" aria-hidden="true">
                        <button type="button" class="delivery-profile-account" id="deliveryProfileAccount">
                            <span class="delivery-menu-avatar" id="deliveryMenuAvatar" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 18.5c1.6-2.5 4-3.8 7-3.8s5.4 1.3 7 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                            </span>
                            <span><?php echo htmlspecialchars($deliveryName, ENT_QUOTES, 'UTF-8'); ?></span>
                        </button>
                        <button type="button" class="delivery-profile-logout" id="logoutBtn">
                            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 5H6.5A1.5 1.5 0 0 0 5 6.5v11A1.5 1.5 0 0 0 6.5 19H10M14 8l4 4-4 4M9 12h9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <span>Log out</span>
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <main class="phone-app">
            <nav class="phone-nav">
                <button class="nav-tab active" data-screen="pickups">My Pickups</button>
                <button class="nav-tab" data-screen="history">History</button>
            </nav>

            <section class="page-screen" id="scanner-screen">
                <div class="section-title-row">
                    <h3>Scan Package QR</h3>
                    <button type="button" class="ghost-btn small-btn" id="backToPickupsBtn">Back</button>
                </div>
                <div class="scan-card">
                    <div class="scan-surface">
                        <video id="cameraPreview" playsinline muted autoplay></video>
                        <div class="scan-line"></div>
                    </div>
                    <label class="field-label" for="barcodeInput">Secure delivery code</label>
                    <input id="barcodeInput" type="text" placeholder="Scan QR or enter DLV-...">
                    <p class="scanner-status">Use the QR printed on the Supply label, or enter the secure DLV-... code printed below it.</p>
                    <div class="scan-actions">
                        <button id="scanBtn" class="primary-btn">Scan Package</button>
                        <button id="clearBtn" class="ghost-btn">Clear</button>
                    </div>
                    <p id="scannerStatus" class="scanner-status">Camera is waiting for permission.</p>
                </div>
                <div class="scanner-modal hidden" id="requestModal" aria-hidden="true">
                    <div class="scanner-modal-card">
                        <div class="modal-title-row">
                            <div><p class="muted">Package Details</p><h3 id="modalTitle">Package details</h3></div>
                            <button class="ghost-btn small-btn" id="closeModalBtn">Close</button>
                        </div>
                        <div class="modal-detail-list">
                            <div class="modal-detail-item"><span>Tracking ID</span><strong id="modalId">—</strong></div>
                            <div class="modal-detail-item"><span>Office</span><strong id="modalOffice">—</strong></div>
                            <div class="modal-detail-item"><span>Item</span><strong id="modalItem">—</strong></div>
                            <div class="modal-detail-item"><span>ETA</span><strong id="modalEta">—</strong></div>
                        </div>
                        <div class="modal-actions" id="modalActions"></div>
                    </div>
                </div>
            </section>

            <section class="page-screen active" id="pickups-screen">
                <div class="section-title-row">
                    <h3>My pickups</h3>
                </div>
                <div class="pickup-list" id="pickupList"></div>
            </section>

            <section class="page-screen" id="history-screen">
                <div class="section-title-row">
                    <h3>Pickup History</h3>
                </div>
                <div class="pickup-list" id="pickupHistoryList"></div>
            </section>

            <div class="scanner-modal hidden" id="summaryModal" aria-hidden="true">
                    <div class="scanner-modal-card">
                        <div class="modal-title-row">
                            <div>
                                <p class="muted">Package Summary</p>
                                <h3 id="summaryModalTitle">Package Summary</h3>
                            </div>
                            <button class="ghost-btn small-btn" id="closeSummaryModalBtn">Close</button>
                        </div>

                        <div class="modal-detail-list">
                            <div class="modal-detail-item"><span>Tracking ID</span><strong id="summaryModalId">—</strong></div>
                            <div class="modal-detail-item"><span>Office</span><strong id="summaryModalOffice">—</strong></div>
                            <div class="modal-detail-item"><span>Item</span><strong id="summaryModalItem">—</strong></div>
                            <div class="modal-detail-item"><span>ETA</span><strong id="summaryModalEta">—</strong></div>
                        </div>

                        <div class="modal-actions">
                            <button id="summaryBackBtn" class="ghost-btn full-width">Back to My Pickups</button>
                        </div>
                    </div>
            </div>

        </main>
    </div>

    <div class="toast" id="toast" aria-live="polite"></div>

    <script>
        window.deliveryProvince = <?php echo json_encode(trim((string)($_SESSION['province'] ?? ''))); ?>;
        window.deliveryUsername = <?php echo json_encode($deliveryUsername); ?>;
        window.deliveryName = <?php echo json_encode($deliveryName); ?>;
    </script>
    <script src="DELI.js?v=20260911-qr-code-preserve-v2"></script>
</body>
</html>
