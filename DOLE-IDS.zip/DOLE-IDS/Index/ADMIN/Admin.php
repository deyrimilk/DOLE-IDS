<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    header('Location: ../../Login/login.php');
    exit;
}

if (empty($_SESSION['role']) || strcasecmp($_SESSION['role'], 'Admin') !== 0) {
    header('Location: ../../Index/SUPPLY/Central.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOLE Inventory System</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Admin.css">
    <link rel="stylesheet" href="Admin.figma.css?v=20260906-profile-edit">
</head>
<body>

<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <img src="assets/figma/logo-dole.png" alt="DOLE Logo" onerror="this.src='../../Images/LOGO.png'">
            <div class="logo-text">Department of Labor and Employment</div>
        </div>
        <ul class="nav">
            <li class="active" data-page="dashboard"><span class="nav-icon"></span> Dashboard</li>
            <li data-page="usermanagement"><span class="nav-icon"></span> User Management</li>
            <li data-page="inventory"><span class="nav-icon"></span> Inventory</li>
            <li data-page="approvals"><span class="nav-icon"></span> Requests Management</li>
            <li data-page="reports"><span class="nav-icon"></span> Reports</li>
        </ul>
        <div class="nav-bottom">
            <li data-page="settings"><span class="nav-icon"></span> Account Settings</li>
            <li data-page="system"><span class="nav-icon"></span> System Settings</li>
            <li data-page="logout"><span class="nav-icon"></span> Log out</li>
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <div class="topbar-left">
                <h2 id="page-title">Dashboard</h2>
                <p class="subtitle" id="page-subtitle">Explore your needs here</p>
            </div>
            <div class="topbar-right">
                <div class="search-bar" id="globalSearchBar">
                    <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                    <input type="text" id="globalSearchInput" placeholder="Search anything...">
                </div>
                <button class="notification-btn" id="notificationBtn" type="button" aria-label="Notifications">
                    <img src="assets/figma/icon-notif.svg" alt="" width="27" height="27">
                </button>
                <button class="profile" id="profileBtn" type="button" title="<?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?>">
                    <div class="avatar"></div>
                </button>
            </div>
        </header>

        <!-- Notifications Panel -->
        <div class="notifications-panel" id="notificationsPanel">
            <div class="notifications-header">
                <h3>Notifications</h3>
                <div class="notifications-header-actions">
                    <button class="mark-all-read" id="markAllReadBtn" type="button" title="Mark all as read">✓✓</button>
                    <button class="close-notifications" id="closeNotifications" type="button">✕</button>
                </div>
            </div>
            <div class="notifications-tabs">
                <div class="notif-tab active" data-filter="all">All <span class="notif-count" id="notifCountAll">0</span></div>
                <div class="notif-tab" data-filter="request">Requests <span class="notif-count" id="notifCountRequest">0</span></div>
                <div class="notif-tab" data-filter="inventory">Inventory <span class="notif-count" id="notifCountInventory">0</span></div>
                <div class="notif-tab" data-filter="unread">Unread <span class="notif-count" id="notifCountUnread">0</span></div>
            </div>
            <div class="notifications-content">
                <div class="notif-section">
                    <h4 class="notif-section-title">Today</h4>
                    <div id="todayNotifications" class="notif-list"></div>
                </div>
                <div class="notif-section">
                    <h4 class="notif-section-title">Yesterday</h4>
                    <div id="olderNotifications" class="notif-list"></div>
                </div>
            </div>
            <button class="view-all-notif" type="button">View all</button>
        </div>

        <div class="notification-overlay" id="notificationOverlay"></div>

        <section id="dashboard" class="page active">
            <div class="stats">
                <div class="stat-card" data-filter="all" data-goto="inventory">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-stat-inv.png" alt="" width="24" height="22">
                        <span>TOTAL INVENTORY</span>
                    </div>
                    <h1 id="totalInventoryCount">14</h1>
                    <img class="stat-arrow" src="assets/figma/icon-arrow.svg" alt="" width="11" height="12">
                </div>
                <div class="stat-card" data-filter="low" data-goto="inventory">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-stat-low.svg" alt="" width="16" height="12">
                        <span>LOW STOCK</span>
                    </div>
                    <h1 id="lowStockCount">5</h1>
                    <img class="stat-arrow" src="assets/figma/icon-arrow.svg" alt="" width="11" height="12">
                </div>
                <div class="stat-card" data-filter="out" data-goto="inventory">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-stat-out.png" alt="" width="14" height="15">
                        <span>OUT OF STOCK</span>
                    </div>
                    <h1 id="outStockCount">14</h1>
                    <img class="stat-arrow" src="assets/figma/icon-arrow.svg" alt="" width="11" height="12">
                </div>
                <div class="stat-card" data-filter="pending" data-goto="approvals">
                    <div class="stat-header">
                        <img class="stat-icon" src="assets/figma/icon-request.png" alt="" width="15" height="15">
                        <span>PENDING REQUESTS</span>
                    </div>
                    <h1 id="pendingRequestCount">0</h1>
                    <img class="stat-arrow" src="assets/figma/icon-arrow.svg" alt="" width="11" height="12">
                </div>
            </div>

            <div class="dashboard-main">
                <div class="dashboard-left">
                    <div class="dashboard-section recent-requests-card">
                        <h3 class="section-title">Recent Requests</h3>
                        <table class="dashboard-table">
                            <thead>
                                <tr>
                                    <th>RIS Number</th>
                                    <th>Office/ Branch</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody id="recentRequestsTable"></tbody>
                        </table>
                    </div>

                    <div class="dashboard-section recent-acts-card">
                        <h3 class="section-title">Recent Activities</h3>
                        <div id="recentActivitiesList" class="activities-list"></div>
                    </div>

                    <div class="dashboard-section activity-summary-card">
                        <h3 class="section-title">Activity Summary (Today)</h3>
                        <div class="activity-summary">
                            <div class="summary-row">
                                <span class="summary-label">Request</span>
                                <span class="summary-value" id="activityRequest">1</span>
                            </div>
                            <div class="summary-row">
                                <span class="summary-label">Approved</span>
                                <span class="summary-value" id="activityApproved">2</span>
                            </div>
                            <div class="summary-row">
                                <span class="summary-label">Declined</span>
                                <span class="summary-value" id="activityDeclined">1</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-right">
                    <div class="dashboard-section popular-items-card">
                        <h3 class="section-title">Popular Requested Items</h3>
                        <ul id="popularItemsList" class="popular-items-list"></ul>
                        <button class="view-all-btn" type="button" data-goto="inventory">View all</button>
                    </div>

                    <div class="dashboard-section ppmp-status-card">
                        <h3 class="section-title">PPMP Status</h3>
                        <div class="activity-summary">
                            <div class="summary-row">
                                <span class="summary-label">Pending</span>
                                <span class="summary-value" id="ppmpPendingCount">0</span>
                            </div>
                            <div class="summary-row">
                                <span class="summary-label">Approved</span>
                                <span class="summary-value" id="ppmpApprovedCount">0</span>
                            </div>
                            <div class="summary-row">
                                <span class="summary-label">Declined</span>
                                <span class="summary-value" id="ppmpDeclinedCount">0</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section id="inventory" class="page">
            <div class="inventory-header">
                <div class="inventory-title-section">
                    <h3 class="inventory-title">All Items <span id="totalItemCount">14</span></h3>
                </div>
                <div class="inventory-actions">
                    <div class="search-wrapper">
                        <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                        <input id="searchInput" placeholder="Search by Item name, code, or category...">
                    </div>
                    <button id="inventorySortDirBtn" type="button" class="circle-icon-btn" title="Sort direction" aria-label="Sort direction">↓</button>
                    <button id="inventorySortFieldBtn" type="button" class="circle-icon-btn" title="Sort field" aria-label="Sort field">ITEM NO.</button>
                    <div class="inventory-category-select-wrapper">
                        <select id="inventoryCategorySelect" aria-label="Filter by category">
                            <option value="all">All Categories</option>
                        </select>
                    </div>
                    <button id="addItemBtn" class="blue-btn">+ Add Item</button>
                </div>
            </div>
            <div class="inventory-table-container">
                <table class="inventory-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Category</th>
                            <th>In Stock</th>
                            <th>Status</th>
                            <th>Last Modified</th>
                        </tr>
                    </thead>
                    <tbody id="inventoryTable"></tbody>
                </table>
            </div>
        </section>

        <section id="approvals" class="page">
            <div class="request-management-header">
                <div class="request-type-tabs" aria-label="Request type">
                    <button type="button" class="request-type-tab active" data-request-type="all">All Requests</button>
                    <button type="button" class="request-type-tab" data-request-type="Item Request">Item Requests</button>
                    <button type="button" class="request-type-tab" data-request-type="PPMP Request">PPMP Requests</button>
                </div>
                <div class="request-tabs">
                    <div class="request-tab active" data-filter="all">All <span id="req-count-all">13</span></div>
                    <div class="request-tab" data-filter="today">Today <span id="req-count-today">0</span></div>
                    <div class="request-tab" data-filter="pending">Pending <span id="req-count-pending">15</span></div>
                    <div class="request-tab" data-filter="approved">Approved <span id="req-count-approved">03</span></div>
                    <div class="request-tab" data-filter="declined">Declined <span id="req-count-declined">02</span></div>
                </div>
                <div class="request-actions">
                    <div class="search-wrapper request-search">
                        <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                        <input id="requestSearchInput" placeholder="Search by RIS, Item...">
                    </div>
                    <button id="requestSortBtn" type="button" class="circle-icon-btn" title="Sort" aria-label="Sort">⇅</button>
                    <button id="requestSortFieldBtn" type="button" class="circle-icon-btn" title="Sort Field" aria-label="Sort Field">RIS</button>
                    <button id="openAdminRequestHistoryBtn" type="button" class="circle-icon-btn history-btn" title="Request history" aria-label="Request history">▣</button>
                </div>
            </div>
            <div class="request-table-container">
                <table class="request-table">
                    <thead>
                        <tr>
                            <th>RIS Number</th>
                            <th>Type</th>
                            <th>Item</th>
                            <th>Total Quantity</th>
                            <th>Office/ Branch</th>
                            <th>Stock status</th>
                            <th>Request status</th>
                            <th>Date Requested</th>
                            <th style="width: 50px;"></th>
                        </tr>
                    </thead>
                    <tbody id="requestTable"></tbody>
                </table>
            </div>
        </section>

        <section id="requestHistory" class="page">
            <div class="request-history-toolbar">
                <button type="button" id="adminHistoryBackBtn" class="admin-history-back-btn" aria-label="Back to request management">‹ Back</button>
                <div class="request-history-actions">
                    <label>From <input type="date" id="adminHistoryStartDate"></label>
                    <label>To <input type="date" id="adminHistoryEndDate"></label>
                    <button type="button" id="clearAdminHistoryDates">Clear</button>
                </div>
            </div>
            <div class="request-history-summary" id="adminHistorySummary"></div>
            <div class="request-table-container">
                <table class="request-table">
                    <thead>
                        <tr>
                            <th>RIS Number</th><th>Type</th><th>Item</th><th>Total Quantity</th>
                            <th>Office/ Branch</th><th>Stock status</th><th>Request status</th>
                            <th>Date Requested</th><th style="width: 50px;"></th>
                        </tr>
                    </thead>
                    <tbody id="adminHistoryTable"></tbody>
                </table>
            </div>
        </section>

        <section id="reports" class="page">
            <div class="reports-panel">
                <div class="reports-content">
                    <div class="reports-overview-grid">
                <div class="report-metric-card">
                    <span class="report-metric-label">Total Requests</span>
                    <span class="report-metric-value" id="reportTotalRequests">0</span>
                    <span class="report-metric-subtitle" id="reportTotalRequestsSubtitle">Logged this month</span>
                </div>
                <div class="report-metric-card">
                    <span class="report-metric-label">Approval Rate</span>
                    <span class="report-metric-value" id="reportApprovalRate">0%</span>
                    <span class="report-metric-subtitle">Current status of requests created in range</span>
                </div>
                <div class="report-metric-card">
                    <span class="report-metric-label">Stock Health</span>
                    <span class="report-metric-value" id="reportStockHealth">0%</span>
                    <span class="report-metric-subtitle">Current inventory snapshot</span>
                </div>
                <div class="report-metric-card">
                    <span class="report-metric-label">Pending Requests</span>
                    <span class="report-metric-value" id="reportPendingRequests">0</span>
                    <span class="report-metric-subtitle" id="reportPendingRequestsSubtitle">Awaiting approval this month</span>
                </div>
            </div>

            <div class="reports-main-grid">
                <div class="report-chart-card">
                    <div class="report-chart-header">
                        <div>
                            <h4>Request & Inventory Overview</h4>
                            <p>Live trend data from your inventory and request workflow.</p>
                        </div>
                        <div class="report-range-switch">
                            <button class="range-btn active" data-range="month">Monthly</button>
                            <button class="range-btn" data-range="quarter">Quarterly</button>
                            <button class="range-btn" data-range="year">Yearly</button>
                        </div>
                    </div>

                    <div class="report-chart">
                        <div class="chart-section">
                            <div class="chart-title">Request Status</div>
                            <div class="chart-row">
                                <span>Approved</span>
                                <div class="chart-bar-bg"><div id="chartApprovedBar" class="chart-bar chart-approved"></div></div>
                                <span id="chartApprovedValue">0%</span>
                            </div>
                            <div class="chart-row">
                                <span>Pending</span>
                                <div class="chart-bar-bg"><div id="chartPendingBar" class="chart-bar chart-pending"></div></div>
                                <span id="chartPendingValue">0%</span>
                            </div>
                            <div class="chart-row">
                                <span>Declined</span>
                                <div class="chart-bar-bg"><div id="chartDeclinedBar" class="chart-bar chart-declined"></div></div>
                                <span id="chartDeclinedValue">0%</span>
                            </div>
                        </div>
                        <div class="chart-section">
                            <div class="chart-title">Inventory Status</div>
                            <div class="chart-row">
                                <span>In Stock</span>
                                <div class="chart-bar-bg"><div id="chartInStockBar" class="chart-bar chart-instock"></div></div>
                                <span id="chartInStockValue">0%</span>
                            </div>
                            <div class="chart-row">
                                <span>Low Stock</span>
                                <div class="chart-bar-bg"><div id="chartLowStockBar" class="chart-bar chart-lowstock"></div></div>
                                <span id="chartLowStockValue">0%</span>
                            </div>
                            <div class="chart-row">
                                <span>Out of Stock</span>
                                <div class="chart-bar-bg"><div id="chartOutStockBar" class="chart-bar chart-outstock"></div></div>
                                <span id="chartOutStockValue">0%</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="report-details-card">
                    <div class="report-card report-highlights-card">
                        <h4>Highlights</h4>
                        <ul class="report-list" id="reportList"></ul>
                    </div>
                </div>
            </div>
            <div class="report-activity-panel">
                <div class="report-activity-header">
                    <div>
                        <h4>Process Activity</h4>
                        <p>Recorded actions for the selected reporting period.</p>
                    </div>
                    <span id="reportActivityTotal">0 events</span>
                </div>
                <div class="report-activity-table-wrap">
                    <table class="report-activity-table">
                        <thead>
                            <tr>
                                <th>Date and time</th>
                                <th>Process</th>
                                <th>Province</th>
                                <th>Performed by</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody id="reportActivityTable">
                            <tr><td colspan="5">Loading activity...</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="report-activity-pagination">
                    <span id="reportActivityPageLabel">Page 1</span>
                    <div>
                        <button type="button" id="reportActivityPrevious" disabled>Previous</button>
                        <button type="button" id="reportActivityNext" disabled>Next</button>
                    </div>
                </div>
                <p class="report-activity-retention">Activity history begins when activity logging was enabled; earlier actions cannot be reconstructed reliably.</p>
            </div>
                <div class="reports-bottom-actions">
                    <div class="report-download-wrapper">
                        <button id="reportDownloadBtn" class="report-action-btn report-action-download" type="button">
                            <span class="report-action-icon">⬇️</span>
                            <span>Download</span>
                            <span class="report-download-caret">▾</span>
                        </button>
                        <div id="reportDownloadMenu" class="report-download-menu hidden">
                            <button type="button" class="report-download-item" data-export-type="xlsx">Download Excel Workbook</button>
                            <button type="button" class="report-download-item" data-export-type="pdf">Export PDF</button>
                        </div>
                    </div>
                </div>
        </section>

        <section id="usermanagement" class="page">
            <div class="user-management-header">
                <div class="user-title-section">
                    <h3 class="user-title">All users <span id="totalUserCount">0</span></h3>
                </div>
                <div class="user-actions">
                    <div class="search-wrapper">
                        <img class="search-icon-img" src="assets/figma/icon-search.svg" alt="" width="12" height="12">
                        <input id="userSearchInput" placeholder="Search">
                    </div>
                    <button id="addUserBtn" class="add-user-btn">+ Add User</button>
                </div>
            </div>
            <div class="user-table-container">
                <table class="user-table">
                    <thead>
                        <tr>
                            <th data-sort="name" class="sortable">User <span class="sort-indicator"></span></th>
                            <th data-sort="role" class="sortable">Role <span class="sort-indicator"></span></th>
                            <th>Status</th>
                            <th data-sort="province" class="sortable">Province <span class="sort-indicator"></span></th>
                            <th data-sort="lastActive" class="sortable">Last active <span class="sort-indicator"></span></th>
                            <th data-sort="dateAdded" class="sortable">Date added <span class="sort-indicator"></span></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="userTable"></tbody>
                </table>
            </div>
        </section>

        <section id="settings" class="page">
            <div class="account-settings">
                <div class="settings-profile-card">
                    <button type="button" class="settings-edit-btn" id="settingsEditBtn" title="Edit profile" aria-label="Edit profile">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9a2.1 2.1 0 0 0-4-4L4 16v4Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="m13.5 6.5 4 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        <span>Edit Profile</span>
                    </button>
                    <div class="settings-profile-main">
                        <div class="settings-avatar" id="settingsAvatar"></div>
                        <div class="settings-profile-info">
                            <h3 id="settingsDisplayName"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></h3>
                            <p class="settings-role" id="settingsRole"><?php echo htmlspecialchars($_SESSION['role'] ?? 'Admin'); ?></p>
                            <p class="settings-bureau" id="settingsBureau">Bureau of Working Conditions</p>
                            <p class="settings-org">Department of Labor and Employment</p>
                            <span class="settings-active-badge">Active</span>
                        </div>
                    </div>
                    <div class="settings-profile-contact">
                        <div class="settings-contact-row">
                            <span class="settings-contact-icon" aria-hidden="true">
                                <svg width="12" height="10" viewBox="0 0 12 10" fill="none"><path d="M1 2.2 5.2 5.1c.5.35 1.1.35 1.6 0L11 2.2M1.5 9h9A1.5 1.5 0 0 0 12 7.5v-5A1.5 1.5 0 0 0 10.5 1h-9A1.5 1.5 0 0 0 0 2.5v5A1.5 1.5 0 0 0 1.5 9Z" stroke="#5E5E5E" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <span id="settingsEmail"><?php echo htmlspecialchars($_SESSION['email'] ?? '—'); ?></span>
                        </div>
                        <div class="settings-contact-row">
                            <span class="settings-contact-icon" aria-hidden="true">
                                <svg width="11" height="11" viewBox="0 0 11 11" fill="none"><path d="M9.7 7.4v1.2a1 1 0 0 1-1.1 1A9.6 9.6 0 0 1 1.4 2.4a1 1 0 0 1 1-1.1h1.2a1 1 0 0 1 1 .8c.1.6.2 1.1.4 1.6a1 1 0 0 1-.2 1L4.3 5.2a7.7 7.7 0 0 0 1.5 1.5l.5-.5a1 1 0 0 1 1-.2c.5.2 1 .3 1.6.4a1 1 0 0 1 .8 1Z" stroke="#5E5E5E" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <span id="settingsPhone">+63 9123456789</span>
                        </div>
                        <div class="settings-contact-row">
                            <span class="settings-contact-icon" aria-hidden="true">
                                <svg width="10" height="12" viewBox="0 0 10 12" fill="none"><path d="M5 6.2a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2Z" stroke="#5E5E5E"/><path d="M5 1C2.8 1 1 2.7 1 4.8 1 7.5 5 11 5 11s4-3.5 4-6.2C9 2.7 7.2 1 5 1Z" stroke="#5E5E5E" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </span>
                            <span id="settingsAddress">Calamba City, Laguna, Parian</span>
                        </div>
                    </div>
                </div>

                <div class="settings-lower">
                    <div class="settings-lower-left">
                        <div class="settings-info-card">
                            <h4>Personal Information</h4>
                            <div class="settings-info-grid settings-info-grid-5">
                                <div class="settings-field">
                                    <span class="settings-label">Full Name</span>
                                    <strong id="settingsFullName">Flavio Maneclang Deza III</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Date of Birth</span>
                                    <strong id="settingsDob">June 13, 2003</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Gender</span>
                                    <strong id="settingsGender">Male</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Civil Status</span>
                                    <strong id="settingsCivil">Single</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Nationality</span>
                                    <strong id="settingsNationality">Filipino</strong>
                                </div>
                            </div>
                        </div>

                        <div class="settings-info-card settings-work-card">
                            <h4>Work Information</h4>
                            <div class="settings-info-grid settings-info-grid-4">
                                <div class="settings-field">
                                    <span class="settings-label">Employee ID</span>
                                    <strong id="settingsEmployeeId">DOLE-2026-00013</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Position</span>
                                    <strong id="settingsPosition">Supply Officer</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Division/ Unit</span>
                                    <strong id="settingsDivision">Procurement and Supply Division</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Employment Status</span>
                                    <strong id="settingsEmployment">Permanent</strong>
                                </div>
                            </div>
                            <div class="settings-info-grid settings-info-grid-4 settings-work-row-2">
                                <div class="settings-field">
                                    <span class="settings-label">Step Increment</span>
                                    <strong id="settingsStep">3</strong>
                                </div>
                                <div class="settings-field">
                                    <span class="settings-label">Date Created</span>
                                    <strong id="settingsDateCreated">June 5, 2026</strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="settings-security-card">
                        <h4>Security Settings</h4>
                        <div class="settings-field">
                            <span class="settings-label">Username <span class="req">*</span></span>
                            <strong id="settingsUsername"><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></strong>
                        </div>
                        <button type="button" class="settings-password-btn" id="changePasswordBtn">Change Password</button>
                    </div>
                </div>
            </div>
        </section>

        <section id="system" class="page">
            <div class="system-settings">
                <div class="system-settings-card">
                    <h4>Inventory</h4>
                    <p class="system-settings-desc">Controls how stock levels are flagged in the dashboard and inventory list.</p>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysLowStockThreshold">Low stock threshold</label>
                            <span class="system-setting-hint">Items at or below this quantity are marked Low Stock</span>
                        </div>
                        <input type="number" id="sysLowStockThreshold" class="system-input" min="1" max="100" value="5">
                    </div>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysShowOutOfStock">Highlight out of stock items</label>
                            <span class="system-setting-hint">Show a stronger alert style for zero-stock items</span>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="sysShowOutOfStock" checked>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="system-settings-card">
                    <h4>Requests</h4>
                    <p class="system-settings-desc">Default behavior for request management.</p>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysDefaultRequestFilter">Default request tab</label>
                            <span class="system-setting-hint">Opened first when you visit Requests Management</span>
                        </div>
                        <select id="sysDefaultRequestFilter" class="system-select">
                            <option value="all">All</option>
                            <option value="pending">Pending</option>
                            <option value="today">Today</option>
                            <option value="approved">Approved</option>
                            <option value="declined">Declined</option>
                        </select>
                    </div>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysNotifyNewRequests">Notify on new requests</label>
                            <span class="system-setting-hint">Show notification badge for incoming requests</span>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="sysNotifyNewRequests" checked>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="system-settings-card">
                    <h4>Notifications &amp; Display</h4>
                    <p class="system-settings-desc">General system preferences for this admin account.</p>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysNotifyLowStock">Low stock alerts</label>
                            <span class="system-setting-hint">Receive alerts when inventory hits the threshold</span>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="sysNotifyLowStock" checked>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysAutoRefresh">Auto-refresh dashboard</label>
                            <span class="system-setting-hint">Refresh dashboard stats every few minutes</span>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="sysAutoRefresh">
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    <div class="system-setting-row">
                        <div>
                            <label for="sysSessionTimeout">Session timeout</label>
                            <span class="system-setting-hint">Idle time before requiring login again</span>
                        </div>
                        <select id="sysSessionTimeout" class="system-select">
                            <option value="30">30 minutes</option>
                            <option value="60" selected>1 hour</option>
                            <option value="120">2 hours</option>
                            <option value="480">8 hours</option>
                        </select>
                    </div>
                </div>

                <div class="system-settings-actions">
                    <button type="button" class="btn-cancel" id="resetSystemSettingsBtn">Reset defaults</button>
                    <button type="button" class="btn-save" id="saveSystemSettingsBtn">Save settings</button>
                </div>
            </div>
        </section>
    </main>
</div>

<div class="modal-overlay" id="addUserModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeAddUserModal">←</button>
            <h3>Create User Account</h3>
        </div>
        <div class="modal-body">
            <div class="form-row">
                <div class="form-group">
                    <label>Username <span class="req">*</span></label>
                    <input type="text" id="newUserUsername" placeholder="Username">
                </div>
                <div class="form-group">
                    <label>Password <span class="req">*</span></label>
                    <input type="password" id="newUserPassword" placeholder="Password">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Gmail <span class="req">*</span></label>
                    <input type="email" id="newUserEmail" placeholder="Gmail">
                </div>
                <div class="form-group">
                    <label>Fullname <span class="req">*</span></label>
                    <input type="text" id="newUserFullname" placeholder="Fullname">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Role <span class="req">*</span></label>
                    <div class="select-box">
                        <select id="newUserRole">
                            <option value="Admin">Admin</option>
                            <option value="Approver">Approver</option>
                            <option value="Requester">Requester</option>
                            <option value="Delivery">Delivery</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Province <span class="req">*</span></label>
                    <div class="select-box">
                        <select id="newUserProvince">
                            <option value="CAVITE">CAVITE</option>
                            <option value="LAGUNA">LAGUNA</option>
                            <option value="BATANGAS">BATANGAS</option>
                            <option value="RIZAL">RIZAL</option>
                            <option value="QUEZON">QUEZON</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelAddUserBtn">Cancel</button>
            <button class="btn-save" id="saveUserBtn">Create</button>
        </div>
    </div>
</div>

<!-- Edit Profile Modal -->
<div class="modal-overlay" id="editProfileModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeEditProfileModal">←</button>
            <h3>Edit Profile</h3>
        </div>
        <div class="modal-body">
            <div style="display:flex; gap:16px; align-items:center; margin-bottom:12px;">
                <div class="user-avatar" id="editAvatarPreview" style="width:72px; height:72px; border-radius:50%; background:#ddd; background-size:cover;"></div>
                <div>
                    <label class="form-group">Image (square)</label>
                    <input type="file" id="editAvatarInput" accept="image/*">
                </div>
            </div>

            <div class="form-group">
                <label>Display Name</label>
                <input type="text" id="editDisplayName" placeholder="Full name">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="editEmail" placeholder="Email">
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" id="editPhone" placeholder="Phone number">
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" id="editAddress" placeholder="Address">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="text" id="editDob" placeholder="June 13, 2003">
                </div>
                <div class="form-group">
                    <label>Gender</label>
                    <input type="text" id="editGender" placeholder="Male">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Civil Status</label>
                    <input type="text" id="editCivil" placeholder="Single">
                </div>
                <div class="form-group">
                    <label>Nationality</label>
                    <input type="text" id="editNationality" placeholder="Filipino">
                </div>
            </div>
            <div class="form-group">
                <label>Bureau / Unit</label>
                <input type="text" id="editBureau" placeholder="Bureau of Working Conditions">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Employee ID</label>
                    <input type="text" id="editEmployeeId" placeholder="Employee ID">
                </div>
                <div class="form-group">
                    <label>Position</label>
                    <input type="text" id="editPosition" placeholder="Position">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Employment Status</label>
                    <input type="text" id="editEmployment" placeholder="Permanent">
                </div>
                <div class="form-group">
                    <label>Plantilla Item No.</label>
                    <input type="text" id="editPlantillaItemNo" placeholder="Plantilla item number">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Salary Grade</label>
                    <input type="text" id="editSalaryGrade" placeholder="SG 15">
                </div>
                <div class="form-group">
                    <label>Step Increment</label>
                    <input type="text" id="editStep" placeholder="3">
                </div>
            </div>
            <div class="form-group">
                <label>Date Created</label>
                <input type="text" id="editDateCreated" placeholder="June 5, 2026">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelEditProfileBtn">Cancel</button>
            <button class="btn-save" id="saveProfileBtn">Update Information</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="changePasswordModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeChangePasswordModal">←</button>
            <h3>Change Password</h3>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Current Password <span class="req">*</span></label>
                <input type="password" id="currentPassword" placeholder="Current password">
            </div>
            <div class="form-group">
                <label>New Password <span class="req">*</span></label>
                <input type="password" id="newPassword" placeholder="New password">
            </div>
            <div class="form-group">
                <label>Confirm New Password <span class="req">*</span></label>
                <input type="password" id="confirmPassword" placeholder="Confirm new password">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelChangePasswordBtn">Cancel</button>
            <button class="btn-save" id="savePasswordBtn">Update Password</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="requestDetailsModal">
    <div class="modal request-modal">
        <div class="modal-header">
            <h3>Request Details</h3>
            <button class="modal-back" id="closeRequestDetails">✕</button>
        </div>
        <div class="modal-body request-details-body">
            <div id="detailRequestSteps" class="request-steps" style="margin-bottom:12px;">
                <div class="request-step" data-step="review">
                    <div class="request-step-circle">✓</div>
                    <div class="request-step-label">Review Request</div>
                </div>
                <div class="request-step" data-step="preparing">
                    <div class="request-step-circle">2</div>
                    <div class="request-step-label">Preparing Request</div>
                </div>
                <div class="request-step" data-step="shipping">
                    <div class="request-step-circle">3</div>
                    <div class="request-step-label">Shipping</div>
                </div>
                <div class="request-step" data-step="delivering">
                    <div class="request-step-circle">4</div>
                    <div class="request-step-label">Delivering</div>
                </div>
            </div>
            <div class="detail-row"><span>Request No:</span><strong id="detailReqNo">#001</strong></div>
            <div class="detail-row"><span>Status:</span><strong id="detailReqStatus">Pending</strong></div>
            <div class="detail-row"><span>Date:</span><strong id="detailReqDate">2026-04-10</strong></div>
            <div class="detail-row"><span>Requestor:</span><strong id="detailRequestor">Cavite</strong></div>
            <div class="detail-row"><span>Approver:</span><strong id="detailApprover">Flavio Deza IV</strong></div>
            <div class="detail-row"><span>Item:</span><strong id="detailItemName">Ballpoint Pen</strong></div>
            <div class="detail-row"><span>Quantity:</span><strong id="detailQty">8 pcs</strong></div>
            <div class="detail-row"><span>Remarks:</span><strong id="detailRemarks">Low Stock</strong></div>
            <div class="detail-row"><span>Note:</span><strong id="detailNote">Please process urgently.</strong></div>
        </div>
        <div class="modal-footer request-actions-footer">
            <button id="approveRequestBtn" class="blue-btn">✓ Approve</button>
            <button id="declineRequestBtn" class="red-btn">✕ Decline</button>
        </div>
    </div>
</div>

<!-- Add Items Modal -->
<div class="modal-overlay" id="addItemsModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeAddItemsModal">←</button>
            <h3>Add Items</h3>
        </div>
        <div class="modal-body">
            <div class="drop-zone" id="itemDropZone">
                <div class="drop-content">
                    <div class="upload-icon">📤</div>
                    <div>Upload Image</div>
                    <input type="file" id="itemImageInput" accept="image/*" style="display:none">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Item ID</label>
                    <input type="text" id="newItemId" class="readonly-input" readonly value="AUTO">
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <div class="select-box">
                        <select id="newItemCategory">
                            <option value="Paper Products">Paper Products</option>
                            <option value="Writing Supplies">Writing Supplies</option>
                            <option value="Office Supplies">Office Supplies</option>
                            <option value="Office Equipment">Office Equipment</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Item Name <span class="req">*</span></label>
                    <input type="text" id="newItemName" placeholder="Item Name">
                </div>
                <div class="form-group">
                    <label>Unit</label>
                    <div class="select-box">
                        <select id="newItemUnit">
                            <option value="pcs">pcs</option>
                            <option value="reams">reams</option>
                            <option value="box">box</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>In Stock</label>
                    <input type="number" id="newItemStock" value="0" min="0">
                </div>
                <div class="form-group">
                    <label>Minimum Stock</label>
                    <input type="number" id="newItemMinStock" value="1" min="0">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelAddItemBtn">Cancel</button>
            <button class="btn-save" id="saveItemBtn">Add Item</button>
        </div>
    </div>
</div>

<!-- Report Download Options Modal -->
<div class="modal-overlay" id="reportDownloadModal">
    <div class="modal">
        <div class="modal-header">
            <button class="modal-back" id="closeReportDownloadModal">←</button>
            <h3>Download Report Options</h3>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Date Range Option</label>
                <div class="select-box">
                    <select id="reportDownloadRange">
                        <option value="daily">Daily (Today)</option>
                        <option value="weekly">Weekly (Last 7 Days)</option>
                        <option value="monthly" selected>Monthly</option>
                        <option value="yearly">Annually</option>
                        <option value="custom">Custom Date Range</option>
                    </select>
                </div>
            </div>

            <div id="monthlyReportFields" class="form-row">
                <div class="form-group">
                    <label for="reportMonth">Month</label>
                    <select id="reportMonth">
                        <option value="0">January</option>
                        <option value="1">February</option>
                        <option value="2">March</option>
                        <option value="3">April</option>
                        <option value="4">May</option>
                        <option value="5">June</option>
                        <option value="6">July</option>
                        <option value="7">August</option>
                        <option value="8">September</option>
                        <option value="9">October</option>
                        <option value="10">November</option>
                        <option value="11">December</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="reportMonthYear">Year</label>
                    <input type="number" id="reportMonthYear" min="2000" max="2100" step="1">
                </div>
            </div>

            <div id="yearlyReportFields" class="form-group" style="display: none;">
                <label for="reportYear">Year</label>
                <input type="number" id="reportYear" min="2000" max="2100" step="1">
            </div>
            
            <div id="customDateRangeFields" style="display: none;">
                <div class="form-row">
                    <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" id="reportStartDate">
                    </div>
                    <div class="form-group">
                        <label>End Date</label>
                        <input type="date" id="reportEndDate">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="cancelReportDownloadBtn">Cancel</button>
            <button class="btn-save" id="confirmReportDownloadBtn">Generate & Download</button>
        </div>
    </div>
</div>

<div id="toastMessage" class="toast-message"></div>

<script>
    window.currentAdminUser = <?php echo json_encode($_SESSION['username'] ?? ''); ?>;
    window.currentAdminFullName = <?php echo json_encode($_SESSION['full_name'] ?? ($_SESSION['username'] ?? '')); ?>;
    window.currentAdminEmail = <?php echo json_encode($_SESSION['email'] ?? ''); ?>;
    window.currentAdminRole = <?php echo json_encode($_SESSION['role'] ?? ''); ?>;
    window.flashMessage = <?php echo json_encode($_SESSION['flash_message'] ?? ''); ?>;
    <?php if (!empty($_SESSION['flash_message'])) unset($_SESSION['flash_message']); ?>
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="Admin.js?v=20260906-live-notifications-v2"></script>

</body>
</html>
