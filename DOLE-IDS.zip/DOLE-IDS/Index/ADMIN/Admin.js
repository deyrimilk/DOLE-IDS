// --- SESSION & AUTHENTICATION ---
class SessionManager {
    constructor() {
        this.loadSession();
    }
    
    loadSession() {
        const session = localStorage.getItem('userSession');
        this.currentUser = session ? JSON.parse(session) : null;
        this.token = localStorage.getItem('authToken');
    }
    
    saveSession(user, token) {
        localStorage.setItem('userSession', JSON.stringify(user));
        localStorage.setItem('authToken', token);
        this.currentUser = user;
        this.token = token;
    }
    
    clearSession() {
        localStorage.removeItem('userSession');
        localStorage.removeItem('authToken');
        this.currentUser = null;
        this.token = null;
    }
    
    isAuthenticated() {
        return this.token && this.currentUser;
    }
}

const session = new SessionManager();

function deriveAppRoot() {
    return new URL('../../', window.location.href).pathname.replace(/\/$/, '');
}

const appRoot = deriveAppRoot();
const loginApiBase = `${window.location.origin}${appRoot}/Login`;
const loginPageUrl = `${window.location.origin}${appRoot}/Login/login.php`;
const logoutPageUrl = `${window.location.origin}${appRoot}/Login/logout.php`;
const inventoryApiBase = `${window.location.origin}${appRoot}/Inventory/inventory.php`;
const requestsApiBase = `${window.location.origin}${appRoot}/Requests/requests.php`;
const deliveryApiBase = `${window.location.origin}${appRoot}/Index/DELIVERY/delivery_api.php`;
const ppmpApiBase = `${window.location.origin}${appRoot}/ppmp/ppmp_api.php`;
const reportApiBase = `${window.location.origin}${appRoot}/Index/ADMIN/report_api.php`;

function getCsrfToken() {
    const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
    return match ? decodeURIComponent(match[1]) : '';
}

function withCsrfHeaders(headers = {}) {
    return {
        ...headers,
        'X-CSRF-Token': getCsrfToken()
    };
}

// --- BACKEND INTEGRATION GUIDE ---
// 
// The frontend is now structured to easily integrate with a backend API.
// Here's how to replace hardcoded data with API calls:
//
// 1. AUTHENTICATION:
//    - On login page: Call API endpoint, store token and user info using session.saveSession(user, token)
//    - session.isAuthenticated() checks if user is logged in
//    - session.token contains the auth token for API requests
//
// 2. DATA FETCHING:
//    - Replace individual data arrays with async functions
//    - Example: async function fetchInventory() { 
//        const response = await fetch('api/inventory', { headers: { 'Authorization': `Bearer ${session.token}` }});
//        inventoryData = await response.json();
//        renderInventory('all');
//      }
//    - Call on page load or data refresh
//
// 3. API ENDPOINTS NEEDED:
//    - POST /api/login - Authenticate user
//    - GET /api/inventory - Fetch inventory items
//    - GET /api/requests - Fetch request records
//    - GET /api/users - Fetch user list
//    - GET /api/activities - Fetch recent activities
//    - POST /api/requests/:id/approve - Approve request
//    - POST /api/requests/:id/decline - Decline request
//    - POST /api/items - Add new inventory item
//    - POST /api/users - Add new user
//
// 4. ERROR HANDLING:
//    - Add try-catch blocks around fetch calls
//    - Handle 401 errors by calling logout() and redirecting to login
//    - Display user-friendly error messages
//
// 5. INITIALIZATION:
//    - Check session.isAuthenticated() before loading admin page
//    - If not authenticated, redirect to login
//    - Load all required data before showing page

// --- CENTRAL DATA ---
const fallbackInventoryData = [
    { id: 1, item_name: 'Bond Paper', category: 'Paper Products', stock: 15, unit: 'ream', min_stock: 10, last_modified: '2026-09-06' },
    { id: 2, item_name: 'Ballpoint Pens', category: 'Writing Supplies', stock: 42, unit: 'dozen', min_stock: 15, last_modified: '2026-09-05' },
    { id: 3, item_name: 'A4 Notebooks', category: 'Office Supplies', stock: 9, unit: 'dozen', min_stock: 12, last_modified: '2026-09-04' },
    { id: 4, item_name: 'Printer Paper', category: 'Paper Products', stock: 0, unit: 'ream', min_stock: 8, last_modified: '2026-09-03' },
    { id: 5, item_name: 'Staplers', category: 'Office Supplies', stock: 0, unit: 'pcs', min_stock: 5, last_modified: '2026-09-02' },
    { id: 6, item_name: 'Highlighters', category: 'Writing Supplies', stock: 7, unit: 'pack', min_stock: 10, last_modified: '2026-09-05' },
    { id: 7, item_name: 'Binder Clips', category: 'Office Supplies', stock: 18, unit: 'box', min_stock: 12, last_modified: '2026-09-06' },
    { id: 8, item_name: 'Sticky Notes', category: 'Paper Products', stock: 21, unit: 'pack', min_stock: 18, last_modified: '2026-09-01' },
    { id: 9, item_name: 'Desk Organizer', category: 'Office Supplies', stock: 12, unit: 'pcs', min_stock: 6, last_modified: '2026-09-01' },
    { id: 10, item_name: 'Correction Fluid', category: 'Writing Supplies', stock: 14, unit: 'bottle', min_stock: 8, last_modified: '2026-09-04' }
];

const fallbackRequestsData = [
    { id: 1001, item_name: 'Bond Paper', item: 'Bond Paper', quantity: 8, requestor: 'CAVITE', status: 'Pending', request_date: '2026-09-06T09:15:00', stock_status: 'Low Stock', approver: 'Approver Donna' },
    { id: 1002, item_name: 'Ballpoint Pens', item: 'Ballpoint Pens', quantity: 16, requestor: 'BATANGAS', status: 'Approved', request_date: '2026-09-05T13:30:00', stock_status: 'In Stock', approver: 'Approver Kurt' },
    { id: 1003, item_name: 'A4 Notebooks', item: 'A4 Notebooks', quantity: 25, requestor: 'RIZAL', status: 'Approved', request_date: '2026-09-04T11:40:00', stock_status: 'In Stock', approver: 'Approver Gab' },
    { id: 1004, item_name: 'Printer Paper', item: 'Printer Paper', quantity: 10, requestor: 'QUEZON', status: 'Declined', request_date: '2026-09-03T08:00:00', stock_status: 'Out of Stock', approver: 'Approver Donna' },
    { id: 1005, item_name: 'Staplers', item: 'Staplers', quantity: 6, requestor: 'LAGUNA', status: 'Pending', request_date: '2026-09-02T10:10:00', stock_status: 'Out of Stock', approver: 'Approver Kurt' }
];

let inventoryData = [];

// Recent Requests Data (will be populated from backend)
let recentRequestsData = [];

// Requests Data (full list, will be populated from backend)
let requestsData = [];
let currentRequestFilter = 'all';
let currentRequestType = 'all';
let currentRequestSearch = '';
let adminHistoryStartDate = '';
let adminHistoryEndDate = '';

// Deliveries Data (full list, will be populated from backend)
let deliveriesData = [];

// Recent Activities Data, derived from live request and PPMP records.
let activitiesData = [];
let activitySummaryData = [];

let notificationsData = [];
let ppmpData = [];

// Users Data
let usersData = [
    { name: "Flavio Deza", email: "fdeza@gmail.com", role: "Admin", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza II", email: "fdeaza2@gmail.com", role: "Admin", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza III", email: "fdeaza3@gmail.com", role: "Approver", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza IV", email: "fdeaza4@gmail.com", role: "Approver", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza V", email: "fdeaza5@gmail.com", role: "Approver", province: "LAGUNA", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza VI", email: "fdeaza6@gmail.com", role: "Requester", province: "BATANGAS", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza VII", email: "fdeaza7@gmail.com", role: "Requester", province: "CAVITE", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza VIII", email: "fdeaza8@gmail.com", role: "Requester", province: "QUEZON", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" },
    { name: "Flavio Deza IX", email: "fdeaza9@gmail.com", role: "Requester", province: "RIZAL", lastActive: "Apr 10, 2026", dateAdded: "Mar 10, 2026" }
];
// Sorting state for users table
let usersSortField = null; // one of: name, role, province, lastActive, dateAdded
let usersSortDir = 'asc'; // 'asc' or 'desc'
// Request sorting state
let requestSortField = 'ris'; // 'ris' or 'date'
let requestSortDir = 'desc'; // 'asc' or 'desc'

// Inventory sorting/filtering state
let inventorySortField = 'item'; // 'item' or 'date'
let inventorySortDir = 'desc'; // 'asc' or 'desc'
let inventoryCategoryFilter = 'all';
const navItems = document.querySelectorAll(".nav li, .nav-bottom li");
const pages = document.querySelectorAll(".page");
const centralNavItems = document.querySelectorAll(".central-nav-item");

navItems.forEach(item => {
    item.onclick = () => {
        if(item.dataset.page === 'logout') {
            logout();
        } else {
            showPage(item.dataset.page);
        }
    };
});

centralNavItems.forEach(item => {
    item.onclick = () => {
        if (item.dataset.page === 'logout') {
            logout();
        } else {
            showPage(item.dataset.page);
        }
    };
});

function showPage(pageId) {
    pages.forEach(p => p.classList.remove("active"));
    navItems.forEach(n => n.classList.remove("active"));
    
    const pageEl = document.getElementById(pageId);
    if (!pageEl) {
        pageId = 'dashboard';
    }
    document.getElementById(pageId)?.classList.add("active");
    document.querySelector(`.nav li[data-page="${pageId}"], .nav-bottom li[data-page="${pageId}"]`)?.classList.add("active");
    
    const titleMap = {
        'dashboard': 'Dashboard',
        'usermanagement': 'User Management',
        'inventory': 'Inventory',
        'approvals': 'Request Management',
        'requestHistory': 'Request History',
        'reports': 'Reports',
        'settings': 'Account Settings',
        'system': 'System Settings'
    };
    const subtitleMap = {
        'dashboard': 'Explore your needs here',
        'usermanagement': 'Manage your users here',
        'inventory': 'Mange your inventories here',
        'approvals': 'View requests here',
        'requestHistory': 'Review requests submitted more than one week ago',
        'reports': 'Review usage, exports, and inventory trends.',
        'settings': '',
        'system': 'Configure inventory, requests, and notification preferences.'
    };
    
    document.getElementById("page-title").textContent = titleMap[pageId] || pageId.charAt(0).toUpperCase() + pageId.slice(1);
    const subtitleEl = document.getElementById("page-subtitle");
    if (subtitleEl) {
        subtitleEl.textContent = subtitleMap[pageId] || '';
        subtitleEl.style.display = subtitleMap[pageId] ? '' : 'none';
    }

    const globalSearch = document.getElementById("globalSearchBar");
    if (globalSearch) {
        globalSearch.style.display = (pageId === 'dashboard') ? '' : 'none';
    }
    
    if(pageId === 'dashboard') {
        initDashboard();
    }
    if(pageId === 'inventory') renderInventory('all');
    if(pageId === 'approvals') {
        const defaultFilter = loadSystemSettings().defaultRequestFilter || 'all';
        document.querySelectorAll('.request-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`.request-tab[data-filter="${defaultFilter}"]`)?.classList.add('active');
        renderRequests(defaultFilter);
    }
    if(pageId === 'requestHistory') renderAdminRequestHistory();
    if(pageId === 'reports') renderReports(currentReportRange);
    if(pageId === 'usermanagement') renderUsers();
    if(pageId === 'settings') renderAccountSettings();
    if(pageId === 'system') loadSystemSettingsForm();
}

// --- LOGOUT FUNCTIONALITY ---
function logout() {
    // Clear session data
    session.clearSession();
    
    // Clear all data arrays
    inventoryData = [];
    recentRequestsData = [];
    activitiesData = [];
    notificationsData = [];
    approvalsData = [];
    usersData = [];
    requestsData = [];
    
    // Redirect to login page through server logout
    window.location.href = logoutPageUrl;
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toastMessage');
    if (!toast) return;

    toast.textContent = message;
    toast.className = `toast-message toast-${type} show`;
    clearTimeout(toast.hideTimer);
    toast.hideTimer = setTimeout(() => {
        toast.className = `toast-message toast-${type}`;
    }, 3200);
}

// --- DASHBOARD LOGIC ---
function getStatus(stock, min) {
    if (stock <= 0) return "out";
    if (stock <= min) return "low";
    return "in";
}

function initDashboard() {
    renderDashboardStats();
    renderRecentRequests();
    renderRecentActivities();
    renderPopularItems();
    renderActivitySummary();
}

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function formatOfficeName(requestor) {
    if (!requestor) return '—';
    const name = String(requestor).trim();
    if (/office/i.test(name)) return name;
    return `${name} Provincial Office`;
}

function formatRisNumber(id, risNumber = '') {
    if (risNumber) return risNumber;
    if (id === undefined || id === null || id === '') return 'RIS#XXXXXXXX';
    return `RIS-${String(id).padStart(8, '0')}`;
}

function formatLongDate(dateValue) {
    const d = new Date(dateValue);
    if (Number.isNaN(d.getTime())) return '—';
    return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

function renderDashboardStats() {
    let totalCount = inventoryData.length;
    let lowCount = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'low').length;
    let outCount = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'out').length;
    let pendingCount = (requestsData.length ? requestsData : recentRequestsData)
        .filter(r => String(r.status || '').toLowerCase() === 'pending').length;
    
    document.getElementById("totalInventoryCount").textContent = String(totalCount);
    document.getElementById("lowStockCount").textContent = String(lowCount);
    document.getElementById("outStockCount").textContent = String(outCount);
    const pendingEl = document.getElementById("pendingRequestCount");
    if (pendingEl) pendingEl.textContent = String(pendingCount);

    const ppmpCounts = { pending: 0, approved: 0, declined: 0 };
    ppmpData.forEach(ppmp => {
        const status = ppmp.status === 'Rejected' ? 'declined' : String(ppmp.status || 'Pending').toLowerCase();
        if (ppmpCounts[status] !== undefined) ppmpCounts[status]++;
    });
    const ppmpPendingEl = document.getElementById('ppmpPendingCount');
    const ppmpApprovedEl = document.getElementById('ppmpApprovedCount');
    const ppmpDeclinedEl = document.getElementById('ppmpDeclinedCount');
    if (ppmpPendingEl) ppmpPendingEl.textContent = String(ppmpCounts.pending);
    if (ppmpApprovedEl) ppmpApprovedEl.textContent = String(ppmpCounts.approved);
    if (ppmpDeclinedEl) ppmpDeclinedEl.textContent = String(ppmpCounts.declined);
}

function renderRecentRequests() {
    const table = document.getElementById("recentRequestsTable");
    if (!table) return;

    table.innerHTML = "";
    
    recentRequestsData.forEach(req => {
        let statusClass = (req.status || 'Pending').toLowerCase();
        const statusColor = statusClass === 'pending' ? 'yellow' : statusClass === 'approved' ? 'green' : 'red';
        
        table.innerHTML += `
            <tr>
                <td>${escapeHtml(formatRisNumber(req.id, req.ris_number))}</td>
                <td>${formatOfficeName(req.requestor || req.office)}</td>
                <td>${formatLongDate(req.request_date)}</td>
                <td><span class="status ${statusColor}">${req.status || 'Pending'}</span></td>
            </tr>
        `;
    });
}

function rebuildRecentActivities() {
    const next = [];
    const today = new Date().toDateString();
    const addActivity = (activity, dateValue) => {
        const date = new Date(dateValue);
        if (Number.isNaN(date.getTime())) return;
        if (date.toDateString() !== today) return;
        next.push({ ...activity, date, time: formatNotificationTime(date) });
    };

    requestsData.forEach(request => {
        const status = String(request.status || 'Pending');
        const item = summarizeRequestItems(request);
        const date = status === 'Approved' || status === 'Declined'
            ? (request.approved_date || request.request_date)
            : request.request_date;
        if (status === 'Approved' || status === 'Declined') {
            addActivity({
                type: status === 'Approved' ? 'approved' : 'declined',
                name: request.approver || request.requestor || 'System',
                action: `${status.toLowerCase()} a request of ${item}`,
                reason: status === 'Declined' ? (request.note || request.remarks || '') : ''
            }, date);
        } else {
            addActivity({
                type: 'request',
                name: request.requestor || 'Requester',
                action: `requested ${item}`
            }, date);
        }
    });

    ppmpData.forEach(ppmp => {
        const status = String(ppmp.status || 'Pending');
        const isApproved = status === 'Approved';
        const isDeclined = status === 'Rejected';
        addActivity({
            type: isApproved ? 'approved' : isDeclined ? 'declined' : 'request',
            name: ppmp.province || ppmp.requestor_name || 'Office',
            action: isApproved
                ? 'approved a PPMP request'
                : isDeclined
                    ? 'declined a PPMP request'
                    : 'submitted a PPMP request',
            reason: isDeclined ? (ppmp.reason || '') : ''
        }, isApproved || isDeclined ? (ppmp.reviewed_at || ppmp.uploaded_at) : ppmp.uploaded_at);
    });

    const sortedActivities = next.sort((a, b) => b.date - a.date);
    activitySummaryData = sortedActivities;
    activitiesData = sortedActivities.slice(0, 4);
}

function renderRecentActivities() {
    const list = document.getElementById("recentActivitiesList");
    list.innerHTML = "";
    
    activitiesData.forEach(activity => {
        const iconClass = `activity-icon ${activity.type}`;
        const reasonHtml = activity.reason
            ? `<span class="activity-reason">Due to: ${activity.reason}</span>`
            : '';
        
        list.innerHTML += `
            <div class="activity-item">
                <div class="${iconClass}"></div>
                <div class="activity-text">
                    <span class="activity-name">${activity.name}</span>
                    <span class="activity-description"> ${activity.action}</span>
                    ${reasonHtml}
                </div>
                <span class="activity-time">${activity.time}</span>
            </div>
        `;
    });
}

function renderPopularItems() {
    const list = document.getElementById("popularItemsList");
    list.innerHTML = "";
    
    // Get items sorted by most requested (using recentRequestsData as popularity metric)
    const requestedItems = recentRequestsData.map(req => req.item);
    const popularItemsSet = new Set(requestedItems);
    
    const itemsWithStatus = inventoryData
        .filter(item => popularItemsSet.has(item.item_name))
        .map(item => ({
            ...item,
            status: getStatus(item.stock, item.min_stock)
        }))
        .slice(0, 5);
    
    // If not enough items from requests, add some from inventory
    if (itemsWithStatus.length < 5) {
        const additionalItems = inventoryData
            .filter(item => !popularItemsSet.has(item.item_name))
            .slice(0, 5 - itemsWithStatus.length)
            .map(item => ({
                ...item,
                status: getStatus(item.stock, item.min_stock)
            }));
        itemsWithStatus.push(...additionalItems);
    }
    
    itemsWithStatus.forEach(item => {
        const indicatorClass = item.status === 'in' ? 'indicator-green' : 
                              item.status === 'low' ? 'indicator-yellow' : 'indicator-red';
        const id = `ITM${String(item.id).padStart(4, '0')}`;
        const imgStyle = item.image ? `style="background-image:url(${item.image}); background-size:cover;"` : '';
        list.innerHTML += `
            <li>
                <div class="popular-item-left">
                    <div class="item-img-box" ${imgStyle}></div>
                    <div style="min-width:0;">
                        <div class="item-name">${item.item_name}</div>
                        <div class="item-id">${id}</div>
                    </div>
                </div>
                <div class="item-stock-indicator ${indicatorClass}"></div>
            </li>
        `;
    });
}

function renderActivitySummary() {
    const today = new Date().toDateString();
    const todayActivities = activitySummaryData.filter(activity => activity.date instanceof Date && activity.date.toDateString() === today);
    let requestCount = todayActivities.filter(a => a.type === 'request').length;
    let approvedCount = todayActivities.filter(a => a.type === 'approved').length;
    let declinedCount = todayActivities.filter(a => a.type === 'declined').length;
    
    document.getElementById("activityRequest").textContent = requestCount;
    document.getElementById("activityApproved").textContent = approvedCount;
    document.getElementById("activityDeclined").textContent = declinedCount;
}

function renderInventory(filter) {
    populateInventoryCategories();
    filterAndRenderInventory(searchInput?.value || '');
}

function populateInventoryCategories() {
    const select = document.getElementById('inventoryCategorySelect');
    if (!select) return;

    const categories = Array.from(new Set(
        inventoryData
            .map(i => (i.category || '').trim())
            .filter(c => c)
            .map(c => c.toLowerCase())
    )).sort();

    const currentValue = select.value || 'all';
    select.innerHTML = '<option value="all">All Categories</option>' +
        categories.map(category => `
            <option value="${category}"${category === currentValue ? ' selected' : ''}>
                ${category.replace(/\b\w/g, ch => ch.toUpperCase())}
            </option>`
        ).join('');
}

document.querySelectorAll(".stat-card").forEach(card => {
    card.onclick = () => {
        const goto = card.dataset.goto || 'inventory';
        showPage(goto);
        if (goto === 'inventory') renderInventory(card.dataset.filter || 'all');
        if (goto === 'approvals') renderRequests(card.dataset.filter || 'all');
    };
});

document.querySelectorAll('[data-goto]').forEach(btn => {
    if (btn.classList.contains('stat-card')) return;
    btn.addEventListener('click', () => showPage(btn.dataset.goto));
});

// --- APPROVALS/REQUESTS LOGIC ---
function isAdminHistoryRequest(request) {
    const date = new Date(request.request_date);
    return !Number.isNaN(date.getTime()) && date.getTime() <= Date.now() - (7 * 24 * 60 * 60 * 1000);
}

function getAdminRequestRows() {
    return [
        ...requestsData.map(req => ({ ...req, request_type: 'Item Request' })),
        ...ppmpData.map(ppmp => ({
            ...ppmp,
            id: `PPMP-${ppmp.id}`,
            rawId: ppmp.id,
            request_type: 'PPMP Request',
            item_name: `${ppmp.item_count || 0} item(s)`,
            quantity: ppmp.item_count || 0,
            requestor: ppmp.province || ppmp.requestor_name || '—',
            status: ppmp.status === 'Approved' ? 'Approved' : ppmp.status === 'Rejected' ? 'Declined' : 'Pending',
            request_date: ppmp.uploaded_at,
            stock_status: '—',
            approver: ppmp.reviewed_by || ''
        }))
    ];
}

function renderRequests(filter) {
    currentRequestFilter = filter || currentRequestFilter || 'all';
    const table = document.getElementById("requestTable");
    if (!table) return;

    table.innerHTML = "";
    
    let counts = { all: 0, today: 0, pending: 0, approved: 0, declined: 0 };
    const todayStr = new Date().toDateString();
    const requestRows = getAdminRequestRows()
        .filter(req => !isAdminHistoryRequest(req))
        .filter(req => currentRequestType === 'all' || req.request_type === currentRequestType);
    
        const todayActivities = requestRows.filter(req => {
            const reqDate = new Date(req.request_date);
            return !isAdminHistoryRequest(req) && reqDate.toDateString() === todayStr;
        });
        counts.today = todayActivities.length;
        counts.all = requestRows.length;
        counts.pending = requestRows.filter(req => req.status === 'Pending').length;
        counts.approved = requestRows.filter(req => req.status === 'Approved').length;
        counts.declined = requestRows.filter(req => req.status === 'Declined').length;
    
    const allCountEl = document.getElementById("req-count-all");
    if (allCountEl) allCountEl.textContent = counts.all;
    const todayCountEl = document.getElementById("req-count-today");
    if (todayCountEl) todayCountEl.textContent = counts.today;
    const pendingCountEl = document.getElementById("req-count-pending");
    if (pendingCountEl) pendingCountEl.textContent = counts.pending;
    const approvedCountEl = document.getElementById("req-count-approved");
    if (approvedCountEl) approvedCountEl.textContent = counts.approved;
    const declinedCountEl = document.getElementById("req-count-declined");
    if (declinedCountEl) declinedCountEl.textContent = counts.declined;

    const query = String(currentRequestSearch || '').trim().toLowerCase();
    const filteredRequests = requestRows.filter((req) => {
        const reqStatus = (req.status || 'Pending').toLowerCase();
        const reqDate = new Date(req.request_date);
        const isToday = !Number.isNaN(reqDate.getTime()) && reqDate.toDateString() === todayStr;

        if (currentRequestFilter === 'today') {
            if (!isToday) return false;
        } else if (currentRequestFilter !== 'all' && reqStatus !== currentRequestFilter.toLowerCase()) {
            return false;
        }

        if (!query) return true;

        const searchText = [
            formatRisNumber(req.id, req.ris_number),
            req.item_name,
            req.requestor,
            req.approver,
            req.status,
            req.request_type,
            req.stock_status,
            req.note,
            req.remarks
        ].filter(Boolean).join(' ').toLowerCase();

        return searchText.includes(query);
    });

    filteredRequests.sort((a, b) => {
        if (requestSortField === 'ris') {
            const comparison = String(a.ris_number || '').localeCompare(String(b.ris_number || ''));
            return requestSortDir === 'asc' ? comparison : -comparison;
        }
        const at = new Date(a.request_date).getTime() || 0;
        const bt = new Date(b.request_date).getTime() || 0;
        return requestSortDir === 'asc' ? at - bt : bt - at;
    });

    if (filteredRequests.length === 0) {
        table.innerHTML = `
            <tr>
                <td colspan="9" class="request-empty-row">No requests match your search or filter.</td>
            </tr>
        `;
        return;
    }

    const rowsHtml = filteredRequests.map((req, index) => {
        const reqStatus = (req.status || 'Pending').toLowerCase();
        const reqDate = new Date(req.request_date);
        const statusClass = req.status === 'Approved'
            ? 'request-status-approved'
            : req.status === 'Pending'
                ? 'request-status-pending'
                : req.status === 'Declined'
                    ? 'request-status-declined'
                    : '';

        const stockStatus = req.stock_status || 'In Stock';
        const stockClass = stockStatus === 'In Stock'
            ? 'stock-status-in'
            : stockStatus === 'Low Stock'
                ? 'stock-status-low'
                : stockStatus === 'Out of Stock'
                    ? 'stock-status-out'
                    : '';

        const formattedDate = Number.isNaN(reqDate.getTime()) ? '—' :
            `${reqDate.getFullYear()}-${String(reqDate.getMonth() + 1).padStart(2, '0')}-${String(reqDate.getDate()).padStart(2, '0')}`;

        const isPpmp = req.request_type === 'PPMP Request';
        const requestIdValue = String(req.id || '').replace(/^PPMP-/, '');
        const requestDisplayId = isPpmp ? escapeHtml(String(req.id)) : escapeHtml(formatRisNumber(req.id, req.ris_number));
        const requestTypeText = escapeHtml(String(req.request_type || 'Item Request'));
        const requestText = escapeHtml(String(req.item_name || '—'));
        const officeText = escapeHtml(formatOfficeName(req.requestor));
        const statusText = escapeHtml(String(req.status || 'Pending'));
        const byLine = (req.status === 'Approved' || req.status === 'Declined') && req.approver
            ? `<span class="request-by">by ${escapeHtml(req.approver)}</span>`
            : '';

        return `
            <tr onclick="${isPpmp ? "showPage('approvals')" : `showRequestDetails(${Number(requestIdValue) || String(requestIdValue)})`}">
                <td><div class="ris-cell"><span>${requestDisplayId}</span></div></td>
                <td><span class="request-type-badge ${isPpmp ? 'request-type-ppmp' : 'request-type-item'}">${requestTypeText}</span></td>
                <td>${requestText}</td>
                <td>${Number(req.quantity) || 0}</td>
                <td>${officeText}</td>
                <td><span class="${stockClass}">${escapeHtml(stockStatus)}</span></td>
                <td><span class="${statusClass}">${statusText}${byLine}</span></td>
                <td>${formattedDate}</td>
                <td><div class="request-action-wrap"><button class="request-menu-btn" type="button" aria-label="Request actions" aria-expanded="false">⋮</button><div class="request-action-menu"><button type="button" data-request-action="view" data-request-id="${escapeHtml(String(req.id || ''))}" data-request-type="${escapeHtml(String(req.request_type || ''))}">View Request</button><button type="button" data-request-action="approve" data-request-id="${escapeHtml(String(req.id || ''))}">Approve</button><button type="button" data-request-action="decline" data-request-id="${escapeHtml(String(req.id || ''))}">Decline</button></div></div></td>
            </tr>
        `;
    }).join('');

    table.innerHTML = rowsHtml;
    bindRequestActionMenus(table);
}

function renderAdminRequestHistory() {
    const table = document.getElementById('adminHistoryTable');
    if (!table) return;

    let rows = getAdminRequestRows().filter(isAdminHistoryRequest);
    const toDateValue = (request) => {
        const date = new Date(request.request_date);
        if (Number.isNaN(date.getTime())) return '';
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    };
    if (adminHistoryStartDate) rows = rows.filter(row => toDateValue(row) >= adminHistoryStartDate);
    if (adminHistoryEndDate) rows = rows.filter(row => toDateValue(row) <= adminHistoryEndDate);
    rows.sort((a, b) => new Date(b.request_date) - new Date(a.request_date));

    const summary = document.getElementById('adminHistorySummary');
    if (summary) summary.textContent = `${rows.length} ${rows.length === 1 ? 'request' : 'requests'} in history`;
    if (!rows.length) {
        table.innerHTML = '<tr><td colspan="9" class="request-empty-row">No requests found for this date range.</td></tr>';
        return;
    }

    table.innerHTML = rows.map(req => {
        const isPpmp = req.request_type === 'PPMP Request';
        const requestIdValue = String(req.id || '').replace(/^PPMP-/, '');
        const requestDisplayId = isPpmp ? escapeHtml(String(req.id)) : escapeHtml(formatRisNumber(req.id, req.ris_number));
        const status = String(req.status || 'Pending');
        const statusClass = status === 'Approved' ? 'request-status-approved' : status === 'Pending' ? 'request-status-pending' : status === 'Declined' ? 'request-status-declined' : '';
        const stockStatus = req.stock_status || 'In Stock';
        const stockClass = stockStatus === 'In Stock' ? 'stock-status-in' : stockStatus === 'Low Stock' ? 'stock-status-low' : stockStatus === 'Out of Stock' ? 'stock-status-out' : '';
        const requestDate = new Date(req.request_date);
        const formattedDate = Number.isNaN(requestDate.getTime()) ? '—' : `${requestDate.getFullYear()}-${String(requestDate.getMonth() + 1).padStart(2, '0')}-${String(requestDate.getDate()).padStart(2, '0')}`;
        const action = isPpmp ? "showPage('approvals')" : `showRequestDetails(${Number(requestIdValue) || String(requestIdValue)})`;
        return `<tr onclick="${action}">
            <td><div class="ris-cell"><span>${requestDisplayId}</span></div></td>
            <td><span class="request-type-badge ${isPpmp ? 'request-type-ppmp' : 'request-type-item'}">${escapeHtml(String(req.request_type))}</span></td>
            <td>${escapeHtml(String(req.item_name || '—'))}</td>
            <td>${Number(req.quantity) || 0}</td>
            <td>${escapeHtml(formatOfficeName(req.requestor))}</td>
            <td><span class="${stockClass}">${escapeHtml(stockStatus)}</span></td>
            <td><span class="${statusClass}">${escapeHtml(status)}</span></td>
            <td>${formattedDate}</td>
            <td><div class="request-action-wrap"><button class="request-menu-btn" type="button" aria-label="Request actions" aria-expanded="false">⋮</button><div class="request-action-menu"><button type="button" data-request-action="view" data-request-id="${escapeHtml(String(req.id || ''))}" data-request-type="${escapeHtml(String(req.request_type || ''))}">View Request</button><button type="button" data-request-action="approve" data-request-id="${escapeHtml(String(req.id || ''))}">Approve</button><button type="button" data-request-action="decline" data-request-id="${escapeHtml(String(req.id || ''))}">Decline</button></div></div></td>
        </tr>`;
    }).join('');
    bindRequestActionMenus(table);
}

function bindRequestActionMenus(table) {
    table.querySelectorAll('.request-menu-btn').forEach((button) => {
        button.addEventListener('click', (event) => {
            event.stopPropagation();
            const menu = button.nextElementSibling;
            const willOpen = menu && !menu.classList.contains('open');
            document.querySelectorAll('.request-action-menu.open').forEach((openMenu) => openMenu.classList.remove('open'));
            document.querySelectorAll('.request-menu-btn[aria-expanded="true"]').forEach((openButton) => openButton.setAttribute('aria-expanded', 'false'));
            if (willOpen && menu) {
                menu.classList.add('open');
                button.setAttribute('aria-expanded', 'true');
            }
        });
    });

    table.querySelectorAll('[data-request-action]').forEach((actionButton) => {
        actionButton.addEventListener('click', async (event) => {
            event.stopPropagation();
            const requestId = actionButton.dataset.requestId;
            const action = actionButton.dataset.requestAction;
            const requestType = actionButton.dataset.requestType || '';
            document.querySelectorAll('.request-action-menu.open').forEach((menu) => menu.classList.remove('open'));
            if (!requestId) return;

            if (action === 'view') {
                if (requestType === 'PPMP Request') showPage('approvals');
                else showRequestDetails(requestId);
                return;
            }

            const status = action === 'approve' ? 'Approved' : 'Declined';
            if (confirm(`${status} this request?`)) await updateRequestStatus(requestId, status);
        });
    });
}

document.getElementById('openAdminRequestHistoryBtn')?.addEventListener('click', () => showPage('requestHistory'));
document.getElementById('adminHistoryBackBtn')?.addEventListener('click', () => showPage('approvals'));
document.getElementById('adminHistoryStartDate')?.addEventListener('change', (event) => {
    adminHistoryStartDate = event.target.value;
    renderAdminRequestHistory();
});
document.getElementById('adminHistoryEndDate')?.addEventListener('change', (event) => {
    adminHistoryEndDate = event.target.value;
    renderAdminRequestHistory();
});
document.getElementById('clearAdminHistoryDates')?.addEventListener('click', () => {
    adminHistoryStartDate = '';
    adminHistoryEndDate = '';
    document.getElementById('adminHistoryStartDate').value = '';
    document.getElementById('adminHistoryEndDate').value = '';
    renderAdminRequestHistory();
});

function showRequestDetails(requestId) {
    const req = requestsData.find(r => String(r.id) === String(requestId));
    if (!req) return;
    
    const modal = document.getElementById("requestDetailsModal");
    if (!modal) return;
    
    const reqNoEl = document.getElementById("detailReqNo");
    const reqStatusEl = document.getElementById("detailReqStatus");
    const reqDateEl = document.getElementById("detailReqDate");
    const requestorEl = document.getElementById("detailRequestor");
    const approverEl = document.getElementById("detailApprover");
    const itemNameEl = document.getElementById("detailItemName");
    const qtyEl = document.getElementById("detailQty");
    const remarksEl = document.getElementById("detailRemarks");
    const noteEl = document.getElementById("detailNote");

    if (reqNoEl) reqNoEl.textContent = formatRisNumber(req.id, req.ris_number);
    if (reqStatusEl) {
        reqStatusEl.textContent = req.status || 'Pending';
        reqStatusEl.className = `request-status-badge status-${(req.status || 'Pending').toLowerCase()}-badge`;
    }
    
    const reqDate = new Date(req.request_date);
    const formattedDate = reqDate.getFullYear() + '-' + 
                         (reqDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                         reqDate.getDate().toString().padStart(2, '0');
    if (reqDateEl) reqDateEl.textContent = formattedDate;
    if (requestorEl) requestorEl.textContent = req.requestor || '—';
    if (approverEl) approverEl.textContent = req.approver || '-';
    if (itemNameEl) itemNameEl.textContent = req.item_name || '—';
    if (qtyEl) qtyEl.textContent = req.quantity ?? 0;
    if (remarksEl) remarksEl.textContent = req.stock_status || 'In Stock';
    if (noteEl) noteEl.textContent = req.note || '';
    
    modal.dataset.requestId = req.id;
    modal.classList.add("active");
}

document.getElementById("closeRequestDetails").onclick = () => {
    document.getElementById("requestDetailsModal").classList.remove("active");
};

document.getElementById("requestDetailsModal").onclick = (e) => {
    if (e.target.id === "requestDetailsModal") {
        document.getElementById("requestDetailsModal").classList.remove("active");
    }
};

// Request action buttons
document.getElementById("approveRequestBtn").onclick = async () => {
    const modal = document.getElementById("requestDetailsModal");
    const requestId = modal.dataset.requestId;
    if (!requestId) return;
    
    if (confirm('Approve this request?')) {
        const result = await updateRequestStatus(requestId, 'Approved');
        if (result) {
            modal.classList.remove("active");
        }
    }
};

document.getElementById("declineRequestBtn").onclick = async () => {
    const modal = document.getElementById("requestDetailsModal");
    const requestId = modal.dataset.requestId;
    if (!requestId) return;
    
    if (confirm('Decline this request?')) {
        const result = await updateRequestStatus(requestId, 'Declined');
        if (result) {
            modal.classList.remove("active");
        }
    }
};

document.querySelectorAll(".request-tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".request-tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        renderRequests(tab.dataset.filter);
    };
});

document.querySelectorAll('.request-type-tab').forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll('.request-type-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        currentRequestType = tab.dataset.requestType || 'all';
        renderRequests(currentRequestFilter);
    };
});

// Wire request search input to filter requests live
const requestSearchInput = document.getElementById('requestSearchInput');
if (requestSearchInput) {
    requestSearchInput.addEventListener('input', () => {
        currentRequestSearch = requestSearchInput.value || '';
        const activeTab = document.querySelector('.request-tab.active');
        const filter = activeTab ? activeTab.dataset.filter : currentRequestFilter;
        renderRequests(filter);
    });
}

// Initialize request sort controls (field toggler and direction)
function initRequestSortControls() {
    const sortBtn = document.getElementById('requestSortBtn');
    const sortFieldBtn = document.getElementById('requestSortFieldBtn');

    if (sortBtn) {
        sortBtn.addEventListener('click', () => {
            requestSortDir = requestSortDir === 'asc' ? 'desc' : 'asc';
            const activeTab = document.querySelector('.request-tab.active');
            const filter = activeTab ? activeTab.dataset.filter : currentRequestFilter;
            renderRequests(filter);
            sortBtn.title = `Sort ${requestSortField.toUpperCase()} (${requestSortDir})`;
        });
        sortBtn.title = `Sort ${requestSortField.toUpperCase()} (${requestSortDir})`;
    }

    if (sortFieldBtn) {
        sortFieldBtn.addEventListener('click', () => {
            requestSortField = requestSortField === 'ris' ? 'date' : 'ris';
            sortFieldBtn.textContent = requestSortField === 'ris' ? 'RIS' : 'DATE';
            const activeTab = document.querySelector('.request-tab.active');
            const filter = activeTab ? activeTab.dataset.filter : currentRequestFilter;
            renderRequests(filter);
            sortFieldBtn.title = `Sorting field: ${requestSortField.toUpperCase()}`;
        });
        sortFieldBtn.textContent = requestSortField === 'ris' ? 'RIS' : 'DATE';
        sortFieldBtn.title = `Sorting field: ${requestSortField.toUpperCase()}`;
    }
}

function initInventoryControls() {
    const sortDirBtn = document.getElementById('inventorySortDirBtn');
    const sortFieldBtn = document.getElementById('inventorySortFieldBtn');
    const categorySelect = document.getElementById('inventoryCategorySelect');

    if (sortDirBtn) {
        sortDirBtn.textContent = inventorySortDir === 'asc' ? '↑' : '↓';
        sortDirBtn.addEventListener('click', () => {
            inventorySortDir = inventorySortDir === 'asc' ? 'desc' : 'asc';
            sortDirBtn.textContent = inventorySortDir === 'asc' ? '↑' : '↓';
            filterAndRenderInventory(searchInput?.value || '');
        });
    }

    if (sortFieldBtn) {
        sortFieldBtn.textContent = inventorySortField === 'item' ? 'ITEM NO.' : 'DATE';
        sortFieldBtn.addEventListener('click', () => {
            inventorySortField = inventorySortField === 'item' ? 'date' : 'item';
            sortFieldBtn.textContent = inventorySortField === 'item' ? 'ITEM NO.' : 'DATE';
            filterAndRenderInventory(searchInput?.value || '');
        });
    }

    populateInventoryCategories();
    if (categorySelect) {
        categorySelect.addEventListener('change', (e) => {
            inventoryCategoryFilter = e.target.value;
            filterAndRenderInventory(searchInput?.value || '');
        });
    }
}

function initAdminControls() {
    initRequestSortControls();
    initInventoryControls();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAdminControls);
} else {
    initAdminControls();
}

let currentReportRange = 'month';
let reportActivityEvents = [];
let reportActivityOffset = 0;
let reportActivityTotal = 0;
let reportActivityRequestId = 0;
const reportActivityPageSize = 5;

function initReportRangeButtons() {
    document.querySelectorAll('.range-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.range-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentReportRange = btn.dataset.range || 'month';
            renderReports(currentReportRange);
        };
    });
}

function reportDateInputValue(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function getReportRangeDates(range) {
    const now = new Date();
    let start;
    if (range === 'year') {
        start = new Date(now.getFullYear(), 0, 1);
    } else if (range === 'quarter') {
        start = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
    } else {
        start = new Date(now.getFullYear(), now.getMonth(), 1);
    }
    return { start: reportDateInputValue(start), end: reportDateInputValue(now) };
}

function formatActivityDetails(details) {
    if (!details || typeof details !== 'object') return '';
    const labels = {
        full_name: 'Name',
        email: 'Email',
        role: 'Role',
        province: 'Province',
        status: 'Status',
        username: 'Username',
        password_changed: 'Password',
        item_name: 'Item',
        quantity: 'Quantity',
        unit: 'Unit',
        category: 'Category',
        stock: 'Stock',
        before_stock: 'Previous stock',
        after_stock: 'New stock',
        quantity_change: 'Change',
        min_stock: 'Minimum stock',
        from_status: 'Previous status',
        to_status: 'New status',
        reason: 'Reason',
        file_name: 'File',
        fiscal_year: 'Fiscal year',
        requestor_name: 'Requester',
        requestor_stock_reserved: 'Requestor stock reserved',
        requestor_stock_restored: 'Requestor stock restored',
        supply_stock_deducted: 'Supply stock deducted',
        type: 'Report type',
        start_date: 'From',
        end_date: 'To',
        items: 'Items',
    };
    const labelFor = key => labels[key] || key.replace(/_/g, ' ').replace(/\b\w/g, letter => letter.toUpperCase());
    const formatValue = (key, value) => {
        if (key === 'password_changed') return value ? 'Changed' : 'Not changed';
        if (value === null || value === undefined || value === '') return 'Not provided';
        if (Array.isArray(value)) {
            if (key === 'items') {
                return value.map(item => {
                    if (!item || typeof item !== 'object') return String(item);
                    const name = item.item_name || item.name || 'Item';
                    const quantity = item.quantity ?? item.qty;
                    const unit = item.unit ? ` ${item.unit}` : '';
                    return `${name}${quantity !== undefined ? ` x${quantity}${unit}` : ''}`;
                }).join(', ');
            }
            return value.map(item => formatValue('', item)).filter(Boolean).join(', ');
        }
        if (typeof value === 'object') {
            return Object.entries(value).map(([childKey, childValue]) => `${labelFor(childKey)}: ${formatValue(childKey, childValue)}`).join(', ');
        }
        if (typeof value === 'boolean') return value ? 'Yes' : 'No';
        return String(value);
    };

    const output = [];
    if (details.before && typeof details.before === 'object' && details.after && typeof details.after === 'object') {
        const before = details.before;
        const after = details.after;
        const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
        keys.forEach(key => {
            if (key === 'id' || key === 'password_hash' || key === 'password') return;
            if (before[key] === after[key]) return;
            if (key === 'password_changed') {
                if (after[key]) output.push('Password: changed');
                return;
            }
            output.push(`${labelFor(key)}: ${formatValue(key, before[key])} -> ${formatValue(key, after[key])}`);
        });
    }

    Object.entries(details).forEach(([key, value]) => {
        if (key === 'before' || key === 'after' || key === 'password' || key === 'password_hash' || key === 'id') return;
        if (key === 'password_changed') {
            if (value && !details.after) output.push('Password: changed');
            return;
        }
        const formatted = formatValue(key, value);
        if (formatted) output.push(`${labelFor(key)}: ${formatted}`);
    });

    return output.join('; ');
}

function renderReportActivity() {
    const table = document.getElementById('reportActivityTable');
    const totalLabel = document.getElementById('reportActivityTotal');
    const pageLabel = document.getElementById('reportActivityPageLabel');
    const previous = document.getElementById('reportActivityPrevious');
    const next = document.getElementById('reportActivityNext');
    if (!table) return;

    totalLabel.textContent = `${reportActivityTotal} ${reportActivityTotal === 1 ? 'activity' : 'activities'}`;
    const pageCount = Math.max(1, Math.ceil(reportActivityTotal / reportActivityPageSize));
    const pageNumber = Math.floor(reportActivityOffset / reportActivityPageSize) + 1;
    pageLabel.textContent = `Page ${pageNumber} of ${pageCount}`;
    previous.disabled = reportActivityOffset === 0;
    next.disabled = reportActivityOffset + reportActivityPageSize >= reportActivityTotal;

    if (!reportActivityEvents.length) {
        table.innerHTML = '<tr><td colspan="5">No recorded activity for this reporting period.</td></tr>';
        return;
    }

    table.innerHTML = reportActivityEvents.map(event => {
        const eventName = String(event.event_type || 'activity').replace(/_/g, ' ');
        const details = formatActivityDetails(event.details);
        return `<tr>
            <td>${escapeHtml(new Date(String(event.created_at).replace(' ', 'T')).toLocaleString())}</td>
            <td><strong>${escapeHtml(event.summary || eventName)}</strong><small>${escapeHtml(event.entity_type || '')} ${escapeHtml(event.entity_id || '')}</small></td>
            <td>${escapeHtml(event.province || 'System-wide')}</td>
            <td>${escapeHtml(event.actor_username || 'System')}<small>${escapeHtml(event.actor_role || '')}</small></td>
            <td>${escapeHtml(details || eventName)}</td>
        </tr>`;
    }).join('');
}

async function loadReportActivity(startDate, endDate, offset = 0) {
    const requestId = ++reportActivityRequestId;
    const table = document.getElementById('reportActivityTable');
    if (table) table.innerHTML = '<tr><td colspan="5">Loading activity...</td></tr>';
    const params = new URLSearchParams({
        action: 'events',
        start_date: startDate,
        end_date: endDate,
        limit: String(reportActivityPageSize),
        offset: String(offset)
    });

    try {
        const response = await fetch(`${reportApiBase}?${params}`, { credentials: 'include' });
        const payload = await response.json();
        if (!response.ok || !payload.success) throw new Error(payload.message || 'Could not load report activity.');
        if (requestId !== reportActivityRequestId) return;
        reportActivityEvents = payload.data || [];
        reportActivityTotal = Number(payload.pagination?.total || 0);
        reportActivityOffset = offset;
        renderReportActivity();
    } catch (error) {
        if (requestId !== reportActivityRequestId) return;
        reportActivityEvents = [];
        reportActivityTotal = 0;
        const status = document.getElementById('reportActivityTable');
        if (status) status.innerHTML = `<tr><td colspan="5">${escapeHtml(error.message || 'Could not load activity.')}</td></tr>`;
        document.getElementById('reportActivityTotal').textContent = 'Unavailable';
    }
}

document.getElementById('reportActivityPrevious')?.addEventListener('click', () => {
    const { start, end } = getReportRangeDates(currentReportRange);
    loadReportActivity(start, end, Math.max(0, reportActivityOffset - reportActivityPageSize));
});
document.getElementById('reportActivityNext')?.addEventListener('click', () => {
    const { start, end } = getReportRangeDates(currentReportRange);
    loadReportActivity(start, end, reportActivityOffset + reportActivityPageSize);
});

function filterRequestsByRange(requests, range) {
    const now = new Date();
    const parsedRequests = (requests || []).filter(req => {
        if (!req.request_date) return false;
        const requestDate = new Date(req.request_date);
        return !Number.isNaN(requestDate.getTime());
    }).sort((a, b) => new Date(b.request_date) - new Date(a.request_date));

    const matching = parsedRequests.filter(req => {
        const requestDate = new Date(req.request_date);

        if (range === 'year') {
            return requestDate.getFullYear() === now.getFullYear();
        }

        if (range === 'quarter') {
            const quarter = Math.floor(now.getMonth() / 3);
            const requestQuarter = Math.floor(requestDate.getMonth() / 3);
            return requestDate.getFullYear() === now.getFullYear() && requestQuarter === quarter;
        }

        return requestDate.getFullYear() === now.getFullYear() && requestDate.getMonth() === now.getMonth();
    });

    return matching;
}

function renderReports(range = 'month') {
    const activityRange = getReportRangeDates(range);
    reportActivityOffset = 0;
    loadReportActivity(activityRange.start, activityRange.end, 0);
    const filteredRequests = filterRequestsByRange(requestsData, range);
    const totalRequests = filteredRequests.length;
    const approvedCount = filteredRequests.filter(r => (r.status || 'Pending').toLowerCase() === 'approved').length;
    const pendingCount = filteredRequests.filter(r => (r.status || 'Pending').toLowerCase() === 'pending').length;
    const declinedCount = filteredRequests.filter(r => (r.status || 'Pending').toLowerCase() === 'declined').length;
    const approvedRate = totalRequests ? Math.round((approvedCount / totalRequests) * 100) : 0;

    const rangeLabel = range === 'year' ? 'Year' : range === 'quarter' ? 'Quarter' : 'Month';
    const rangeTitle = document.querySelector('.report-chart-header h4');
    if (rangeTitle) rangeTitle.textContent = `${rangeLabel}ly Request & Inventory Overview`;

    const inventoryTotal = inventoryData.length;
    const lowCount = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'low').length;
    const outCount = inventoryData.filter(i => getStatus(i.stock, i.min_stock) === 'out').length;
    const inStockCount = inventoryTotal - lowCount - outCount;
    const stockHealth = inventoryTotal ? Math.round((inStockCount / inventoryTotal) * 100) : 0;

    document.getElementById('reportTotalRequests').textContent = totalRequests;
    document.getElementById('reportApprovalRate').textContent = `${approvedRate}%`;
    document.getElementById('reportStockHealth').textContent = `${stockHealth}%`;
    document.getElementById('reportPendingRequests').textContent = pendingCount;
    document.getElementById('reportTotalRequestsSubtitle').textContent = `Logged this ${range === 'year' ? 'year' : range === 'quarter' ? 'quarter' : 'month'}`;
    document.getElementById('reportPendingRequestsSubtitle').textContent = `Awaiting approval this ${range === 'year' ? 'year' : range === 'quarter' ? 'quarter' : 'month'}`;

    const totalStatus = Math.max(totalRequests, 1);
    const approvedPercent = Math.round((approvedCount / totalStatus) * 100);
    const pendingPercent = Math.round((pendingCount / totalStatus) * 100);
    const declinedPercent = Math.round((declinedCount / totalStatus) * 100);

    const totalStock = Math.max(inventoryTotal, 1);
    const instockPercent = Math.round((inStockCount / totalStock) * 100);
    const lowStockPercent = Math.round((lowCount / totalStock) * 100);
    const outStockPercent = Math.round((outCount / totalStock) * 100);

    setChartBarWidth('chartApprovedBar', approvedPercent);
    setChartBarWidth('chartPendingBar', pendingPercent);
    setChartBarWidth('chartDeclinedBar', declinedPercent);
    setChartBarWidth('chartInStockBar', instockPercent);
    setChartBarWidth('chartLowStockBar', lowStockPercent);
    setChartBarWidth('chartOutStockBar', outStockPercent);

    document.getElementById('chartApprovedValue').textContent = `${approvedPercent}%`;
    document.getElementById('chartPendingValue').textContent = `${pendingPercent}%`;
    document.getElementById('chartDeclinedValue').textContent = `${declinedPercent}%`;
    document.getElementById('chartInStockValue').textContent = `${instockPercent}%`;
    document.getElementById('chartLowStockValue').textContent = `${lowStockPercent}%`;
    document.getElementById('chartOutStockValue').textContent = `${outStockPercent}%`;

    const highlights = [
        { title: 'Low stock alerts', value: `${lowCount} items`, description: 'Items below minimum threshold' },
        { title: 'Out of stock items', value: `${outCount} items`, description: 'Items that need restocking now' },
        { title: 'Pending approvals', value: `${pendingCount} requests`, description: 'Awaiting manager review' },
        { title: 'Average approval rate', value: `${approvedRate}%`, description: 'Approved requests across selected range' }
    ];

    const list = document.getElementById('reportList');
    if (list) {
        list.innerHTML = highlights.map(item => `
            <li>
                <div>
                    <div class="report-list-title">${item.title}</div>
                    <div class="report-list-note">${item.description}</div>
                </div>
                <strong>${item.value}</strong>
            </li>
        `).join('');
    }
}

function setChartBarWidth(elementId, percent) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.style.width = `${percent}%`;
}

function initReportActions() {
    const reportDownloadBtn = document.getElementById('reportDownloadBtn');
    const reportDownloadMenu = document.getElementById('reportDownloadMenu');
    const reportDownloadItems = document.querySelectorAll('.report-download-item');

    if (reportDownloadBtn && reportDownloadMenu) {
        reportDownloadBtn.onclick = (event) => {
            event.stopPropagation();
            reportDownloadMenu.classList.toggle('hidden');
        };

        reportDownloadMenu.onclick = (event) => {
            event.stopPropagation();
        };

        document.addEventListener('click', () => {
            reportDownloadMenu.classList.add('hidden');
        });
    }

    reportDownloadItems.forEach(item => {
        item.onclick = () => {
            const type = item.dataset.exportType || 'csv';
            reportDownloadMenu?.classList.add('hidden');
            openReportDownloadModal(type);
        };
    });
}

// Report download modal behavior
const reportDownloadModal = document.getElementById('reportDownloadModal');
const reportDownloadRangeSelect = document.getElementById('reportDownloadRange');
const customDateRangeFields = document.getElementById('customDateRangeFields');
const monthlyReportFields = document.getElementById('monthlyReportFields');
const yearlyReportFields = document.getElementById('yearlyReportFields');
const reportMonthSelect = document.getElementById('reportMonth');
const reportMonthYearInput = document.getElementById('reportMonthYear');
const reportYearInput = document.getElementById('reportYear');
const reportStartDateInput = document.getElementById('reportStartDate');
const reportEndDateInput = document.getElementById('reportEndDate');
const confirmReportDownloadBtn = document.getElementById('confirmReportDownloadBtn');
const cancelReportDownloadBtn = document.getElementById('cancelReportDownloadBtn');
const closeReportDownloadModalBtn = document.getElementById('closeReportDownloadModal');

function openReportDownloadModal(type) {
    if (!reportDownloadModal) return;
    reportDownloadModal.dataset.exportType = type;
    reportDownloadRangeSelect.value = 'monthly';
    const now = new Date();
    reportMonthSelect.value = String(now.getMonth());
    reportMonthYearInput.value = String(now.getFullYear());
    reportYearInput.value = String(now.getFullYear());
    reportStartDateInput.value = '';
    reportEndDateInput.value = '';
    updateReportRangeFields();
    reportDownloadModal.classList.add('active');
}

function closeReportDownloadModal() {
    if (!reportDownloadModal) return;
    reportDownloadModal.classList.remove('active');
    delete reportDownloadModal.dataset.exportType;
}

if (reportDownloadRangeSelect) {
    reportDownloadRangeSelect.addEventListener('change', () => {
        updateReportRangeFields();
    });
}

function updateReportRangeFields() {
    const range = reportDownloadRangeSelect?.value || 'monthly';
    if (monthlyReportFields) monthlyReportFields.style.display = range === 'monthly' ? '' : 'none';
    if (yearlyReportFields) yearlyReportFields.style.display = range === 'yearly' ? '' : 'none';
    if (customDateRangeFields) customDateRangeFields.style.display = range === 'custom' ? '' : 'none';
}

if (cancelReportDownloadBtn) cancelReportDownloadBtn.onclick = closeReportDownloadModal;
if (closeReportDownloadModalBtn) closeReportDownloadModalBtn.onclick = closeReportDownloadModal;
if (reportDownloadModal) reportDownloadModal.onclick = (e) => { if (e.target === reportDownloadModal) closeReportDownloadModal(); };

async function fetchAllReportActivityEvents(startDate, endDate) {
    const events = [];
    let offset = 0;
    let total = 0;
    do {
        const params = new URLSearchParams({
            action: 'events',
            start_date: reportDateInputValue(startDate),
            end_date: reportDateInputValue(endDate),
            limit: '500',
            offset: String(offset)
        });
        const response = await fetch(`${reportApiBase}?${params}`, { credentials: 'include' });
        const payload = await response.json();
        if (!response.ok || !payload.success) throw new Error(payload.message || 'Could not load activity for export.');
        const batch = payload.data || [];
        events.push(...batch);
        total = Number(payload.pagination?.total || 0);
        offset += batch.length;
        if (!batch.length) break;
    } while (offset < total);
    return events;
}

function reportMetricsForRange(startDate, endDate) {
    const requests = (requestsData || []).filter(request => {
        const requestDate = new Date(request.request_date);
        return request.request_date && !Number.isNaN(requestDate.getTime()) && requestDate >= startDate && requestDate <= endDate;
    });
    const approved = requests.filter(request => String(request.status || '').toLowerCase() === 'approved').length;
    const pending = requests.filter(request => String(request.status || '').toLowerCase() === 'pending').length;
    const declined = requests.filter(request => String(request.status || '').toLowerCase() === 'declined').length;
    const low = inventoryData.filter(item => getStatus(item.stock, item.min_stock) === 'low').length;
    const out = inventoryData.filter(item => getStatus(item.stock, item.min_stock) === 'out').length;
    const healthy = inventoryData.length - low - out;
    return {
        totalRequests: requests.length,
        approvalRate: requests.length ? Math.round(approved / requests.length * 100) : 0,
        stockHealth: inventoryData.length ? Math.round(healthy / inventoryData.length * 100) : 0,
        pendingRequests: pending,
        approved,
        declined,
        lowStock: low,
        outOfStock: out,
    };
}

function buildReportTemplate(startDate, endDate, reportEvents) {
    const metrics = reportMetricsForRange(startDate, endDate);
    const requestRows = getDetailedReportRows(startDate, endDate).flatMap(request => {
        const requestRecord = requestsData.find(row => String(row.id) === String(request.requestId));
        let items = [];
        try {
            items = Array.isArray(requestRecord?.item_details)
                ? requestRecord.item_details
                : JSON.parse(requestRecord?.item_details || '[]');
        } catch (error) {
            items = [];
        }
        if (!items.length) {
            items = [{ item_name: requestRecord?.item_name || '', unit: '', quantity: requestRecord?.quantity || '' }];
        }
        return items.map(item => ({
            requestId: request.requestId,
            risNumber: request.risNumber,
            requestDate: request.requestDate,
            province: request.requestedBy,
            itemName: item.item_name || item.name || '',
            unit: item.unit || '',
            quantity: item.quantity ?? item.qty ?? '',
            stockStatus: request.stockStatus,
            requestStatus: request.requestStatus,
            approver: request.approver,
            approvedDate: request.approvedDate,
            deliveryPackage: request.deliveryPackage,
            deliveryStatus: request.deliveryStatus,
            deliveredBy: request.deliveredBy,
            deliveredDate: request.deliveredDate,
            remarks: request.remarks,
        }));
    });
    const inventoryRows = (inventoryData || []).map(item => ({
        itemId: item.id,
        itemName: item.item_name,
        category: item.category,
        unit: item.unit,
        quantityOnHand: Number(item.stock) || 0,
        minimumStock: Number(item.min_stock) || 0,
        stockStatus: getStatus(item.stock, item.min_stock),
        lastModified: item.last_modified || '',
    }));
    return {
        organization: 'Department of Labor and Employment',
        system: 'Inventory and Supply Management System',
        title: 'System Process and Inventory Report',
        periodStart: formatReportDate(startDate),
        periodEnd: formatReportDate(endDate),
        generatedAt: new Date().toLocaleString(),
        generatedBy: window.currentAdminFullName || window.currentAdminUser || 'Administrator',
        generatedByUsername: window.currentAdminUser || '',
        metrics,
        requestRows,
        events: reportEvents || [],
        inventoryRows,
    };
}

function csvCell(value) {
    let text = String(value ?? '');
    if (/^[\s\u0000-\u001f]*[=+@\-]/.test(text)) text = `'${text}`;
    return `"${text.replace(/"/g, '""')}"`;
}

function buildReportCsv(report) {
    const lines = [];
    const metadataRow = (label, value, extra = '') => {
        lines.push([label, value, extra].map(csvCell).join(','));
    };
    const section = (title, headers, rows) => {
        lines.push('', csvCell(title));
        lines.push(headers.map(csvCell).join(','));
        rows.forEach(row => lines.push(row.map(csvCell).join(',')));
        if (!rows.length) lines.push(csvCell('No records for this report period.'));
        lines.push('');
    };

    lines.push(csvCell(report.organization));
    lines.push(csvCell(report.system));
    lines.push(csvCell(report.title));
    lines.push('');
    metadataRow('Report period', `${report.periodStart} to ${report.periodEnd}`);
    metadataRow('Generated at', report.generatedAt);
    metadataRow('Generated by', report.generatedBy, report.generatedByUsername);
    metadataRow('Record coverage', 'Process activity is available from activity-ledger rollout onward. Inventory values are a current snapshot at generation time.');

    const metric = report.metrics;
    section('EXECUTIVE SUMMARY', ['Metric', 'Value', 'Basis'], [
        ['Requests created in period', metric.totalRequests, 'Request creation date'],
        ['Approved requests', metric.approved, 'Current request status'],
        ['Pending requests', metric.pendingRequests, 'Current request status'],
        ['Declined requests', metric.declined, 'Current request status'],
        ['Approval rate', `${metric.approvalRate}%`, 'Approved / requests created in period'],
        ['Inventory stock health', `${metric.stockHealth}%`, 'Current inventory snapshot'],
        ['Low stock item count', metric.lowStock, 'Current inventory snapshot'],
        ['Out of stock item count', metric.outOfStock, 'Current inventory snapshot'],
        ['Recorded process events', report.events.length, 'Activity timestamps within report period'],
        ['Inventory item count', report.inventoryRows.length, 'Current inventory snapshot'],
    ]);

    section('REQUEST AND DELIVERY ITEM RECORDS', [
        'RIS Number', 'Request ID', 'Requested at', 'Province / office', 'Item', 'Unit', 'Quantity', 'Stock status at request',
        'Request status', 'Approver', 'Reviewed at', 'Package ID', 'Delivery status', 'Courier', 'Delivered at', 'Remarks'
    ], report.requestRows.map(row => [
        row.risNumber, row.requestId, row.requestDate, row.province, row.itemName, row.unit, row.quantity,
        row.stockStatus, row.requestStatus, row.approver, row.approvedDate, row.deliveryPackage,
        row.deliveryStatus, row.deliveredBy, row.deliveredDate, row.remarks
    ]));

    section('RECORDED PROCESS ACTIVITY', [
        'Event ID', 'Event timestamp', 'Event type', 'Entity type', 'Entity ID', 'Province', 'Actor', 'Actor role', 'Summary', 'Details'
    ], report.events.map(event => [
        event.id, event.created_at, event.event_type, event.entity_type, event.entity_id,
        event.province || 'System-wide', event.actor_username, event.actor_role, event.summary,
        formatActivityDetails(event.details)
    ]));

    section('SUPPLY INVENTORY SNAPSHOT', [
        'Item ID', 'Item name', 'Category', 'Unit', 'Quantity on hand', 'Minimum stock', 'Stock status', 'Last modified'
    ], report.inventoryRows.map(item => [
        item.itemId, item.itemName, item.category, item.unit, item.quantityOnHand,
        item.minimumStock, item.stockStatus, item.lastModified
    ]));

    return `\uFEFF${lines.join('\r\n')}`;
}

function buildReportWorkbook(report) {
    if (!window.XLSX) throw new Error('Excel export is not available. Please check your internet connection.');

    const workbook = window.XLSX.utils.book_new();
    const addSheet = (name, rows, widths) => {
        const sheet = window.XLSX.utils.aoa_to_sheet(rows);
        sheet['!cols'] = widths.map(width => ({ wch: width }));
        window.XLSX.utils.book_append_sheet(workbook, sheet, name);
    };
    const metric = report.metrics;

    addSheet('Executive Summary', [
        [report.title],
        ['Organization', report.organization],
        ['System', report.system],
        ['Report period', `${report.periodStart} to ${report.periodEnd}`],
        ['Generated at', report.generatedAt],
        ['Generated by', report.generatedBy, report.generatedByUsername],
        [],
        ['Metric', 'Value', 'Basis'],
        ['Requests created in period', metric.totalRequests, 'Request creation date'],
        ['Approved requests', metric.approved, 'Current request status'],
        ['Pending requests', metric.pendingRequests, 'Current request status'],
        ['Declined requests', metric.declined, 'Current request status'],
        ['Approval rate', `${metric.approvalRate}%`, 'Approved / requests created in period'],
        ['Inventory stock health', `${metric.stockHealth}%`, 'Current inventory snapshot'],
        ['Low stock item count', metric.lowStock, 'Current inventory snapshot'],
        ['Out of stock item count', metric.outOfStock, 'Current inventory snapshot'],
        ['Recorded process activities', report.events.length, 'Activity timestamps within report period'],
        ['Inventory item count', report.inventoryRows.length, 'Current inventory snapshot'],
    ], [34, 24, 48]);

    addSheet('Request Delivery', [
        ['RIS Number', 'Request ID', 'Requested at', 'Province / office', 'Item', 'Unit', 'Quantity', 'Stock status at request', 'Request status', 'Approver', 'Reviewed at', 'Package ID', 'Delivery status', 'Courier', 'Delivered at', 'Remarks'],
        ...report.requestRows.map(row => [
            row.risNumber, row.requestId, row.requestDate, row.province, row.itemName, row.unit, row.quantity,
            row.stockStatus, row.requestStatus, row.approver, row.approvedDate, row.deliveryPackage,
            row.deliveryStatus, row.deliveredBy, row.deliveredDate, row.remarks
        ])
    ], [18, 10, 20, 22, 28, 12, 10, 20, 18, 20, 20, 16, 18, 20, 20, 30]);

    addSheet('Process Activity', [
        ['Event ID', 'Event timestamp', 'Event type', 'Entity type', 'Entity ID', 'Province', 'Actor', 'Actor role', 'Summary', 'Details'],
        ...report.events.map(event => [
            event.id, event.created_at, event.event_type, event.entity_type, event.entity_id,
            event.province || 'System-wide', event.actor_username, event.actor_role, event.summary,
            formatActivityDetails(event.details)
        ])
    ], [10, 22, 24, 16, 14, 18, 20, 14, 34, 60]);

    addSheet('Inventory Snapshot', [
        ['Item ID', 'Item name', 'Category', 'Unit', 'Quantity on hand', 'Minimum stock', 'Stock status', 'Last modified'],
        ...report.inventoryRows.map(item => [
            item.itemId, item.itemName, item.category, item.unit, item.quantityOnHand,
            item.minimumStock, item.stockStatus, item.lastModified
        ])
    ], [10, 28, 24, 12, 18, 16, 16, 18]);

    return window.XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
}

async function recordReportExport(type, startDate, endDate) {
    const response = await fetch(`${reportApiBase}?action=export`, {
        method: 'POST',
        credentials: 'include',
        headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
            type,
            start_date: reportDateInputValue(startDate),
            end_date: reportDateInputValue(endDate),
        })
    });
    const payload = await response.json();
    if (!response.ok || !payload.success) throw new Error(payload.message || 'Could not record report export.');
    const { start, end } = getReportRangeDates(currentReportRange);
    loadReportActivity(start, end, reportActivityOffset);
}

confirmReportDownloadBtn && (confirmReportDownloadBtn.onclick = async () => {
    const type = reportDownloadModal?.dataset.exportType || 'csv';
    const range = reportDownloadRangeSelect?.value || 'monthly';

    let startDate = null;
    let endDate = null;
    if (range === 'custom') {
        if (!reportStartDateInput.value || !reportEndDateInput.value) {
            showToast('Please choose start and end dates for custom range.', 'error');
            return;
        }
        startDate = new Date(reportStartDateInput.value);
        endDate = new Date(reportEndDateInput.value);
        endDate.setHours(23, 59, 59, 999);
        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime()) || startDate > endDate) {
            showToast('Invalid custom date range.', 'error');
            return;
        }
    } else if (range === 'monthly') {
        const month = Number(reportMonthSelect?.value);
        const year = Number(reportMonthYearInput?.value);
        if (!Number.isInteger(month) || month < 0 || month > 11 || !Number.isInteger(year) || year < 2000 || year > 2100) {
            showToast('Choose a valid month and year.', 'error');
            return;
        }
        startDate = new Date(year, month, 1, 0, 0, 0, 0);
        endDate = new Date(year, month + 1, 0, 23, 59, 59, 999);
    } else if (range === 'yearly') {
        const year = Number(reportYearInput?.value);
        if (!Number.isInteger(year) || year < 2000 || year > 2100) {
            showToast('Choose a valid year.', 'error');
            return;
        }
        startDate = new Date(year, 0, 1, 0, 0, 0, 0);
        endDate = new Date(year, 11, 31, 23, 59, 59, 999);
    } else {
        const computed = computeRangeDates(range);
        startDate = computed.start;
        endDate = computed.end;
    }

    // Prepare filename suffix
    const s = formatIsoDate(startDate);
    const e = formatIsoDate(endDate);
    let reportFilename;
    if (range === 'monthly') {
        const monthName = startDate.toLocaleString('en-US', { month: 'long' });
        reportFilename = `reports-record_${monthName}_${startDate.getFullYear()}`;
    } else if (range === 'yearly') {
        reportFilename = `reports-record_${startDate.getFullYear()}`;
    } else {
        reportFilename = s === e ? `reports-record_${s}` : `reports-record_${s}_to_${e}`;
    }
    let reportEvents;
    try {
        reportEvents = await fetchAllReportActivityEvents(startDate, endDate);
    } catch (error) {
        showToast(error.message || 'Could not load activity records for export.', 'error');
        return;
    }
    if (type === 'xlsx') {
        const report = buildReportTemplate(startDate, endDate, reportEvents);
        const workbookBytes = buildReportWorkbook(report);
        const workbookBlob = new Blob([workbookBytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const workbookUrl = URL.createObjectURL(workbookBlob);
        const workbookLink = document.createElement('a');
        workbookLink.href = workbookUrl;
        workbookLink.download = `${reportFilename}.xlsx`;
        document.body.appendChild(workbookLink);
        workbookLink.click();
        workbookLink.remove();
        URL.revokeObjectURL(workbookUrl);
        try { await recordReportExport(type, startDate, endDate); } catch (error) { showToast(error.message, 'warning'); }
        showToast('Excel workbook download started.', 'success');
    } else if (type === 'csv') {
        const report = buildReportTemplate(startDate, endDate, reportEvents);
        downloadCsv(`${reportFilename}.csv`, buildReportCsv(report));
        try { await recordReportExport(type, startDate, endDate); } catch (error) { showToast(error.message, 'warning'); }
        showToast('CSV download started.', 'success');
    } else {
        if (!window.jspdf || !window.jspdf.jsPDF) {
            showToast('PDF export is not available. Please check your internet connection.', 'error');
            return;
        }
        const report = buildReportTemplate(startDate, endDate, reportEvents);
        generateReportPdfForRange(report, `${reportFilename}.pdf`);
        try { await recordReportExport(type, startDate, endDate); } catch (error) { showToast(error.message, 'warning'); }
    }

    closeReportDownloadModal();
});

function computeRangeDates(range) {
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
    let start = new Date(end);
    if (range === 'daily') {
        start = new Date(end.getFullYear(), end.getMonth(), end.getDate(), 0, 0, 0);
    } else if (range === 'weekly') {
        start.setDate(start.getDate() - 6);
        start.setHours(0,0,0,0);
    } else if (range === 'monthly') {
        start.setDate(start.getDate() - 29);
        start.setHours(0,0,0,0);
    } else if (range === 'yearly') {
        start = new Date(end.getFullYear(), 0, 1, 0, 0, 0);
    } else {
        // default to last 30 days
        start.setDate(start.getDate() - 29);
        start.setHours(0,0,0,0);
    }
    return { start, end };
}

function formatIsoDate(d) {
    if (!d) return '';
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}${m}${day}`;
}

function getDeliveryForRequest(requestId) {
    return deliveriesData.find(d => String(d.request_id) === String(requestId)) || null;
}

function formatReportDate(value) {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleDateString('en-US');
}

function summarizeRequestItems(req) {
    if (!req) return '';
    if (req.item_details) {
        try {
            const parsed = JSON.parse(req.item_details);
            if (Array.isArray(parsed) && parsed.length) {
                return parsed.map(item => {
                    const name = item.item_name || item.name || '';
                    const qty = item.quantity || item.qty || 0;
                    return `${name} x${qty}`;
                }).join('; ');
            }
        } catch (err) {
            // continue with fallback
        }
    }
    return `${req.item_name || 'N/A'} x${req.quantity || 0}`;
}

function getDetailedReportRows(startDate, endDate) {
    const rangeStart = startDate ? new Date(startDate) : null;
    const rangeEnd = endDate ? new Date(endDate) : null;
    return (requestsData || []).filter(req => {
        if (!req.request_date) return false;
        const requestDate = new Date(req.request_date);
        if (Number.isNaN(requestDate.getTime())) return false;
        if (rangeStart && requestDate < rangeStart) return false;
        if (rangeEnd && requestDate > rangeEnd) return false;
        return true;
    }).sort((a, b) => new Date(a.request_date) - new Date(b.request_date)).map(req => {
        const delivery = getDeliveryForRequest(req.id);
        return {
            requestId: req.id || '',
            risNumber: formatRisNumber(req.id, req.ris_number),
            requestDate: formatReportDate(req.request_date),
            requestedBy: req.requestor || '',
            items: summarizeRequestItems(req),
            quantity: req.quantity || '',
            stockStatus: req.stock_status || '',
            requestStatus: req.status || '',
            approver: req.approver || '',
            approvedDate: formatReportDate(req.approved_date),
            deliveryStatus: delivery?.status || '',
            deliveryPackage: delivery?.package_id || '',
            deliveredBy: delivery?.courier_name || '',
            deliveredDate: formatReportDate(delivery?.completed_at || delivery?.delivered_at),
            remarks: req.remarks || req.note || ''
        };
    });
}

function generateReportPdfForRange(report, filename) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'pt', format: 'a4', orientation: 'landscape' });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 34;
    const contentWidth = pageWidth - margin * 2;
    const footerY = pageHeight - 22;
    let cursorY = 0;

    const drawPageHeader = () => {
        doc.setFillColor(20, 72, 93);
        doc.rect(0, 0, pageWidth, 7, 'F');
        doc.setTextColor(29, 57, 71);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text(report.organization.toUpperCase(), margin, 27);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(105, 115, 125);
        doc.setFontSize(8);
        doc.text(report.system, pageWidth - margin, 27, { align: 'right' });
        doc.setDrawColor(218, 225, 231);
        doc.line(margin, 36, pageWidth - margin, 36);
    };
    const newPage = () => {
        doc.addPage();
        drawPageHeader();
        cursorY = 54;
    };
    const ensureSpace = height => {
        if (cursorY + height > footerY - 8) newPage();
    };
    const drawSectionTitle = title => {
        ensureSpace(30);
        doc.setFillColor(235, 241, 245);
        doc.roundedRect(margin, cursorY, contentWidth, 23, 3, 3, 'F');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(29, 57, 71);
        doc.text(title.toUpperCase(), margin + 9, cursorY + 15);
        cursorY += 32;
    };
    const drawTable = (headers, rows, widths, fontSize = 7.2) => {
        const headerHeight = 24;
        const drawTableHeader = () => {
            ensureSpace(headerHeight + 8);
            doc.setFillColor(29, 57, 71);
            doc.rect(margin, cursorY, contentWidth, headerHeight, 'F');
            let x = margin;
            headers.forEach((header, index) => {
                const cellWidth = widths[index] * contentWidth;
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(fontSize);
                doc.setTextColor(255, 255, 255);
                const lines = doc.splitTextToSize(String(header), cellWidth - 8).slice(0, 2);
                doc.text(lines, x + 4, cursorY + (lines.length > 1 ? 9 : 15));
                x += cellWidth;
            });
            cursorY += headerHeight;
        };

        if (!rows.length) {
            ensureSpace(23);
            doc.setFont('helvetica', 'italic');
            doc.setFontSize(8);
            doc.setTextColor(105, 115, 125);
            doc.text('No records for this report period.', margin + 2, cursorY + 11);
            cursorY += 20;
            return;
        }

        drawTableHeader();
        rows.forEach((row, rowIndex) => {
            const cellLines = row.map((value, index) => doc.splitTextToSize(String(value ?? '—'), widths[index] * contentWidth - 8));
            const lineCount = Math.max(1, ...cellLines.map(lines => lines.length));
            const rowHeight = Math.max(22, lineCount * (fontSize + 2) + 8);
            if (cursorY + rowHeight > footerY - 8) {
                newPage();
                drawTableHeader();
            }
            if (rowIndex % 2 === 0) {
                doc.setFillColor(248, 250, 251);
                doc.rect(margin, cursorY, contentWidth, rowHeight, 'F');
            }
            doc.setDrawColor(226, 231, 235);
            doc.line(margin, cursorY + rowHeight, margin + contentWidth, cursorY + rowHeight);
            let x = margin;
            row.forEach((value, index) => {
                const cellWidth = widths[index] * contentWidth;
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(fontSize);
                doc.setTextColor(48, 58, 66);
                doc.text(cellLines[index], x + 4, cursorY + 12, { maxWidth: cellWidth - 8 });
                x += cellWidth;
            });
            cursorY += rowHeight;
        });
        cursorY += 8;
    };

    drawPageHeader();
    cursorY = 63;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(29, 57, 71);
    doc.setFontSize(21);
    doc.text(report.title, margin, cursorY);
    cursorY += 19;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(92, 103, 112);
    doc.setFontSize(9);
    doc.text(`Reporting period: ${report.periodStart} to ${report.periodEnd}`, margin, cursorY);
    doc.text(`Generated: ${report.generatedAt}`, margin + 255, cursorY);
    doc.text(`Prepared by: ${report.generatedBy}`, pageWidth - margin, cursorY, { align: 'right' });
    cursorY += 16;
    doc.setFontSize(7.5);
    doc.setTextColor(105, 115, 125);
    doc.text(`Account: ${report.generatedByUsername || '—'} | Process records begin with activity-ledger rollout; inventory is a current snapshot.`, margin, cursorY);
    cursorY += 12;
    doc.setDrawColor(218, 225, 231);
    doc.line(margin, cursorY, pageWidth - margin, cursorY);
    cursorY += 15;

    const metricRows = [
        ['Requests created in period', report.metrics.totalRequests, 'Creation date within selected period'],
        ['Approved / pending / declined', `${report.metrics.approved} / ${report.metrics.pendingRequests} / ${report.metrics.declined}`, 'Current status of requests created in period'],
        ['Approval rate', `${report.metrics.approvalRate}%`, 'Approved divided by requests created in period'],
        ['Stock health', `${report.metrics.stockHealth}%`, 'Current inventory snapshot at report generation'],
        ['Low / out of stock items', `${report.metrics.lowStock} / ${report.metrics.outOfStock}`, 'Current inventory snapshot'],
        ['Recorded process events', report.events.length, 'Events recorded within selected period'],
    ];
    drawSectionTitle('Executive summary');
    drawTable(['Measure', 'Result', 'Definition'], metricRows, [0.27, 0.18, 0.55], 8);

    drawSectionTitle(`Request and delivery item records (${report.requestRows.length} item rows)`);
    drawTable(
        ['RIS / date', 'Province', 'Requested item', 'Qty / unit', 'Request / stock', 'Approver / reviewed', 'Package / status', 'Courier / delivered', 'Remarks'],
        report.requestRows.map(row => [
            `${row.risNumber} / ${row.requestDate}`,
            row.province,
            row.itemName,
            `${row.quantity} ${row.unit}`.trim(),
            `${row.requestStatus} / ${row.stockStatus}`,
            `${row.approver || '—'} / ${row.approvedDate || '—'}`,
            `${row.deliveryPackage || '—'} / ${row.deliveryStatus || '—'}`,
            `${row.deliveredBy || '—'} / ${row.deliveredDate || '—'}`,
            row.remarks,
        ]),
        [0.12, 0.09, 0.15, 0.07, 0.12, 0.14, 0.12, 0.12, 0.07],
        6.6
    );

    drawSectionTitle(`Recorded process activity (${report.events.length} events)`);
    drawTable(
        ['Timestamp', 'Process / record', 'Province', 'Performed by', 'Summary', 'Event details'],
        report.events.map(event => [
            event.created_at,
            `${event.event_type} / ${event.entity_type} ${event.entity_id || ''}`,
            event.province || 'System-wide',
            `${event.actor_username || 'System'} (${event.actor_role || '—'})`,
            event.summary,
            formatActivityDetails(event.details),
        ]),
        [0.13, 0.17, 0.10, 0.16, 0.20, 0.23],
        6.8
    );

    drawSectionTitle(`Supply inventory snapshot (${report.inventoryRows.length} items)`);
    drawTable(
        ['Item ID', 'Item', 'Category', 'Unit', 'On hand', 'Minimum', 'Status', 'Last modified'],
        report.inventoryRows.map(item => [
            item.itemId, item.itemName, item.category, item.unit,
            item.quantityOnHand, item.minimumStock, item.stockStatus, item.lastModified,
        ]),
        [0.07, 0.22, 0.20, 0.09, 0.10, 0.10, 0.12, 0.10],
        7.2
    );

    const pageCount = doc.internal.getNumberOfPages();
    for (let page = 1; page <= pageCount; page++) {
        doc.setPage(page);
        doc.setDrawColor(218, 225, 231);
        doc.line(margin, footerY, pageWidth - margin, footerY);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.setTextColor(105, 115, 125);
        doc.text('System activity is available from activity-ledger rollout onward. Inventory values are a current snapshot.', margin, footerY + 12);
        doc.text(`Page ${page} of ${pageCount}`, pageWidth - margin, footerY + 12, { align: 'right' });
    }

    doc.save(filename || 'dole-system-report.pdf');
    showToast('PDF report generated.', 'success');
    return {
        pageCount,
        requestRows: report.requestRows.length,
        eventRows: report.events.length,
        inventoryRows: report.inventoryRows.length,
    };
}

function addWrappedText(doc, text, x, y, maxWidth, fontSize, lineHeight) {
    doc.setFontSize(fontSize);
    const lines = doc.splitTextToSize(String(text), maxWidth);
    lines.forEach(line => {
        if (y > 760) {
            doc.addPage();
            y = 40;
        }
        doc.text(line, x, y);
        y += lineHeight;
    });
    return y;
}

function downloadCsv(filename, csvText) {
    const blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

function generateReportPdf() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    const title = document.querySelector('.report-chart-header h4')?.textContent || 'Report Summary';
    const subtitle = document.querySelector('.reports-title p')?.textContent || '';
    const metrics = [
        ['Total Requests', document.getElementById('reportTotalRequests')?.textContent || '0'],
        ['Approval Rate', document.getElementById('reportApprovalRate')?.textContent || '0%'],
        ['Stock Health', document.getElementById('reportStockHealth')?.textContent || '0%'],
        ['Pending Requests', document.getElementById('reportPendingRequests')?.textContent || '0']
    ];
    const highlights = Array.from(document.querySelectorAll('#reportList li')).map(li => {
        const titleEl = li.querySelector('.report-list-title');
        const descEl = li.querySelector('.report-list-note');
        const valueEl = li.querySelector('strong');
        return {
            title: titleEl?.textContent.trim() || '',
            description: descEl?.textContent.trim() || '',
            value: valueEl?.textContent.trim() || ''
        };
    });

    doc.setFontSize(20);
    doc.text(title, 40, 50);
    doc.setFontSize(11);
    doc.setTextColor('#666');
    doc.text(subtitle, 40, 70);
    doc.setTextColor('#000');

    doc.setFontSize(12);
    doc.text('Key Metrics', 40, 110);
    let cursorY = 130;
    metrics.forEach(([label, value]) => {
        doc.setFontSize(10);
        doc.text(label, 40, cursorY);
        doc.setFontSize(10);
        doc.text(value, 320, cursorY);
        cursorY += 20;
    });

    cursorY += 10;
    doc.setFontSize(12);
    doc.text('Highlights', 40, cursorY);
    cursorY += 20;

    highlights.forEach(item => {
        doc.setFontSize(10);
        doc.text(`• ${item.title}: ${item.value}`, 40, cursorY);
        cursorY += 16;
        doc.setFontSize(9);
        doc.setTextColor('#555');
        doc.text(item.description, 55, cursorY);
        doc.setTextColor('#000');
        cursorY += 20;
        if (cursorY > 720) {
            doc.addPage();
            cursorY = 40;
        }
    });

    doc.save('report-summary.pdf');
    showToast('Report PDF download started.', 'success');
}

// --- USER MANAGEMENT LOGIC ---
function renderUsers() {
    const table = document.getElementById("userTable");
    if (!table) return;

    table.innerHTML = "";

    // sort a copy of usersData according to current sort state
    const sortedUsers = sortUsersArray(usersData || []);

    document.getElementById("totalUserCount").textContent = (usersData || []).length;
    const currentUser = window.currentAdminUser || '';

    sortedUsers.forEach(user => {
        const roleKey = String(user.role || '').toLowerCase();
        let roleClass = 'role-requester';
        let roleLabel = user.role;
        if (roleKey === 'admin') {
            roleClass = 'role-admin';
            roleLabel = 'Admin';
        } else if (roleKey === 'approver') {
            roleClass = 'role-approver';
            roleLabel = 'Approver';
        } else if (roleKey === 'delivery') {
            roleClass = 'role-delivery';
            roleLabel = 'Delivery';
        } else if (roleKey === 'requester' || roleKey === 'provincial' || roleKey === 'requestor') {
            roleClass = 'role-requester';
            roleLabel = 'Requester';
        }
        const statusKey = String(user.status || 'Operational').toLowerCase();
        const statusClass = statusKey === 'operational' ? 'status-operational' : 'status-not-operational';
        const statusLabel = statusKey === 'operational' ? 'Operational' : 'Not Operational';
        const currentClass = user.username === currentUser ? 'user-current' : '';
        const avatar = user.avatar || localStorage.getItem('avatar_' + (user.username || user.email || '')) || '';
        const avatarStyle = avatar ? `style="background-image:url(${avatar}); background-size:cover;"` : '';
        const lastActive = user.lastActive || '—';
        const lastActiveParts = String(lastActive).split(',');
        const lastActiveMain = lastActiveParts[0] || lastActive;
        const lastActiveTime = lastActiveParts[1] ? `<div class="user-email">${lastActiveParts[1].trim()}</div>` : '';
        
        table.innerHTML += `
            <tr class="${currentClass}">
                <td>
                    <div class="user-info">
                        <div class="user-avatar" ${avatarStyle}></div>
                        <div class="user-details">
                            <div class="user-name">${user.name}</div>
                            <div class="user-email">${user.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="role-badge ${roleClass}">${roleLabel}</span></td>
                <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                <td>${user.province}</td>
                <td><div>${lastActiveMain}</div>${lastActiveTime}</td>
                <td>${user.dateAdded}</td>
                <td>
                    <div class="user-action-cell">
                        <button class="status-toggle-btn ${statusKey === 'operational' ? 'status-operational' : 'status-not-operational'}" data-username="${user.username}" title="Toggle operational status"></button>
                        <div class="user-options-wrapper">
                            <button class="user-options-btn" data-username="${user.username}" title="More actions">⋮</button>
                            <div class="user-action-menu hidden" data-username="${user.username}">
                                <button type="button" class="user-action-menu-item" data-action="edit" data-username="${user.username}">Edit information</button>
                                <button type="button" class="user-action-menu-item" data-action="status" data-username="${user.username}">Status: ${statusLabel}</button>
                                <button type="button" class="user-action-menu-item user-action-delete" data-action="delete" data-username="${user.username}">Delete user</button>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    });

    table.querySelectorAll('.status-toggle-btn').forEach(btn => {
        btn.onclick = async (e) => {
            e.stopPropagation();
            const username = btn.dataset.username;
            const user = usersData.find(entry => entry.username === username);
            if (!user) return;
            const newStatus = user.status === 'Not Operational' ? 'Operational' : 'Not Operational';
            await updateUserStatus(username, newStatus);
        };
    });

    table.querySelectorAll('.user-options-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const username = btn.dataset.username;
            const menu = btn.parentElement.querySelector('.user-action-menu');
            if (!menu) return;
            const isOpen = !menu.classList.contains('hidden');
            document.querySelectorAll('.user-action-menu').forEach(m => m.classList.add('hidden'));
            if (!isOpen) {
                menu.classList.remove('hidden');
            }
        };
    });

    table.querySelectorAll('.user-action-menu-item').forEach(item => {
        item.onclick = (e) => {
            e.stopPropagation();
            const action = item.dataset.action;
            const username = item.dataset.username;
            document.querySelectorAll('.user-action-menu').forEach(m => m.classList.add('hidden'));
            if (action === 'edit') {
                openEditUserModal(username);
            } else if (action === 'status') {
                openUserStatusPrompt(username);
            } else if (action === 'delete') {
                deleteUser(username);
            }
        };
    });
}

document.addEventListener('click', () => {
    document.querySelectorAll('.user-action-menu').forEach(m => m.classList.add('hidden'));
});

function compareStrings(a, b) {
    if (a === null || a === undefined) a = '';
    if (b === null || b === undefined) b = '';
    return String(a).toLowerCase().localeCompare(String(b).toLowerCase());
}

function openUserStatusPrompt(username) {
    const user = usersData.find(entry => entry.username === username);
    if (!user) return;
    const currentStatus = user.status || 'Operational';
    const incoming = window.prompt(
        `Set status for ${username} (Operational or Not Operational):`,
        currentStatus
    );
    if (!incoming) return;
    const selected = incoming.trim();
    if (!['Operational', 'Not Operational'].includes(selected)) {
        alert('Please enter either Operational or Not Operational.');
        return;
    }
    updateUserStatus(username, selected);
}

async function updateUserStatus(username, status) {
    const user = usersData.find(entry => entry.username === username);
    if (!user) return;

    try {
        const response = await fetch(`${loginApiBase}/update_user.php`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({
                username,
                fullname: user.name,
                email: user.email,
                role: user.role,
                province: user.province,
                status
            })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || `Unable to update status (HTTP ${response.status})`);
        }

        await fetchUsers();
        renderUsers();
        showToast(`User ${username} status updated to ${status}.`, 'success');
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not update user status.', 'error');
    }
}

function parseDateForSort(raw) {
    if (!raw) return null;
    // try to normalize common formats
    try {
        const normalized = String(raw).replace(' ', 'T');
        const t = Date.parse(normalized);
        return Number.isNaN(t) ? null : t;
    } catch (e) {
        return null;
    }
}

function sortUsersArray(arr) {
    if (!Array.isArray(arr)) return [];
    if (!usersSortField) return arr.slice();

    const copy = arr.slice();
    copy.sort((u1, u2) => {
        let a, b;
        switch (usersSortField) {
            case 'name':
                a = u1.name; b = u2.name; return compareStrings(a, b) * (usersSortDir === 'asc' ? 1 : -1);
            case 'role':
                a = u1.role; b = u2.role; return compareStrings(a, b) * (usersSortDir === 'asc' ? 1 : -1);
            case 'province':
                a = u1.province; b = u2.province; return compareStrings(a, b) * (usersSortDir === 'asc' ? 1 : -1);
            case 'lastActive':
                a = parseDateForSort(u1.lastLoginRaw) || (u1.lastActive === 'Never' ? 0 : 0);
                b = parseDateForSort(u2.lastLoginRaw) || (u2.lastActive === 'Never' ? 0 : 0);
                // treat null as 0 so they appear last when sorting desc
                if (a === b) return 0;
                return (a - b) * (usersSortDir === 'asc' ? 1 : -1);
            case 'dateAdded':
                a = parseDateForSort(u1.createdAtRaw) || 0;
                b = parseDateForSort(u2.createdAtRaw) || 0;
                if (a === b) return 0;
                return (a - b) * (usersSortDir === 'asc' ? 1 : -1);
            default:
                return 0;
        }
    });
    return copy;
}

function initUserTableSorting() {
    const headers = document.querySelectorAll('.user-table thead th[data-sort]');
    headers.forEach(h => {
        h.style.cursor = 'pointer';
        h.onclick = () => {
            const field = h.dataset.sort;
            if (usersSortField === field) {
                usersSortDir = usersSortDir === 'asc' ? 'desc' : 'asc';
            } else {
                usersSortField = field;
                usersSortDir = 'asc';
            }
            // update indicators
            document.querySelectorAll('.user-table thead th .sort-indicator').forEach(si => si.textContent = '');
            const ind = h.querySelector('.sort-indicator');
            if (ind) ind.textContent = usersSortDir === 'asc' ? '▲' : '▼';
            renderUsers();
        };
    });
}

async function deleteUser(username) {
    if (!username) return;
    if (!confirm(`Delete account ${username}? This action cannot be undone.`)) return;

    try {
        const response = await fetch(`${loginApiBase}/delete_user.php`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ username })
        });

        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || `Unable to delete user (HTTP ${response.status})`);
        }

        await fetchUsers();
        renderUsers();
        showToast(`User ${username} deleted successfully.`, 'success');
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not delete user.', 'error');
    }
}

const addUserModal = document.getElementById("addUserModal");
const closeAddUserModalBtn = document.getElementById("closeAddUserModal");
const cancelAddUserBtn = document.getElementById("cancelAddUserBtn");
const saveUserBtn = document.getElementById("saveUserBtn");
let editingUsername = null;

async function fetchUsers() {
    try {
        const response = await fetch(`${loginApiBase}/get_users.php`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            let errorText = 'Unable to load users';
            try {
                const errJson = await response.json();
                errorText = errJson.message || errorText;
            } catch (fetchError) {
                errorText = `${errorText} (HTTP ${response.status})`;
            }
            throw new Error(errorText);
        }

        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message || 'Unable to load users');
        }

        usersData = data.data.map(user => ({
            username: user.username,
            name: user.full_name,
            email: user.email,
            role: user.role,
            province: user.province,
            status: user.status || 'Operational',
            // keep raw timestamps for accurate sorting and formatted strings for display
            lastLoginRaw: user.last_login || null,
            createdAtRaw: user.created_at || null,
            lastActive: user.last_login ? formatDateTime(user.last_login) : 'Never',
            dateAdded: formatDateTime(user.created_at)
        }));
    } catch (error) {
        console.error(error);
        alert(`Could not load users from the database. Please refresh the page.\n${error.message}`);
    }
}

function formatDateTime(value) {
    if (!value) return 'Never';
    const normalized = value.replace(' ', 'T');
    const date = new Date(normalized);
    return date.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function openAddUserModal() {
    editingUsername = null;
    addUserModal.classList.add("active");
    clearAddUserForm();
    document.getElementById("newUserUsername").focus();
    document.getElementById("saveUserBtn").textContent = 'Create';
}

function openEditUserModal(username) {
    const user = usersData.find(entry => entry.username === username);
    if (!user) return;

    editingUsername = username;
    addUserModal.classList.add("active");
    document.getElementById("newUserUsername").value = user.username;
    document.getElementById("newUserPassword").value = "";
    document.getElementById("newUserEmail").value = user.email || "";
    document.getElementById("newUserFullname").value = user.name || "";
    document.getElementById("newUserRole").value = user.role || "Requester";
    document.getElementById("newUserProvince").value = user.province || "";
    document.getElementById("newUserUsername").readOnly = true;
    document.getElementById("saveUserBtn").textContent = 'Save';
    document.getElementById("newUserFullname").focus();
}

function closeAddUserModal() {
    addUserModal.classList.remove("active");
    clearAddUserForm();
}

function clearAddUserForm() {
    editingUsername = null;
    document.getElementById("newUserUsername").readOnly = false;
    document.getElementById("newUserUsername").value = "";
    document.getElementById("newUserPassword").value = "";
    document.getElementById("newUserEmail").value = "";
    document.getElementById("newUserFullname").value = "";
    document.getElementById("newUserRole").value = "Admin";
    document.getElementById("newUserProvince").value = "CAVITE";
    document.getElementById("saveUserBtn").textContent = 'Create';
}

document.getElementById("addUserBtn").onclick = openAddUserModal;
closeAddUserModalBtn.onclick = closeAddUserModal;
cancelAddUserBtn.onclick = closeAddUserModal;
addUserModal.onclick = (e) => {
    if (e.target.id === "addUserModal") {
        closeAddUserModal();
    }
};

saveUserBtn.onclick = async () => {
    const username = document.getElementById("newUserUsername").value.trim();
    const password = document.getElementById("newUserPassword").value;
    const email = document.getElementById("newUserEmail").value.trim();
    const fullname = document.getElementById("newUserFullname").value.trim();
    const role = document.getElementById("newUserRole").value;
    const province = document.getElementById("newUserProvince").value.trim();

    if (!username || !email || !fullname || !role || !province) {
        alert("Please fill in all required fields.");
        return;
    }

    if (editingUsername === null && !password) {
        alert("Please fill in all required fields.");
        return;
    }

    if (!email.toLowerCase().endsWith("@gmail.com")) {
        alert("Please use a valid Gmail address.");
        return;
    }

    try {
        const endpoint = editingUsername ? `${loginApiBase}/update_user.php` : `${loginApiBase}/add_user.php`;
        const method = editingUsername ? 'POST' : 'POST';
        const payload = editingUsername
            ? { username, password, email, fullname, role, province }
            : { username, password, email, fullname, role, province };

        const response = await fetch(endpoint, {
            method,
            credentials: 'include',
            headers: withCsrfHeaders({
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(payload)
        });

        let result;
        try {
            result = await response.json();
        } catch (jsonError) {
            result = null;
        }

        if (!response.ok || !result || !result.success) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            const errorMessage = result?.message || `Unable to ${editingUsername ? 'update' : 'add'} user (HTTP ${response.status})`;
            throw new Error(errorMessage);
        }

        await fetchUsers();
        renderUsers();
        closeAddUserModal();
        showToast(editingUsername ? 'User updated successfully.' : 'New user created successfully.', 'success');
    } catch (error) {
        showToast(error.message || `Could not ${editingUsername ? 'update' : 'add'} user.`, 'error');
        console.error(error);
    }
};

// --- NOTIFICATIONS LOGIC ---
const notificationBtn = document.getElementById("notificationBtn");
const notificationsPanel = document.getElementById("notificationsPanel");
const notificationOverlay = document.getElementById("notificationOverlay");
const closeNotificationsBtn = document.getElementById("closeNotifications");

function toggleNotifications() {
    if (!notificationsPanel || !notificationOverlay) return;

    notificationsPanel.classList.toggle("active");
    notificationOverlay.classList.toggle("active");
    if (notificationsPanel.classList.contains("active")) {
        renderNotifications("all");
        Promise.all([fetchInventory(), fetchRequests(), fetchPpmpData(), fetchDeliveries()]).then(() => {
            rebuildNotifications();
            renderNotifications(document.querySelector(".notif-tab.active")?.dataset.filter || 'all');
        });
    }
}

function closeNotifications() {
    notificationsPanel.classList.remove("active");
    notificationOverlay.classList.remove("active");
}

if (notificationBtn) notificationBtn.onclick = toggleNotifications;
if (closeNotificationsBtn) closeNotificationsBtn.onclick = closeNotifications;
if (notificationOverlay) notificationOverlay.onclick = closeNotifications;

document.querySelectorAll(".notif-tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".notif-tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        renderNotifications(tab.dataset.filter);
    };
});

document.getElementById('notificationSearchInput')?.addEventListener('input', () => {
    renderNotifications(document.querySelector(".notif-tab.active")?.dataset.filter || 'all');
});

function formatNotificationTime(value) {
    if (!value) return 'Now';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    const minutes = Math.max(0, Math.floor((Date.now() - date.getTime()) / 60000));
    if (minutes < 1) return 'Now';
    if (minutes < 60) return `${minutes}m ago`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
    return date.toLocaleDateString();
}

function rebuildNotifications() {
    const next = [];
    const add = (notification) => {
        const date = notification.date ? new Date(notification.date) : new Date();
        const targetPage = notification.targetPage || 'dashboard';
        const targetFilter = notification.targetFilter || 'all';
        next.push({
            ...notification,
            date,
            targetPage,
            targetFilter,
            time: formatNotificationTime(date),
            isToday: date.toDateString() === new Date().toDateString()
        });
    };

    requestsData.forEach(request => {
        const status = String(request.status || 'Pending');
        const item = summarizeRequestItems(request);
        const targetFilter = status === 'Pending' ? 'pending' : status === 'Approved' ? 'approved' : 'declined';
        add({
            type: status === 'Approved' ? 'success' : status === 'Declined' ? 'error' : 'info',
            category: 'request',
            targetPage: 'approvals',
            targetFilter,
            title: status === 'Pending' ? 'Request Awaiting Review' : `Request ${status}`,
            message: `${request.requestor || 'A requester'} submitted ${item}.`,
            date: request.approved_date || request.request_date,
            unread: status === 'Pending'
        });
    });

    inventoryData.forEach(item => {
        const stock = Number(item.stock) || 0;
        const minimum = Number(item.min_stock) || 0;
        if (stock <= 0) {
            add({ type: 'error', category: 'inventory', targetPage: 'inventory', targetFilter: 'all', title: 'Out of Stock', message: `${item.item_name} is out of stock.`, unread: true });
        } else if (stock <= minimum) {
            add({ type: 'warning', category: 'inventory', targetPage: 'inventory', targetFilter: 'all', title: 'Low Stock Alert', message: `${item.item_name} has ${stock} ${item.unit || 'unit'} left.`, unread: true });
        }
    });

    ppmpData.forEach(ppmp => {
        const status = String(ppmp.status || 'Pending');
        const targetFilter = status === 'Approved' ? 'approved' : status === 'Rejected' ? 'declined' : 'pending';
        add({
            type: status === 'Approved' ? 'success' : status === 'Rejected' ? 'error' : 'info',
            category: 'request',
            targetPage: 'approvals',
            targetFilter,
            title: `PPMP ${status === 'Approved' ? 'Accepted' : status}`,
            message: `${ppmp.file_name || `PPMP #${ppmp.id}`} from ${ppmp.province || 'an office'}.`,
            date: ppmp.reviewed_at || ppmp.uploaded_at,
            unread: status === 'Pending'
        });
    });

    notificationsData = next.sort((a, b) => b.date - a.date);
}

function renderNotifications(filter) {
    const todayNotif = document.getElementById("todayNotifications");
    const olderNotif = document.getElementById("olderNotifications");
    if (!todayNotif || !olderNotif) return;

    todayNotif.innerHTML = "";
    olderNotif.innerHTML = "";

    const allCount = notificationsData.length;
    const unreadCount = notificationsData.filter(n => n.unread !== false).length;
    const requestCount = notificationsData.filter(n => n.category === 'request').length;
    const inventoryCount = notificationsData.filter(n => n.category === 'inventory').length;
    const searchTerm = (document.getElementById('notificationSearchInput')?.value || '').trim().toLowerCase();
    const allCountEl = document.getElementById("notifCountAll");
    const unreadCountEl = document.getElementById("notifCountUnread");
    const requestCountEl = document.getElementById("notifCountRequest");
    const inventoryCountEl = document.getElementById("notifCountInventory");
    if (allCountEl) allCountEl.textContent = allCount;
    if (unreadCountEl) unreadCountEl.textContent = unreadCount;
    if (requestCountEl) requestCountEl.textContent = requestCount;
    if (inventoryCountEl) inventoryCountEl.textContent = inventoryCount;

    notificationsData.forEach(notif => {
        const isUnread = notif.unread !== false;
        if (filter === "unread" && !isUnread) return;
        if (filter === "request" && notif.category !== 'request') return;
        if (filter === "inventory" && notif.category !== 'inventory') return;
        if (filter !== "all" && filter !== "unread" && filter !== "request" && filter !== "inventory" && notif.category !== filter) return;
        if (searchTerm && !`${notif.title} ${notif.message}`.toLowerCase().includes(searchTerm)) return;
        
        const typeClass = notif.type === 'success' ? 'success' : notif.type === 'error' ? 'error' : 'info';
        const notifHTML = `
            <div class="notif-item ${typeClass} ${isUnread ? 'unread' : ''}" data-page="${notif.targetPage || 'dashboard'}" data-filter="${notif.targetFilter || 'all'}">
                <div class="notif-icon ${notif.type}"></div>
                <div class="notif-body">
                    <p class="notif-title">${notif.title}</p>
                    <p class="notif-message">${notif.message}</p>
                </div>
                <div class="notif-meta">
                    <p class="notif-time">${notif.time}</p>
                    ${isUnread ? '<div class="notif-indicator"></div>' : ''}
                </div>
            </div>
        `;
        
        const container = notif.isToday ? todayNotif : olderNotif;
        container.insertAdjacentHTML('beforeend', notifHTML);
    });

    document.querySelectorAll('.notif-item').forEach(item => {
        item.addEventListener('click', () => {
            const page = item.dataset.page || 'dashboard';
            const filter = item.dataset.filter || 'all';
            showPage(page);

            if (page === 'approvals') {
                const targetTab = document.querySelector(`.request-tab[data-filter="${filter}"]`);
                if (targetTab) targetTab.click();
                else renderRequests(filter);
            }

            if (page === 'inventory') {
                renderInventory(filter === 'all' ? 'all' : filter);
            }
        });
    });
}

const markAllReadBtn = document.getElementById("markAllReadBtn");
if (markAllReadBtn) {
    markAllReadBtn.onclick = () => {
        notificationsData.forEach(n => { n.unread = false; });
        renderNotifications(document.querySelector(".notif-tab.active")?.dataset.filter || "all");
    };
}

// --- DASHBOARD ARROWS ---
document.querySelectorAll(".dashboard-arrow").forEach(arrow => {
    arrow.onclick = (e) => {
        e.preventDefault();
        showPage(arrow.dataset.page);
        if(arrow.dataset.page === 'inventory') renderInventory(arrow.dataset.filter);
        if(arrow.dataset.page === 'approvals') {
            document.querySelector(`.request-tab[data-filter="${arrow.dataset.filter}"]`)?.click();
        }
    };
});

// --- API INTEGRATION HELPERS ---
// These functions serve as templates for connecting to your backend API.
// Uncomment and modify based on your backend endpoints.

/*
// Helper function for API requests with authentication
async function apiRequest(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if(session.token) {
        headers.Authorization = `Bearer ${session.token}`;
    }
    
    try {
        const response = await fetch(url, {
            ...options,
            headers
        });
        
        if(response.status === 401) {
            // Token expired or invalid
            logout();
            return null;
        }
        
        if(!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Request failed:', error);
        return null;
    }
}

// Fetch data from backend (replace hardcoded data)
async function loadAllData() {
    const baseURL = '/api'; // Update with your API URL
    
    // Fetch inventory
    const inventory = await apiRequest(`${baseURL}/inventory`);
    if(inventory) inventoryData = inventory;
    
    // Fetch requests
    const requests = await apiRequest(`${baseURL}/requests`);
    if(requests) requestsData = requests;
    
    // Fetch users
    const users = await apiRequest(`${baseURL}/users`);
    if(users) usersData = users;
    
    // Fetch activities
    const activities = await apiRequest(`${baseURL}/activities`);
    if(activities) activitiesData = activities;
}

// Add item to backend
async function addItemToBackend(itemData) {
    return await apiRequest('/api/inventory', {
        method: 'POST',
        body: JSON.stringify(itemData)
    });
}

// Approve/Decline request
async function updateRequestStatus(requestId, status, remarks) {
    return await apiRequest(`/api/requests/${requestId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, remarks })
    });
}

// Add user to backend
async function addUserToBackend(userData) {
    return await apiRequest('/api/users', {
        method: 'POST',
        body: JSON.stringify(userData)
    });
}
*/

// --- INITIALIZE ---
async function initializeAdmin() {
    await fetchUsers();
    await fetchInventory();
    await fetchRequests();
    await fetchPpmpData();
    await fetchDeliveries();
    await fetchRecentRequests();
    rebuildRecentActivities();
    renderUsers();
    initUserTableSorting();
    renderInventory('all');
    renderRequests('all');
    initReportRangeButtons();
    initReportActions();
    renderReports(currentReportRange);
    renderRecentRequests();
    rebuildNotifications();
    initDashboard();
    
    // Auto-refresh inventory and dashboard stats every 60 seconds
    setInterval(async () => {
        await fetchInventory();
        await fetchRequests();
        await fetchPpmpData();
        await fetchDeliveries();
        await fetchRecentRequests();
        rebuildRecentActivities();
        renderRecentActivities();
        renderActivitySummary();
        rebuildNotifications();
        if (notificationsPanel?.classList.contains('active')) {
            renderNotifications(document.querySelector(".notif-tab.active")?.dataset.filter || 'all');
        }
        if (document.getElementById('dashboard').classList.contains('active')) {
            renderDashboardStats();
            renderRecentRequests();
        }
        if (document.getElementById('inventory').classList.contains('active')) {
            renderInventory('all');
        }
        if (document.getElementById('approvals').classList.contains('active')) {
            renderRequests('all');
        }
    }, 10000);
}

// Load current admin avatar from localStorage if present
function loadCurrentUserAvatar() {
    try {
        const username = window.currentAdminUser || '';
        if (!username) return;
        const data = localStorage.getItem('avatar_' + username);
        const avatarEl = document.querySelector('.profile .avatar');
        if (data && avatarEl) {
            avatarEl.style.backgroundImage = `url(${data})`;
            avatarEl.style.backgroundSize = 'cover';
        }
    } catch (e) { console.error(e); }
}

// --- ACCOUNT SETTINGS ---
function getProfileStorageKey() {
    return 'admin_profile_' + (window.currentAdminUser || 'default');
}

function loadProfileExtras() {
    try {
        return JSON.parse(localStorage.getItem(getProfileStorageKey()) || '{}') || {};
    } catch (e) {
        return {};
    }
}

function saveProfileExtras(data) {
    localStorage.setItem(getProfileStorageKey(), JSON.stringify(data));
}

function renderAccountSettings() {
    const extras = loadProfileExtras();
    const name = extras.displayName || window.currentAdminFullName || window.currentAdminUser || '—';
    const email = extras.email || window.currentAdminEmail || '—';
    const phone = extras.phone || '+63 9123456789';
    const address = extras.address || 'Calamba City, Laguna, Parian';
    const bureau = extras.bureau || 'Bureau of Working Conditions';

    const setText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value || '—';
    };

    setText('settingsDisplayName', name);
    setText('settingsRole', window.currentAdminRole || 'Admin');
    setText('settingsBureau', bureau);
    setText('settingsEmail', email);
    setText('settingsPhone', phone);
    setText('settingsAddress', address);
    setText('settingsFullName', extras.fullName || name);
    setText('settingsDob', extras.dob || 'June 13, 2003');
    setText('settingsGender', extras.gender || 'Male');
    setText('settingsCivil', extras.civil || 'Single');
    setText('settingsNationality', extras.nationality || 'Filipino');
    setText('settingsUsername', window.currentAdminUser || '—');
    setText('settingsEmployeeId', extras.employeeId || 'DOLE-2026-00013');
    setText('settingsPosition', extras.position || 'Administrative Officer');
    setText('settingsDivision', extras.division || bureau);
    setText('settingsEmployment', extras.employment || 'Permanent');
    setText('settingsStep', extras.step || '3');
    setText('settingsDateCreated', extras.dateCreated || 'June 5, 2026');

    const avatar = localStorage.getItem('avatar_' + (window.currentAdminUser || '')) || '';
    const settingsAvatar = document.getElementById('settingsAvatar');
    if (settingsAvatar) {
        settingsAvatar.style.backgroundImage = avatar ? `url(${avatar})` : '';
        settingsAvatar.style.backgroundSize = 'cover';
    }
}

const DEFAULT_SYSTEM_SETTINGS = {
    lowStockThreshold: 5,
    showOutOfStock: true,
    defaultRequestFilter: 'all',
    notifyNewRequests: true,
    notifyLowStock: true,
    autoRefresh: false,
    sessionTimeout: '60'
};

function getSystemSettingsKey() {
    return 'admin_system_settings_' + (window.currentAdminUser || 'default');
}

function loadSystemSettings() {
    try {
        return { ...DEFAULT_SYSTEM_SETTINGS, ...(JSON.parse(localStorage.getItem(getSystemSettingsKey()) || '{}') || {}) };
    } catch (e) {
        return { ...DEFAULT_SYSTEM_SETTINGS };
    }
}

function saveSystemSettings(data) {
    localStorage.setItem(getSystemSettingsKey(), JSON.stringify(data));
}

function loadSystemSettingsForm() {
    const s = loadSystemSettings();
    const setVal = (id, value) => {
        const el = document.getElementById(id);
        if (!el) return;
        if (el.type === 'checkbox') el.checked = !!value;
        else el.value = value;
    };
    setVal('sysLowStockThreshold', s.lowStockThreshold);
    setVal('sysShowOutOfStock', s.showOutOfStock);
    setVal('sysDefaultRequestFilter', s.defaultRequestFilter);
    setVal('sysNotifyNewRequests', s.notifyNewRequests);
    setVal('sysNotifyLowStock', s.notifyLowStock);
    setVal('sysAutoRefresh', s.autoRefresh);
    setVal('sysSessionTimeout', s.sessionTimeout);
}

function collectSystemSettingsFromForm() {
    return {
        lowStockThreshold: Math.max(1, parseInt(document.getElementById('sysLowStockThreshold')?.value || '5', 10) || 5),
        showOutOfStock: !!document.getElementById('sysShowOutOfStock')?.checked,
        defaultRequestFilter: document.getElementById('sysDefaultRequestFilter')?.value || 'all',
        notifyNewRequests: !!document.getElementById('sysNotifyNewRequests')?.checked,
        notifyLowStock: !!document.getElementById('sysNotifyLowStock')?.checked,
        autoRefresh: !!document.getElementById('sysAutoRefresh')?.checked,
        sessionTimeout: document.getElementById('sysSessionTimeout')?.value || '60'
    };
}

document.getElementById('saveSystemSettingsBtn')?.addEventListener('click', () => {
    const data = collectSystemSettingsFromForm();
    saveSystemSettings(data);
    showToast('System settings saved.', 'success');
});

document.getElementById('resetSystemSettingsBtn')?.addEventListener('click', () => {
    saveSystemSettings({ ...DEFAULT_SYSTEM_SETTINGS });
    loadSystemSettingsForm();
    showToast('System settings reset to defaults.', 'success');
});

function openEditProfileModal() {
    if (!editProfileModal) return;
    const extras = loadProfileExtras();
    document.getElementById('editDisplayName').value = extras.displayName || window.currentAdminFullName || '';
    document.getElementById('editEmail').value = extras.email || window.currentAdminEmail || '';
    document.getElementById('editPhone').value = extras.phone || '';
    document.getElementById('editAddress').value = extras.address || '';
    const dobEl = document.getElementById('editDob');
    const genderEl = document.getElementById('editGender');
    const civilEl = document.getElementById('editCivil');
    const nationalityEl = document.getElementById('editNationality');
    const bureauEl = document.getElementById('editBureau');
    if (dobEl) dobEl.value = extras.dob || 'June 13, 2003';
    if (genderEl) genderEl.value = extras.gender || 'Male';
    if (civilEl) civilEl.value = extras.civil || 'Single';
    if (nationalityEl) nationalityEl.value = extras.nationality || 'Filipino';
    if (bureauEl) bureauEl.value = extras.bureau || 'Bureau of Working Conditions';
    const setEditValue = (id, value) => {
        const field = document.getElementById(id);
        if (field) field.value = value;
    };
    setEditValue('editEmployeeId', extras.employeeId || 'DOLE-2026-00013');
    setEditValue('editPosition', extras.position || 'Administrative Officer');
    setEditValue('editEmployment', extras.employment || 'Permanent');
    setEditValue('editPlantillaItemNo', extras.plantillaItemNo || 'DOL-BWC-2026-078');
    setEditValue('editSalaryGrade', extras.salaryGrade || 'SG 15');
    setEditValue('editStep', extras.step || '3');
    setEditValue('editDateCreated', extras.dateCreated || 'June 5, 2026');
    const saved = localStorage.getItem('avatar_' + (window.currentAdminUser || ''));
    if (saved && editAvatarPreview) {
        editAvatarPreview.style.backgroundImage = `url(${saved})`;
        editAvatarPreview.style.backgroundSize = 'cover';
    }
    editProfileModal.classList.add('active');
}

// Open Edit Profile modal when clicking profile avatar or settings edit
const profileEl = document.querySelector('.profile');
const editProfileModal = document.getElementById('editProfileModal');
const closeEditProfileModal = document.getElementById('closeEditProfileModal');
const cancelEditProfileBtn = document.getElementById('cancelEditProfileBtn');
const saveProfileBtn = document.getElementById('saveProfileBtn');
const editAvatarInput = document.getElementById('editAvatarInput');
const editAvatarPreview = document.getElementById('editAvatarPreview');
const settingsEditBtn = document.getElementById('settingsEditBtn');

if (profileEl) {
    profileEl.addEventListener('click', () => showPage('settings'));
}
if (settingsEditBtn) {
    settingsEditBtn.addEventListener('click', openEditProfileModal);
}

if (closeEditProfileModal) closeEditProfileModal.onclick = () => editProfileModal.classList.remove('active');
if (cancelEditProfileBtn) cancelEditProfileBtn.onclick = () => editProfileModal.classList.remove('active');

if (editAvatarInput) {
    editAvatarInput.addEventListener('change', (e) => {
        const f = e.target.files && e.target.files[0];
        if (!f) return;
        const r = new FileReader();
        r.onload = () => {
            editAvatarPreview.style.backgroundImage = `url(${r.result})`;
            editAvatarPreview.style.backgroundSize = 'cover';
            editAvatarPreview.dataset.avatar = r.result;
        };
        r.readAsDataURL(f);
    });
}

if (saveProfileBtn) {
    saveProfileBtn.onclick = () => {
        const username = window.currentAdminUser || '';
        const displayName = document.getElementById('editDisplayName').value.trim();
        const email = document.getElementById('editEmail').value.trim();
        const phone = document.getElementById('editPhone').value.trim();
        const address = document.getElementById('editAddress').value.trim();
        const dob = document.getElementById('editDob')?.value.trim() || '';
        const gender = document.getElementById('editGender')?.value.trim() || '';
        const civil = document.getElementById('editCivil')?.value.trim() || '';
        const nationality = document.getElementById('editNationality')?.value.trim() || '';
        const bureau = document.getElementById('editBureau')?.value.trim() || '';
        const employeeId = document.getElementById('editEmployeeId')?.value.trim() || '';
        const position = document.getElementById('editPosition')?.value.trim() || '';
        const employment = document.getElementById('editEmployment')?.value.trim() || '';
        const plantillaItemNo = document.getElementById('editPlantillaItemNo')?.value.trim() || '';
        const salaryGrade = document.getElementById('editSalaryGrade')?.value.trim() || '';
        const step = document.getElementById('editStep')?.value.trim() || '';
        const dateCreated = document.getElementById('editDateCreated')?.value.trim() || '';
        const avatarFile = editAvatarInput && editAvatarInput.files && editAvatarInput.files[0] ? editAvatarInput.files[0] : null;

        (async () => {
            let uploadedUrl = null;
            if (avatarFile && username) {
                try {
                    const fd = new FormData();
                    fd.append('avatar', avatarFile);
                    const res = await fetch(`${loginApiBase}/upload_avatar.php`, {
                        method: 'POST',
                        credentials: 'include',
                        headers: withCsrfHeaders(),
                        body: fd
                    });
                    if (res.ok) {
                        const j = await res.json();
                        if (j.success && j.url) uploadedUrl = j.url;
                    }
                } catch (e) {
                    console.warn('Avatar upload failed', e);
                }
            }

            const avatarData = uploadedUrl || (editAvatarPreview && editAvatarPreview.dataset.avatar ? editAvatarPreview.dataset.avatar : null);

            if (avatarData && username) {
                localStorage.setItem('avatar_' + username, avatarData);
                const avatarEl = document.querySelector('.profile .avatar');
                if (avatarEl) { avatarEl.style.backgroundImage = `url(${avatarData})`; avatarEl.style.backgroundSize='cover'; }
            }

            saveProfileExtras({
                displayName,
                email,
                phone,
                address,
                dob,
                gender,
                civil,
                nationality,
                bureau,
                fullName: displayName,
                employeeId,
                position,
                employment,
                plantillaItemNo,
                salaryGrade,
                step,
                dateCreated,
                division: bureau
            });

            if (displayName) window.currentAdminFullName = displayName;
            if (email) window.currentAdminEmail = email;

            try {
                usersData = usersData.map(u => {
                    if ((u.username && u.username === username) || (u.email && u.email === window.currentAdminEmail)) {
                        return { ...u, name: displayName || u.name, email: email || u.email, avatar: avatarData || u.avatar };
                    }
                    return u;
                });
            } catch (e) { console.error(e); }

            renderUsers();
            renderAccountSettings();
            editProfileModal.classList.remove('active');
            showToast('Profile updated', 'success');
        })();
    };
}

const changePasswordModal = document.getElementById('changePasswordModal');
const changePasswordBtn = document.getElementById('changePasswordBtn');
const closeChangePasswordModal = document.getElementById('closeChangePasswordModal');
const cancelChangePasswordBtn = document.getElementById('cancelChangePasswordBtn');
const savePasswordBtn = document.getElementById('savePasswordBtn');

function closePasswordModal() {
    if (changePasswordModal) changePasswordModal.classList.remove('active');
    ['currentPassword', 'newPassword', 'confirmPassword'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
}

if (changePasswordBtn) {
    changePasswordBtn.onclick = () => changePasswordModal?.classList.add('active');
}
if (closeChangePasswordModal) closeChangePasswordModal.onclick = closePasswordModal;
if (cancelChangePasswordBtn) cancelChangePasswordBtn.onclick = closePasswordModal;
if (savePasswordBtn) {
    savePasswordBtn.onclick = () => {
        const current = document.getElementById('currentPassword')?.value || '';
        const next = document.getElementById('newPassword')?.value || '';
        const confirm = document.getElementById('confirmPassword')?.value || '';
        if (!current || !next || !confirm) {
            showToast('Please fill in all password fields.', 'error');
            return;
        }
        if (next.length < 6) {
            showToast('New password must be at least 6 characters.', 'error');
            return;
        }
        if (next !== confirm) {
            showToast('New passwords do not match.', 'error');
            return;
        }
        closePasswordModal();
        showToast('Password updated successfully.', 'success');
    };
}

// call initial avatar load
loadCurrentUserAvatar();

async function fetchInventory() {
    try {
        const response = await fetch(`${inventoryApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load inventory (HTTP ${response.status})`);
        }
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load inventory');
        inventoryData = Array.isArray(data.data) ? data.data : [];
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load inventory. Report stock metrics are unavailable.', 'warning');
        inventoryData = [];
    }
}

async function fetchRequests() {
    try {
        const response = await fetch(`${requestsApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load requests (HTTP ${response.status})`);
        }
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load requests');
        requestsData = Array.isArray(data.data) ? data.data : [];
        recentRequestsData = requestsData.slice(0, 5);
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load requests. Report request metrics are unavailable.', 'warning');
        requestsData = [];
        recentRequestsData = [];
    }
}

async function fetchPpmpData() {
    try {
        const response = await fetch(`${ppmpApiBase}?action=list`, { credentials: 'include' });
        if (!response.ok) throw new Error(`Unable to load PPMP data (HTTP ${response.status})`);
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load PPMP data');
        ppmpData = Array.isArray(data.data) ? data.data : [];
    } catch (error) {
        console.error(error);
        ppmpData = [];
    }
}

async function fetchDeliveries() {
    try {
        const [activeResponse, completedResponse] = await Promise.all([
            fetch(`${deliveryApiBase}?action=list`, { credentials: 'include' }),
            fetch(`${deliveryApiBase}?action=list_completed`, { credentials: 'include' })
        ]);
        if (!activeResponse.ok || !completedResponse.ok) {
            if (activeResponse.status === 401 || completedResponse.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load delivery data (HTTP ${activeResponse.status}/${completedResponse.status})`);
        }
        const [activeData, completedData] = await Promise.all([activeResponse.json(), completedResponse.json()]);
        if (!activeData.success || !completedData.success) throw new Error(activeData.message || completedData.message || 'Unable to load delivery data');
        deliveriesData = [
            ...(Array.isArray(activeData.data) ? activeData.data : []),
            ...(Array.isArray(completedData.data) ? completedData.data : [])
        ];
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load deliveries.', 'error');
        deliveriesData = [];
    }
}

async function fetchRecentRequests() {
    try {
        const response = await fetch(`${requestsApiBase}?action=recent`, { credentials: 'include' });
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to load recent requests (HTTP ${response.status})`);
        }
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to load recent requests');
        recentRequestsData = Array.isArray(data.data) ? data.data.slice(0, 5) : [];
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not load recent requests.', 'error');
        recentRequestsData = [];
    }
}

async function updateRequestStatus(requestId, status) {
    try {
        const response = await fetch(`${requestsApiBase}?action=update_status`, {
            method: 'POST',
            credentials: 'include',
            headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ id: requestId, status: status })
        });
        
        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = loginPageUrl;
                return;
            }
            throw new Error(`Unable to update request (HTTP ${response.status})`);
        }
        
        const data = await response.json();
        if (!data.success) throw new Error(data.message || 'Unable to update request');
        
        showToast(`Request ${status.toLowerCase()} successfully`, 'success');
        await fetchRequests();
        await fetchRecentRequests();
        rebuildRecentActivities();
        renderRequests('all');
        renderRecentRequests();
        renderRecentActivities();
        renderActivitySummary();
        return true;
    } catch (error) {
        console.error(error);
        showToast(error.message || 'Could not update request.', 'error');
        return false;
    }
}

initializeAdmin().then(() => {
    if (window.flashMessage) {
        showToast(window.flashMessage, 'success');
        window.flashMessage = '';
    }
});

// Add Item modal handlers
const addModal = document.getElementById("addItemsModal");
const addItemBtn = document.getElementById("addItemBtn");
const closeAddItemsModal = document.getElementById("closeAddItemsModal");
const cancelAddItemBtn = document.getElementById("cancelAddItemBtn");
const saveItemBtn = document.getElementById("saveItemBtn");
const itemDropZone = document.getElementById("itemDropZone");
const itemImageInput = document.getElementById("itemImageInput");
let newItemImageData = null;
let newItemImageFile = null;

function openAddItemModal() {
    if (!addModal) return;
    addModal.classList.add('active');
    // reset fields
    document.getElementById('newItemName').value = '';
    document.getElementById('newItemCategory').value = 'Paper Products';
    document.getElementById('newItemUnit').value = 'pcs';
    document.getElementById('newItemStock').value = 0;
    document.getElementById('newItemMinStock').value = 1;
    newItemImageData = null;
}

function closeAddItemModal() {
    if (!addModal) return;
    addModal.classList.remove('active');
}

if (addItemBtn) addItemBtn.onclick = openAddItemModal;
if (closeAddItemsModal) closeAddItemsModal.onclick = closeAddItemModal;
if (cancelAddItemBtn) cancelAddItemBtn.onclick = closeAddItemModal;

if (itemDropZone) {
    itemDropZone.addEventListener('click', () => itemImageInput.click());
    itemDropZone.addEventListener('dragover', (e) => { e.preventDefault(); itemDropZone.classList.add('dragover'); });
    itemDropZone.addEventListener('dragleave', () => itemDropZone.classList.remove('dragover'));
    itemDropZone.addEventListener('drop', (e) => {
        e.preventDefault(); itemDropZone.classList.remove('dragover');
        const f = e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) handleItemFile(f);
    });
}

if (itemImageInput) {
    itemImageInput.addEventListener('change', (e) => {
        const f = e.target.files && e.target.files[0];
        if (f) handleItemFile(f);
    });
}

function handleItemFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
        newItemImageData = reader.result; // base64
        newItemImageFile = file;
        if (itemDropZone) itemDropZone.style.backgroundImage = `url(${newItemImageData})`;
    };
    reader.readAsDataURL(file);
}

if (saveItemBtn) {
    saveItemBtn.onclick = async () => {
        const name = document.getElementById('newItemName').value.trim();
        const category = document.getElementById('newItemCategory').value;
        const unit = document.getElementById('newItemUnit').value;
        const stock = parseInt(document.getElementById('newItemStock').value, 10) || 0;
        const min_stock = parseInt(document.getElementById('newItemMinStock').value, 10) || 0;

        if (!name) { alert('Please enter item name'); return; }

        // Create a local item object (id will be assigned by backend in production)
        const newId = inventoryData.length ? Math.max(...inventoryData.map(i=>i.id||0)) + 1 : 1;
        const newItem = {
            id: newId,
            item_name: name,
            category: category,
            stock: stock,
            min_stock: min_stock,
            unit: unit,
            last_modified: new Date().toISOString().split('T')[0],
            image: newItemImageData
        };

        // Attempt to post to backend; if unavailable, add locally
        try {
            if (newItemImageFile) {
                const fd = new FormData();
                fd.append('image', newItemImageFile);
                fd.append('item_name', newItem.item_name);
                fd.append('category', newItem.category);
                fd.append('stock', newItem.stock);
                fd.append('unit', newItem.unit);
                fd.append('min_stock', newItem.min_stock);

                const resp = await fetch(`${inventoryApiBase}?action=add`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: withCsrfHeaders(),
                    body: fd
                });
                const json = await resp.json();
                if (!resp.ok || !json.success) throw new Error(json.message || 'Unable to add inventory item');
                if (Array.isArray(json.data)) inventoryData = json.data;
                else if (json.item) inventoryData.push(json.item);
            } else {
                const resp = await fetch(`${inventoryApiBase}?action=add`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
                    body: JSON.stringify(newItem)
                });
                const json = await resp.json();
                if (!resp.ok || !json.success) throw new Error(json.message || 'Unable to add inventory item');
                if (Array.isArray(json.data)) inventoryData = json.data;
                else if (json.item) inventoryData.push(json.item);
            }
        } catch (err) {
            console.warn('Backend add failed', err);
            showToast(err.message || 'Could not add item.', 'error');
            return;
        }

        renderInventory('all');
        closeAddItemModal();
        showToast('Item added!', 'success');
    };
}

// --- SEARCH FUNCTIONALITY ---
function filterAndRenderInventory(searchQuery) {
    const query = searchQuery.toLowerCase().trim();
    const table = document.getElementById("inventoryTable");
    table.innerHTML = "";
    let counts = { all: 0, in: 0, low: 0, out: 0 };

    const visibleItems = inventoryData
        .filter(i => {
            const status = getStatus(i.stock, i.min_stock);
            const itemName = (i.item_name || '').toLowerCase();
            const itemCode = `ITM${String(i.id).padStart(4, '0')}`.toLowerCase();
            const category = (i.category || '').toLowerCase();
            const matchesSearch = !query || itemName.includes(query) || itemCode.includes(query) || category.includes(query);
            const matchesCategory = inventoryCategoryFilter === 'all' || category === inventoryCategoryFilter;
            return matchesSearch && matchesCategory;
        })
        .sort((a, b) => {
            if (inventorySortField === 'item') {
                const ai = Number(a.id) || 0;
                const bi = Number(b.id) || 0;
                return inventorySortDir === 'asc' ? ai - bi : bi - ai;
            }
            const at = new Date(a.last_modified).getTime() || 0;
            const bt = new Date(b.last_modified).getTime() || 0;
            return inventorySortDir === 'asc' ? at - bt : bt - at;
        });

    document.getElementById("totalItemCount").textContent = String(visibleItems.length);

    visibleItems.forEach(i => {
        const status = getStatus(i.stock, i.min_stock);

        let statusClass = status === 'in' ? 'green' : status === 'low' ? 'yellow' : 'red';
        let statusText = status === 'in' ? 'In Stock' : status === 'low' ? 'Low Stock' : 'Out of Stock';
        const formattedItemCode = `ITM${String(i.id).padStart(4, '0')}`;

        const imgStyle = i.image ? `style="background-image:url(${i.image}); background-size:cover;"` : '';
        table.innerHTML += `
            <tr>
                <td>
                    <div class="item-cell">
                        <div class="item-img-box" ${imgStyle}></div>
                        <div class="item-text">
                            <div class="item-name">${i.item_name}</div>
                            <div class="item-code">${formattedItemCode}</div>
                        </div>
                    </div>
                </td>
                <td>${i.category}</td>
                <td>${i.stock} ${i.unit || 'pcs'}</td>
                <td><span class="status ${statusClass}">${statusText}</span></td>
                <td>${i.last_modified}</td>
            </tr>
        `;
    });

    document.getElementById("totalItemCount").textContent = String(visibleItems.length);
}

// Add event listener to search input
const searchInput = document.getElementById("searchInput");
if (searchInput) {
    searchInput.addEventListener("input", (e) => {
        filterAndRenderInventory(e.target.value);
    });
}

// Add event listener to user search input
const userSearchInput = document.getElementById("userSearchInput");
if (userSearchInput) {
    userSearchInput.addEventListener("input", (e) => {
        filterAndRenderUsers(e.target.value);
    });
}

function filterAndRenderUsers(searchQuery) {
    const query = searchQuery.toLowerCase().trim();
    const table = document.getElementById("userTable");
    table.innerHTML = "";
    const currentUser = window.currentAdminUser || '';
    
    usersData.forEach(user => {
        const userName = user.name.toLowerCase();
        const userEmail = user.email.toLowerCase();
        const province = (user.province || '').toLowerCase();
        
        // Check if user matches search query
        const matches = !query || userName.includes(query) || userEmail.includes(query) || province.includes(query);
        
        if (!matches) return;
        
        const statusKey = String(user.status || 'Operational').toLowerCase();
        const statusClass = statusKey === 'operational' ? 'status-operational' : 'status-not-operational';
        const statusLabel = statusKey === 'operational' ? 'Operational' : 'Not Operational';
        const roleClass = user.role === 'Admin' ? 'role-admin' :
                         user.role === 'Approver' ? 'role-approver' :
                         user.role === 'Delivery' ? 'role-delivery' : 'role-requester';
        const currentClass = user.username === currentUser ? 'user-current' : '';
        
        const avatar = user.avatar || localStorage.getItem('avatar_' + (user.username || user.email || '')) || '';
        const avatarStyle = avatar ? `style="background-image:url(${avatar}); background-size:cover;"` : '';
        table.innerHTML += `
            <tr class="${currentClass}">
                <td>
                    <div class="user-info">
                        <div class="user-avatar" ${avatarStyle}></div>
                        <div class="user-details">
                            <div class="user-name">${user.name}</div>
                            <div class="user-email">${user.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="role-badge ${roleClass}">${user.role}</span></td>
                <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                <td>${user.province}</td>
                <td>${user.lastActive}</td>
                <td>${user.dateAdded}</td>
                <td>
                    <div class="user-action-cell">
                        <button class="status-toggle-btn ${statusKey === 'operational' ? 'status-operational' : 'status-not-operational'}" data-username="${user.username}" title="Toggle operational status"></button>
                        <div class="user-options-wrapper">
                            <button class="user-options-btn" data-username="${user.username}" title="More actions">⋮</button>
                            <div class="user-action-menu hidden" data-username="${user.username}">
                                <button type="button" class="user-action-menu-item" data-action="edit" data-username="${user.username}">Edit information</button>
                                <button type="button" class="user-action-menu-item" data-action="status" data-username="${user.username}">Status: ${statusLabel}</button>
                                <button type="button" class="user-action-menu-item user-action-delete" data-action="delete" data-username="${user.username}">Delete user</button>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    });

    table.querySelectorAll('.status-toggle-btn').forEach(btn => {
        btn.onclick = async (e) => {
            e.stopPropagation();
            const username = btn.dataset.username;
            const user = usersData.find(entry => entry.username === username);
            if (!user) return;
            const newStatus = user.status === 'Not Operational' ? 'Operational' : 'Not Operational';
            await updateUserStatus(username, newStatus);
        };
    });

    table.querySelectorAll('.user-options-btn').forEach(btn => {
        btn.onclick = (e) => {
            e.stopPropagation();
            const username = btn.dataset.username;
            const menu = btn.parentElement.querySelector('.user-action-menu');
            if (!menu) return;
            const isOpen = !menu.classList.contains('hidden');
            document.querySelectorAll('.user-action-menu').forEach(m => m.classList.add('hidden'));
            if (!isOpen) {
                menu.classList.remove('hidden');
            }
        };
    });

    table.querySelectorAll('.user-action-menu-item').forEach(item => {
        item.onclick = (e) => {
            e.stopPropagation();
            const action = item.dataset.action;
            const username = item.dataset.username;
            document.querySelectorAll('.user-action-menu').forEach(m => m.classList.add('hidden'));
            if (action === 'edit') {
                openEditUserModal(username);
            } else if (action === 'status') {
                openUserStatusPrompt(username);
            } else if (action === 'delete') {
                deleteUser(username);
            }
        };
    });
}
