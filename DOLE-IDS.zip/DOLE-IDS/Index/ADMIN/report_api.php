<?php
session_set_cookie_params([
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

require_once __DIR__ . '/../../Login/db_connect.php';
require_once __DIR__ . '/../../Login/activity_log.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function reportApiJson(int $status, array $payload): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (empty($_SESSION['logged_in']) || strcasecmp((string)($_SESSION['role'] ?? ''), 'Admin') !== 0) {
    reportApiJson(403, ['success' => false, 'message' => 'Admin access is required.']);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? 'events';

function validReportDate(string $value): bool
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

if ($method === 'GET' && $action === 'events') {
    $startDate = trim((string)($_GET['start_date'] ?? ''));
    $endDate = trim((string)($_GET['end_date'] ?? ''));
    if (($startDate !== '' && !validReportDate($startDate)) || ($endDate !== '' && !validReportDate($endDate))) {
        reportApiJson(422, ['success' => false, 'message' => 'Dates must use YYYY-MM-DD format.']);
    }
    if ($startDate !== '' && $endDate !== '' && $startDate > $endDate) {
        reportApiJson(422, ['success' => false, 'message' => 'Start date must not be after end date.']);
    }

    $where = [];
    $params = [];
    if ($startDate !== '') {
        $where[] = 'created_at >= ?';
        $params[] = $startDate . ' 00:00:00';
    }
    if ($endDate !== '') {
        $where[] = 'created_at < DATE_ADD(?, INTERVAL 1 DAY)';
        $params[] = $endDate . ' 00:00:00';
    }
    $whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM system_activity_log' . $whereSql);
    $countStmt->execute($params);
    $total = (int)$countStmt->fetchColumn();

    $limit = max(1, min(500, (int)($_GET['limit'] ?? 100)));
    $offset = max(0, (int)($_GET['offset'] ?? 0));
    $stmt = $pdo->prepare(
        'SELECT id, event_type, entity_type, entity_id, province, actor_username, actor_role, summary, details_json, created_at
         FROM system_activity_log' . $whereSql . ' ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?'
    );
    $position = 1;
    foreach ($params as $param) {
        $stmt->bindValue($position++, $param, PDO::PARAM_STR);
    }
    $stmt->bindValue($position++, $limit, PDO::PARAM_INT);
    $stmt->bindValue($position, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($events as &$event) {
        $event['details'] = $event['details_json'] !== null
            ? (json_decode((string)$event['details_json'], true) ?: [])
            : [];
        unset($event['details_json']);
    }
    unset($event);

    reportApiJson(200, [
        'success' => true,
        'data' => $events,
        'pagination' => ['total' => $total, 'limit' => $limit, 'offset' => $offset],
        'history_start' => 'Activity records are captured from the activity ledger rollout onward.',
    ]);
}

if ($method === 'POST' && $action === 'export') {
    $headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    $sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
    $cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));
    if ($headerToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $headerToken)) {
        reportApiJson(403, ['success' => false, 'message' => 'Invalid CSRF token']);
    }

    $input = json_decode((string)file_get_contents('php://input'), true) ?: [];
    $type = strtolower(trim((string)($input['type'] ?? '')));
    $startDate = trim((string)($input['start_date'] ?? ''));
    $endDate = trim((string)($input['end_date'] ?? ''));
    if (!in_array($type, ['csv', 'xlsx', 'pdf'], true)
        || !validReportDate($startDate)
        || !validReportDate($endDate)
        || $startDate > $endDate) {
        reportApiJson(422, ['success' => false, 'message' => 'Invalid report export details.']);
    }

    recordSystemActivity(
        $pdo,
        'report_exported',
        'report',
        null,
        null,
        strtoupper($type) . ' activity report exported',
        ['type' => $type, 'start_date' => $startDate, 'end_date' => $endDate]
    );
    reportApiJson(200, ['success' => true]);
}

reportApiJson(400, ['success' => false, 'message' => 'Invalid report action.']);