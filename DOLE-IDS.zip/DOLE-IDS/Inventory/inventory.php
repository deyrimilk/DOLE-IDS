<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
require_once __DIR__ . '/../Login/db_connect.php';
require_once __DIR__ . '/../Login/activity_log.php';

header('Content-Type: application/json; charset=utf-8');

function json_out(int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    json_out(401, ['success' => false, 'message' => 'Unauthorized']);
}

$role = (string)($_SESSION['role'] ?? '');
$isApprover = strcasecmp($role, 'Approver') === 0;

function ensureColumnExists(PDO $pdo, string $table, string $column, string $definition): void {
    $colCheck = $pdo->prepare("SHOW COLUMNS FROM {$table} LIKE ?");
    $colCheck->execute([$column]);
    if (!$colCheck->fetch()) {
        $pdo->exec("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method !== 'GET') {
    $headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    $sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
    $cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

    if ($sessionToken !== '' && $headerToken !== '' && hash_equals($sessionToken, $headerToken)) {
        // valid CSRF token
    } elseif ($sessionToken === '' || $headerToken === '') {
        json_out(403, ['success' => false, 'message' => 'Invalid CSRF token']);
    } else {
        json_out(403, ['success' => false, 'message' => 'Invalid CSRF token']);
    }
}

if ($method === 'GET' && $action === 'list') {
    try {
        $columnCheck = $pdo->query("SHOW COLUMNS FROM inventory_items LIKE 'image_path'");
        if (!$columnCheck->fetch()) {
            $pdo->exec("ALTER TABLE inventory_items ADD COLUMN image_path VARCHAR(255) NULL AFTER min_stock");
        }
    } catch (PDOException $e) {
        // ignore schema repair failures and proceed without image_path if necessary
    }

    $stmt = $pdo->query("SELECT id, item_name, category, stock, unit, min_stock, image_path, DATE_FORMAT(last_modified, '%Y-%m-%d') AS last_modified FROM inventory_items ORDER BY item_name ASC");
    $items = $stmt->fetchAll();
    // append image url if file exists in Images/items or use stored image_path
    $baseWeb = dirname(dirname($_SERVER['SCRIPT_NAME'])); // /SYSTEM
    foreach ($items as &$it) {
        $id = $it['id'];
        $found = null;
        // prefer DB-stored image_path if present
        if (!empty($it['image_path'])) {
            $found = "{$baseWeb}/" . ltrim($it['image_path'], '/');
        } else {
            $possible = ['png','jpg','jpeg','gif','webp','svg'];
            foreach ($possible as $ext) {
                $rel = __DIR__ . "/../Images/items/item_{$id}.{$ext}";
                if (file_exists($rel)) {
                    $found = "{$baseWeb}/Images/items/item_{$id}.{$ext}";
                    break;
                }
            }
            if (!$found) {
                $found = "{$baseWeb}/Images/REQ HP.png";
            }
        }
        $it['image'] = $found;
    }
    json_out(200, ['success' => true, 'data' => $items]);
}

// All mutations are Approver-only
if (!$isApprover) {
    json_out(403, ['success' => false, 'message' => 'Forbidden']);
}

$raw = file_get_contents('php://input');
$body = [];
if (is_string($raw) && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}

// allow form-encoded too
$body = array_merge($body, $_POST);

try {
    if ($action === 'add') {
        // support multipart/form-data with file upload
        $name = trim((string)($body['item_name'] ?? $_POST['item_name'] ?? ''));
        $category = trim((string)($body['category'] ?? $_POST['category'] ?? ''));
        $stock = (int)($body['stock'] ?? $_POST['stock'] ?? 0);
        $unit = trim((string)($body['unit'] ?? $_POST['unit'] ?? 'pcs'));
        $min = (int)($body['min_stock'] ?? $_POST['min_stock'] ?? 0);

        if ($name === '' || $category === '') {
            json_out(422, ['success' => false, 'message' => 'Item name and category are required.']);
        }
        if ($unit === '') {
            json_out(422, ['success' => false, 'message' => 'Unit is required.']);
        }
        if ($stock < 0 || $min < 0) {
            json_out(422, ['success' => false, 'message' => 'Stock values must be non-negative.']);
        }

        $stmt = $pdo->prepare("INSERT INTO inventory_items (item_name, category, stock, unit, min_stock) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $category, $stock, $unit, $min]);
        $newId = $pdo->lastInsertId();
        recordSystemActivity($pdo, 'supply_item_added', 'inventory_item', $newId, null, 'Supply inventory item added', [
            'item_name' => $name,
            'category' => $category,
            'unit' => $unit,
            'stock' => $stock,
            'min_stock' => $min,
        ]);

        // handle uploaded image
        $imageUrl = null;
        if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/../Images/items';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $finfo = pathinfo($_FILES['image']['name']);
            $ext = strtolower($finfo['extension'] ?? '');
            $allowed = ['png','jpg','jpeg','gif','webp'];
            if (in_array($ext, $allowed, true)) {
                $dest = $uploadDir . "/item_{$newId}.{$ext}";
                if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                    $baseWeb = dirname(dirname($_SERVER['SCRIPT_NAME']));
                    $imageUrl = "{$baseWeb}/Images/items/item_{$newId}.{$ext}";
                    // persist image path to DB (add column if missing)
                    try {
                        $colCheck = $pdo->query("SHOW COLUMNS FROM inventory_items LIKE 'image_path'");
                        $exists = $colCheck->fetch();
                        if (!$exists) {
                            $pdo->exec("ALTER TABLE inventory_items ADD COLUMN image_path VARCHAR(255) NULL AFTER min_stock");
                        }
                        $stmt2 = $pdo->prepare("UPDATE inventory_items SET image_path = ? WHERE id = ?");
                        $dbPath = "Images/items/item_{$newId}.{$ext}";
                        $stmt2->execute([$dbPath, $newId]);
                    } catch (PDOException $e) {
                        // non-fatal
                    }
                }
            }
        }

        // return the newly created item with optional image url
        $stmt = $pdo->prepare("SELECT id, item_name, category, stock, unit, min_stock, DATE_FORMAT(last_modified, '%Y-%m-%d') AS last_modified FROM inventory_items WHERE id = ?");
        $stmt->execute([$newId]);
        $item = $stmt->fetch();
        if ($item) {
            $item['image'] = $imageUrl;
        }
        json_out(200, ['success' => true, 'item' => $item, 'data' => null]);
    }

    if ($action === 'update') {
        $id = (int)($body['id'] ?? 0);
        $name = trim((string)($body['item_name'] ?? ''));
        $category = trim((string)($body['category'] ?? ''));
        $unit = trim((string)($body['unit'] ?? 'pcs'));
        $min = (int)($body['min_stock'] ?? 0);

        if ($id <= 0 || $name === '' || $category === '') {
            json_out(422, ['success' => false, 'message' => 'Invalid item update payload.']);
        }
        if ($unit === '') {
            json_out(422, ['success' => false, 'message' => 'Unit is required.']);
        }
        if ($min < 0) {
            json_out(422, ['success' => false, 'message' => 'Minimum stock must be non-negative.']);
        }

        $beforeStmt = $pdo->prepare("SELECT item_name, category, unit, min_stock FROM inventory_items WHERE id = ? LIMIT 1");
        $beforeStmt->execute([$id]);
        $before = $beforeStmt->fetch(PDO::FETCH_ASSOC);
        if (!$before) {
            json_out(404, ['success' => false, 'message' => 'Inventory item not found.']);
        }
        $stmt = $pdo->prepare("UPDATE inventory_items SET item_name = ?, category = ?, unit = ?, min_stock = ? WHERE id = ?");
        $stmt->execute([$name, $category, $unit, $min, $id]);
        recordSystemActivity($pdo, 'supply_item_updated', 'inventory_item', $id, null, 'Supply inventory item details updated', [
            'before' => $before,
            'after' => ['item_name' => $name, 'category' => $category, 'unit' => $unit, 'min_stock' => $min],
        ]);
        json_out(200, ['success' => true]);
    }

    if ($action === 'updateStock') {
        $id = (int)($body['id'] ?? 0);
        $stock = (int)($body['stock'] ?? -1);
        if ($id <= 0 || $stock < 0) {
            json_out(422, ['success' => false, 'message' => 'Invalid stock update payload.']);
        }

        $beforeStmt = $pdo->prepare("SELECT item_name, unit, stock FROM inventory_items WHERE id = ? LIMIT 1");
        $beforeStmt->execute([$id]);
        $before = $beforeStmt->fetch(PDO::FETCH_ASSOC);
        if (!$before) {
            json_out(404, ['success' => false, 'message' => 'Inventory item not found.']);
        }
        $stmt = $pdo->prepare("UPDATE inventory_items SET stock = ? WHERE id = ?");
        $stmt->execute([$stock, $id]);
        recordSystemActivity($pdo, 'supply_stock_adjusted', 'inventory_item', $id, null, 'Supply inventory stock manually adjusted', [
            'item_name' => $before['item_name'],
            'unit' => $before['unit'],
            'before_stock' => (int)$before['stock'],
            'after_stock' => $stock,
            'quantity_change' => $stock - (int)$before['stock'],
        ]);
        json_out(200, ['success' => true]);
    }

    if ($action === 'delete') {
        $id = (int)($body['id'] ?? 0);
        if ($id <= 0) {
            json_out(422, ['success' => false, 'message' => 'Invalid delete payload.']);
        }
        $beforeStmt = $pdo->prepare("SELECT item_name, category, unit, stock, min_stock FROM inventory_items WHERE id = ? LIMIT 1");
        $beforeStmt->execute([$id]);
        $before = $beforeStmt->fetch(PDO::FETCH_ASSOC);
        if (!$before) {
            json_out(404, ['success' => false, 'message' => 'Inventory item not found.']);
        }
        $stmt = $pdo->prepare("DELETE FROM inventory_items WHERE id = ?");
        $stmt->execute([$id]);
        recordSystemActivity($pdo, 'supply_item_deleted', 'inventory_item', $id, null, 'Supply inventory item deleted', $before);
        json_out(200, ['success' => true]);
    }

    json_out(400, ['success' => false, 'message' => 'Unknown action.']);
} catch (PDOException $e) {
    error_log('Inventory API error: ' . $e->getMessage());
    json_out(500, ['success' => false, 'message' => 'The inventory request could not be completed.']);
}

