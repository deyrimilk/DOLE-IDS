<?php
session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['logged_in']) || empty($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/../Login/db_connect.php';
require_once __DIR__ . '/../Login/activity_log.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$role = (string)($_SESSION['role'] ?? '');
$username = (string)($_SESSION['username'] ?? '');
$province = (string)($_SESSION['province'] ?? '');

function readJsonBody(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function requireCsrfToken(): void
{
    $headerToken = trim((string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    $bodyToken = trim((string)($_POST['csrf_token'] ?? ''));
    $sessionToken = trim((string)($_SESSION['csrf_token'] ?? ''));
    $cookieToken = trim((string)($_COOKIE['csrf_token'] ?? ''));

    if ($sessionToken === '' || ($headerToken === '' && $bodyToken === '')) {
        throw new Exception('Missing CSRF token');
    }

    $tokenToCheck = $headerToken !== '' ? $headerToken : $bodyToken;
    $valid = hash_equals($sessionToken, $tokenToCheck);
    if (!$valid) {
        throw new Exception('Invalid CSRF token');
    }
}

function buildRisDocument(PDO $pdo, int $requestId): string
{
    $stmt = $pdo->prepare('SELECT * FROM requests WHERE id = ? LIMIT 1');
    $stmt->execute([$requestId]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$request) {
        throw new Exception('Request not found');
    }

    $items = [];
    if (!empty($request['item_details'])) {
        $decoded = json_decode((string)$request['item_details'], true);
        if (is_array($decoded)) {
            $items = $decoded;
        }
    }
    if (!$items) {
        $items[] = ['item_name' => $request['item_name'] ?? 'Item', 'quantity' => (int)($request['quantity'] ?? 0)];
    }

    $escapedItems = array_map(function ($item) {
        return [
            'item_name' => (string)($item['item_name'] ?? $item['name'] ?? ''),
            'quantity' => (string)($item['quantity'] ?? 0),
            'note' => (string)($item['note'] ?? ''),
        ];
    }, $items);

    $title = 'REQUEST FOR ISSUANCE (RIS)';
    $metaLines = [
        'Department of Labor and Employment',
        'RIS Number: ' . ($request['ris_number'] ?? ('RIS-' . str_pad((string)$requestId, 8, '0', STR_PAD_LEFT))),
        'Requestor: ' . ($request['requestor'] ?? ''),
        'Date: ' . ($request['request_date'] ?? ''),
        'Status: ' . ($request['status'] ?? 'Pending'),
    ];

    $xmlRows = [];
    $xmlRows[] = '<w:tr>';
    $xmlRows[] = '<w:tc><w:p><w:r><w:t>Item</w:t></w:r></w:p></w:tc>';
    $xmlRows[] = '<w:tc><w:p><w:r><w:t>Quantity</w:t></w:r></w:p></w:tc>';
    $xmlRows[] = '<w:tc><w:p><w:r><w:t>Purpose</w:t></w:r></w:p></w:tc>';
    $xmlRows[] = '<w:tc><w:p><w:r><w:t>Remarks</w:t></w:r></w:p></w:tc>';
    $xmlRows[] = '<w:tc><w:p><w:r><w:t>Prepared By</w:t></w:r></w:p></w:tc>';
    $xmlRows[] = '</w:tr>';

    foreach ($escapedItems as $entry) {
        $xmlRows[] = '<w:tr>';
        $xmlRows[] = '<w:tc><w:p><w:r><w:t>' . htmlspecialchars($entry['item_name'], ENT_XML1, 'UTF-8') . '</w:t></w:r></w:p></w:tc>';
        $xmlRows[] = '<w:tc><w:p><w:r><w:t>' . htmlspecialchars($entry['quantity'], ENT_XML1, 'UTF-8') . '</w:t></w:r></w:p></w:tc>';
        $xmlRows[] = '<w:tc><w:p><w:r><w:t>' . htmlspecialchars($entry['note'], ENT_XML1, 'UTF-8') . '</w:t></w:r></w:p></w:tc>';
        $xmlRows[] = '<w:tc><w:p><w:r><w:t></w:t></w:r></w:p></w:tc>';
        $xmlRows[] = '<w:tc><w:p><w:r><w:t></w:t></w:r></w:p></w:tc>';
        $xmlRows[] = '</w:tr>';
    }

    $body = [];
    $body[] = '<w:p><w:r><w:t>' . htmlspecialchars($title, ENT_XML1, 'UTF-8') . '</w:t></w:r></w:p>';
    foreach ($metaLines as $line) {
        $body[] = '<w:p><w:r><w:t>' . htmlspecialchars($line, ENT_XML1, 'UTF-8') . '</w:t></w:r></w:p>';
    }
    $body[] = '<w:p><w:r><w:t></w:t></w:r></w:p>';
    $body[] = '<w:tbl>';
    $body[] = '<w:tblPr><w:tblBorders><w:top w:val="single"/><w:left w:val="single"/><w:bottom w:val="single"/><w:right w:val="single"/><w:insideH w:val="single"/><w:insideV w:val="single"/></w:tblBorders></w:tblPr>';
    $body[] = '<w:tblGrid><w:gridCol w:w="2400"/><w:gridCol w:w="1400"/><w:gridCol w:w="2400"/><w:gridCol w:w="1800"/><w:gridCol w:w="1800"/></w:tblGrid>';
    $body[] = implode('', $xmlRows);
    $body[] = '</w:tbl>';
    $body[] = '<w:p><w:r><w:t></w:t></w:r></w:p>';
    $body[] = '<w:p><w:r><w:t>Prepared by: ____________________</w:t></w:r></w:p>';
    $body[] = '<w:p><w:r><w:t>Approved by: ____________________</w:t></w:r></w:p>';
    $body[] = '<w:sectPr/>';

    $documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' .
        '<w:body>' . implode('', $body) . '</w:body></w:document>';

    $tmpFile = tempnam(sys_get_temp_dir(), 'ris_') . '.docx';
    $zip = new ZipArchive();
    if ($zip->open($tmpFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
        $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
        $zip->addFromString('word/document.xml', $documentXml);
        $zip->close();
    } else {
        file_put_contents($tmpFile, $documentXml);
    }

    return $tmpFile;
}

function stockStatusFromQty(int $stock, int $minStock): string
{
    if ($stock <= 0) {
        return 'Out of Stock';
    }
    if ($stock <= $minStock) {
        return 'Low Stock';
    }
    return 'In Stock';
}

try {
    if ($method === 'GET' && $action === 'list') {
        if (strcasecmp($role, 'Requester') === 0) {
            $stmt = $pdo->prepare(
                'SELECT * FROM requests
                 WHERE LOWER(requestor) = LOWER(?) OR LOWER(requestor) = LOWER(?)
                 ORDER BY request_date DESC'
            );
            $stmt->execute([$province !== '' ? $province : $username, $username]);
        } else {
            $stmt = $pdo->query('SELECT * FROM requests ORDER BY request_date DESC');
        }
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $requests
        ]);
    }
    elseif ($method === 'GET' && $action === 'mine') {
        // Requestor's own requests: match province (office) or username.
        $stmt = $pdo->prepare(
            'SELECT * FROM requests
             WHERE LOWER(requestor) = LOWER(?)
                OR LOWER(requestor) = LOWER(?)
             ORDER BY request_date DESC'
        );
        $stmt->execute([
            $province !== '' ? $province : $username,
            $username
        ]);
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $requests
        ]);
    }
    elseif ($method === 'GET' && $action === 'recent') {
        if (strcasecmp($role, 'Requester') === 0) {
            $stmt = $pdo->prepare(
                'SELECT * FROM requests
                 WHERE LOWER(requestor) = LOWER(?) OR LOWER(requestor) = LOWER(?)
                 ORDER BY request_date DESC LIMIT 5'
            );
            $stmt->execute([$province !== '' ? $province : $username, $username]);
        } else {
            $stmt = $pdo->query('SELECT * FROM requests ORDER BY request_date DESC LIMIT 5');
        }
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $requests
        ]);
    }
    elseif ($method === 'GET' && $action === 'stats') {
        $stats = [];
        $statsWhere = '';
        $statsParams = [];
        if (strcasecmp($role, 'Requester') === 0) {
            $statsWhere = ' WHERE (LOWER(requestor) = LOWER(?) OR LOWER(requestor) = LOWER(?))';
            $statsParams = [$province !== '' ? $province : $username, $username];
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) as count FROM requests' . $statsWhere);
        $stmt->execute($statsParams);
        $stats['total'] = (int)$stmt->fetch(PDO::FETCH_ASSOC)['count'];

        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM requests" . ($statsWhere === '' ? ' WHERE' : $statsWhere . ' AND') . " status = 'Pending'");
        $stmt->execute($statsParams);
        $stats['pending'] = (int)$stmt->fetch(PDO::FETCH_ASSOC)['count'];

        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM requests" . ($statsWhere === '' ? ' WHERE' : $statsWhere . ' AND') . " status = 'Approved'");
        $stmt->execute($statsParams);
        $stats['approved'] = (int)$stmt->fetch(PDO::FETCH_ASSOC)['count'];

        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM requests" . ($statsWhere === '' ? ' WHERE' : $statsWhere . ' AND') . " status = 'Declined'");
        $stmt->execute($statsParams);
        $stats['declined'] = (int)$stmt->fetch(PDO::FETCH_ASSOC)['count'];

        echo json_encode([
            'success' => true,
            'data' => $stats
        ]);
    }
    elseif ($method === 'POST' && $action === 'create') {
        requireCsrfToken();

        if (strcasecmp($role, 'Requester') !== 0 && strcasecmp($role, 'Admin') !== 0) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Only requesters can submit requests']);
            exit;
        }

        $input = readJsonBody();
        $itemsPayload = $input['items'] ?? [];
        $requestor = $province !== '' ? $province : $username;

        if (!is_array($itemsPayload) || !count($itemsPayload)) {
            throw new Exception('Please add at least one item to the cart');
        }

        $preparedItems = [];
        $deductions = [];
        foreach ($itemsPayload as $entry) {
            $itemId = isset($entry['item_id']) ? (int)$entry['item_id'] : 0;
            $itemName = trim((string)($entry['item_name'] ?? ''));
            $quantity = isset($entry['quantity']) ? (int)$entry['quantity'] : 0;
            $note = trim((string)($entry['note'] ?? ''));

            if ($quantity < 1) {
                continue;
            }

            $item = null;
            if ($itemId > 0) {
                $stmt = $pdo->prepare('SELECT id, item_name, unit, quantity_left FROM requestor_inventory_items WHERE id = ? AND province = ? LIMIT 1');
                $stmt->execute([$itemId, strtoupper($province)]);
                $item = $stmt->fetch(PDO::FETCH_ASSOC);
            } elseif ($itemName !== '') {
                $stmt = $pdo->prepare('SELECT id, item_name, unit, quantity_left FROM requestor_inventory_items WHERE item_name = ? AND province = ? LIMIT 1');
                $stmt->execute([$itemName, strtoupper($province)]);
                $item = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            if (!$item) {
                continue;
            }

            $quantityLeft = (int)$item['quantity_left'];
            $statusLabel = stockStatusFromQty($quantityLeft, 0);
            if ($quantityLeft <= 0) {
                throw new Exception('One or more items are out of stock and cannot be requested');
            }
            $deductions[(int)$item['id']] = ($deductions[(int)$item['id']] ?? 0) + $quantity;
            if ($deductions[(int)$item['id']] > $quantityLeft) {
                throw new Exception("Not enough {$item['item_name']} available in your PPMP inventory");
            }

            $preparedItems[] = [
                'inventory_item_id' => (int)$item['id'],
                'item_name' => $item['item_name'],
                'unit' => $item['unit'],
                'quantity' => $quantity,
                'note' => $note !== '' ? $note : null,
                'stock_status' => $statusLabel,
            ];
        }

        if (!count($preparedItems)) {
            throw new Exception('No valid items were added to the cart');
        }

        $pdo->beginTransaction();
        try {
            $deduct = $pdo->prepare(
                'UPDATE requestor_inventory_items
                 SET quantity_left = quantity_left - ?, updated_at = CURRENT_TIMESTAMP
                 WHERE id = ? AND province = ? AND quantity_left >= ?'
            );
            foreach ($deductions as $inventoryId => $quantity) {
                $deduct->execute([$quantity, $inventoryId, strtoupper($province), $quantity]);
                if ($deduct->rowCount() !== 1) {
                    throw new Exception('Inventory changed while submitting. Please refresh and try again.');
                }
            }

            $firstItem = $preparedItems[0];
            $ins = $pdo->prepare(
                'INSERT INTO requests (item_name, quantity, requestor, stock_status, status, note, item_details)
                 VALUES (?, ?, ?, ?, \'Pending\', ?, ?)'
            );
            $ins->execute([
                $firstItem['item_name'],
                array_reduce($preparedItems, fn($carry, $item) => $carry + (int)$item['quantity'], 0),
                $requestor,
                $firstItem['stock_status'],
                null,
                json_encode($preparedItems)
            ]);
            $newId = (int)$pdo->lastInsertId();
            $createdDateStmt = $pdo->prepare('SELECT DATE(request_date) FROM requests WHERE id = ?');
            $createdDateStmt->execute([$newId]);
            $requestDay = (string)$createdDateStmt->fetchColumn();
            $sequenceStmt = $pdo->prepare(
                'INSERT INTO request_ris_sequences (request_day, last_sequence) VALUES (?, 1)
                 ON DUPLICATE KEY UPDATE last_sequence = last_sequence + 1'
            );
            $sequenceStmt->execute([$requestDay]);
            $sequenceValueStmt = $pdo->prepare('SELECT last_sequence FROM request_ris_sequences WHERE request_day = ? FOR UPDATE');
            $sequenceValueStmt->execute([$requestDay]);
            $risNumber = 'RIS-' . str_replace('-', '', $requestDay) . '-' . str_pad((string)$sequenceValueStmt->fetchColumn(), 4, '0', STR_PAD_LEFT);
            $saveRis = $pdo->prepare('UPDATE requests SET ris_number = ? WHERE id = ?');
            $saveRis->execute([$risNumber, $newId]);
            recordSystemActivity(
                $pdo,
                'request_submitted',
                'request',
                $newId,
                $requestor,
                'Item request submitted',
                ['ris_number' => $risNumber, 'items' => $preparedItems, 'requestor_stock_reserved' => true]
            );
            $pdo->commit();
        } catch (Throwable $transactionError) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $transactionError;
        }

        $stmt = $pdo->prepare('SELECT * FROM requests WHERE id = ?');
        $stmt->execute([$newId]);
        $created = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'message' => 'Request submitted successfully',
            'data' => $created
        ]);
    }
    elseif ($method === 'POST' && $action === 'update_status') {
        requireCsrfToken();

        if (strcasecmp($role, 'Approver') !== 0 && strcasecmp($role, 'Admin') !== 0) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Only approvers can update request status']);
            exit;
        }

        $input = readJsonBody();

        if (!isset($input['id']) || !isset($input['status'])) {
            throw new Exception('Missing required fields: id, status');
        }

        $allowedStatuses = ['Pending', 'Approved', 'Declined'];
        if (!in_array($input['status'], $allowedStatuses, true)) {
            throw new Exception('Invalid status');
        }

        $requestId = (int)$input['id'];
        $newStatus = $input['status'];
        $itemMap = [];

        $stmt = $pdo->prepare('SELECT * FROM requests WHERE id = ? LIMIT 1');
        $stmt->execute([$requestId]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            throw new Exception('Request not found');
        }

        $currentStatus = (string)$request['status'];
        if ($newStatus === $currentStatus || ($currentStatus !== 'Pending' && $newStatus !== 'Pending')) {
            throw new Exception('Requests may only transition from Pending to Approved or Declined.');
        }

        if ($newStatus === 'Approved' && $currentStatus === 'Pending') {
            if (!empty($request['item_details'])) {
                $decoded = json_decode((string)$request['item_details'], true);
                if (is_array($decoded)) {
                    foreach ($decoded as $entry) {
                        $itemName = trim((string)($entry['item_name'] ?? $entry['name'] ?? ''));
                        $quantity = (int)($entry['quantity'] ?? 0);
                        if ($itemName === '' || $quantity <= 0) {
                            continue;
                        }
                        $itemMap[$itemName] = ($itemMap[$itemName] ?? 0) + $quantity;
                    }
                }
            }

            if (empty($itemMap)) {
                $itemName = trim((string)($request['item_name'] ?? ''));
                $quantity = (int)($request['quantity'] ?? 0);
                if ($itemName !== '' && $quantity > 0) {
                    $itemMap[$itemName] = $quantity;
                }
            }

            if (!empty($itemMap)) {
                $pdo->beginTransaction();
                try {
                    foreach ($itemMap as $itemName => $quantity) {
                        $checkStmt = $pdo->prepare(
                            'SELECT stock FROM inventory_items WHERE LOWER(TRIM(item_name)) = LOWER(TRIM(?)) LIMIT 1'
                        );
                        $checkStmt->execute([$itemName]);
                        $inventoryItem = $checkStmt->fetch(PDO::FETCH_ASSOC);

                        if (!$inventoryItem) {
                            throw new Exception("Supply inventory item not found: {$itemName}");
                        }

                        $available = (int)$inventoryItem['stock'];
                        if ($available < $quantity) {
                            throw new Exception("Not enough stock for {$itemName}. Requested {$quantity}, available {$available}.");
                        }
                    }

                    foreach ($itemMap as $itemName => $quantity) {
                        $deductStmt = $pdo->prepare(
                            'UPDATE inventory_items
                             SET stock = stock - ?, last_modified = NOW()
                             WHERE LOWER(TRIM(item_name)) = LOWER(TRIM(?)) AND stock >= ?'
                        );
                        $deductStmt->execute([$quantity, $itemName, $quantity]);

                        if ($deductStmt->rowCount() !== 1) {
                            throw new Exception("Failed to deduct {$quantity} of {$itemName} from supply inventory.");
                        }
                    }

                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    throw $e;
                }
            }
        }

        $restoreRequestorStock = $newStatus === 'Declined' && $currentStatus === 'Pending';
        if ($restoreRequestorStock) {
            $pdo->beginTransaction();
        }

        try {
            if ($restoreRequestorStock) {
                $provinceToRestore = strtoupper(trim((string)$request['requestor']));
                if ($provinceToRestore === '') {
                    throw new Exception('Cannot restore provincial inventory without a request province.');
                }

                $requestItems = json_decode((string)($request['item_details'] ?? ''), true);
                if (!is_array($requestItems) || !$requestItems) {
                    $requestItems = [[
                        'item_name' => $request['item_name'] ?? '',
                        'quantity' => (int)($request['quantity'] ?? 0),
                    ]];
                }

                $restoreQuantities = [];
                $findById = $pdo->prepare(
                    'SELECT id FROM requestor_inventory_items WHERE id = ? AND province = ? FOR UPDATE'
                );
                foreach ($requestItems as $entry) {
                    $itemName = trim((string)($entry['item_name'] ?? $entry['name'] ?? ''));
                    $quantity = (int)($entry['quantity'] ?? 0);
                    if ($itemName === '' || $quantity <= 0) {
                        continue;
                    }

                    $inventoryItemId = (int)($entry['inventory_item_id'] ?? 0);
                    if ($inventoryItemId > 0) {
                        $findById->execute([$inventoryItemId, $provinceToRestore]);
                        $matches = $findById->fetchAll(PDO::FETCH_COLUMN);
                    } else {
                        $unit = trim((string)($entry['unit'] ?? ''));
                        $sql = 'SELECT id FROM requestor_inventory_items
                                WHERE province = ? AND LOWER(TRIM(item_name)) = LOWER(TRIM(?))';
                        $params = [$provinceToRestore, $itemName];
                        if ($unit !== '') {
                            $sql .= ' AND LOWER(TRIM(unit)) = LOWER(TRIM(?))';
                            $params[] = $unit;
                        }
                        $findByName = $pdo->prepare($sql . ' FOR UPDATE');
                        $findByName->execute($params);
                        $matches = $findByName->fetchAll(PDO::FETCH_COLUMN);
                    }

                    if (count($matches) !== 1) {
                        throw new Exception("Cannot safely restore provincial inventory for {$itemName}.");
                    }
                    $inventoryId = (int)$matches[0];
                    $restoreQuantities[$inventoryId] = ($restoreQuantities[$inventoryId] ?? 0) + $quantity;
                }

                $restore = $pdo->prepare(
                    'UPDATE requestor_inventory_items
                     SET quantity_left = quantity_left + ?, updated_at = CURRENT_TIMESTAMP
                     WHERE id = ? AND province = ?'
                );
                foreach ($restoreQuantities as $inventoryId => $quantity) {
                    $restore->execute([$quantity, $inventoryId, $provinceToRestore]);
                    if ($restore->rowCount() !== 1) {
                        throw new Exception('Could not restore the requested provincial inventory.');
                    }
                }
            }

            $upd = $pdo->prepare(
                'UPDATE requests SET status = ?, approver = ?, approved_date = NOW() WHERE id = ?'
            );
            $upd->execute([$newStatus, $username, $requestId]);

            if (strcasecmp((string)$request['status'], $newStatus) !== 0) {
                $loggedItems = json_decode((string)($request['item_details'] ?? ''), true);
                if (!is_array($loggedItems) || !$loggedItems) {
                    $loggedItems = [[
                        'item_name' => $request['item_name'] ?? '',
                        'quantity' => (int)($request['quantity'] ?? 0),
                    ]];
                }
                recordSystemActivity(
                    $pdo,
                    'request_status_changed',
                    'request',
                    $requestId,
                    (string)$request['requestor'],
                    'Item request status changed to ' . $newStatus,
                    [
                        'from_status' => $request['status'],
                        'to_status' => $newStatus,
                        'ris_number' => $request['ris_number'] ?? null,
                        'items' => $loggedItems,
                        'supply_stock_deducted' => $newStatus === 'Approved' ? $itemMap : [],
                        'requestor_stock_restored' => $restoreRequestorStock,
                    ]
                );
            }

            if ($newStatus === 'Declined') {
                $pdo->prepare('DELETE FROM delivery_packages WHERE request_id = ?')->execute([$requestId]);
            }

            if ($restoreRequestorStock) {
                $pdo->commit();
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        echo json_encode([
            'success' => true,
            'message' => 'Request status updated successfully'
        ]);
    }
    elseif ($method === 'GET' && $action === 'download_ris') {
        $requestId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($requestId <= 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Missing request id']);
            exit;
        }

        $accessStmt = $pdo->prepare('SELECT requestor FROM requests WHERE id = ? LIMIT 1');
        $accessStmt->execute([$requestId]);
        $requestProvince = trim((string)$accessStmt->fetchColumn());
        $canDownload = in_array(strtolower($role), ['admin', 'approver'], true)
            || (strcasecmp($role, 'Requester') === 0
                && (strcasecmp($requestProvince, $province !== '' ? $province : $username) === 0
                    || strcasecmp($requestProvince, $username) === 0));
        if (!$canDownload) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'You are not allowed to download this RIS']);
            exit;
        }

        $filePath = buildRisDocument($pdo, $requestId);
        $risStmt = $pdo->prepare('SELECT ris_number FROM requests WHERE id = ? LIMIT 1');
        $risStmt->execute([$requestId]);
        $risFilename = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$risStmt->fetchColumn()) ?: ('RIS-' . $requestId);
        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        header('Content-Disposition: attachment; filename="' . $risFilename . '.docx"');
        readfile($filePath);
        unlink($filePath);
        exit;
    }
    else {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action or method']);
    }
} catch (Exception $e) {
    error_log('Requests API error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'The request could not be completed.']);
}
